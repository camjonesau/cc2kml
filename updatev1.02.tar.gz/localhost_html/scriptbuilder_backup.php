<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>CC2KML Configuration</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">
<script type="text/javascript" src="view.js"></script>

</head>
<body id="main_body" >
	
	<img id="top" src="top.png" alt="">
	<div id="form_container">
	
		<h1><a>CC2KML Configuration</a></h1>
		<form id="form_14872" class="appnitro"  method="post" action="">
					<div class="form_description">
			<h2>CC2KML Configuration</h2>
			<p></p>
		</div>						
			<ul >
				<p>This page is used to edit the configuration file that determines the attribrutes of the KML Making proccess. It loads the last used file and when submitted overwrites the last configuration. A backup copy of the last edited config file can be found in /home/mst/local_host/cc2kml/config.ini.date.time. These configuration files can be reused if required , but no naming/automating convention/process was created so if this is required, it needs to be done manually. They can be renamed for different company or location profiles.</p>
					<li class="section_minibreak"> </li>
				<li class="section_break">
			<h3>Breadcrumb Section</h3>
			<p>This section refers to the breadcrumb KML outputs.</p>
		</li>	
				<li id="li_33" >
		<label class="description" for="element_33">Breadcrumb GPS Preference </label>
		<div>
		<select class="element select medium" id="element_33" name="element_33"> 
			<option value="" selected="selected"></option>
<option value="1" >Auto</option>
<option value="2" >Injected</option>
<option value="3" >Manual</option>

		</select>
		</div><p class="guidelines" id="guide_33"><small>"Auto" = Crumb GPS , "Injected" = pc/local USB GPS, "Manual" = Manual location in programmed  in the crumb</small></p> 
		</li>		<li id="li_1" >
		<label class="description" for="element_1">Include these Breadcrumbs </label>
		<div>
			<input id="element_1" name="element_1" class="element text large" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_1"><small>CSV Include list of matching Breadcrumbs names. This list is processed first, prior to the 'Exclude List' below.</small></p> 
		</li>		<li id="li_2" >
		<label class="description" for="element_2">Exclude these Breadcrumbs </label>
		<div>
			<input id="element_2" name="element_2" class="element text large" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_2"><small>CSV Exclude list of matching Breadcrumbs names. This list is processed last, after the 'Include List' above.</small></p> 
		</li>		<li id="li_5" >
		<label class="description" for="element_5">Breadcrumb Name Search n Replace </label>
		<div>
			<input id="element_5" name="element_5" class="element text large" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_5"><small>Each field is separated by a carat ^.
Each field consists of a find value and replace value seperated by a comma. So if we replace BMA with @bma and BC with Crumb and Building Number with BNO and JPC with null then the string to enter is...
BMA,@bma^BC,Crumb^Building Number,BNO^JPC,</small></p> 

		</li>			
				<li class="section_minibreak"> </li>
				<TABLE BORDER=0>
<TR>
<TD>

				
				<li id="li_6" >
		<label class="description" for="element_6">Crumb Name Text - 01</label>
		<div>
			<input id="element_6" name="element_6" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_6"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
				</li>
				

</TD>
<TD>
	
				<li id="li_34" >
		<label class="description" for="element_34">Link to Style</label>
		<div>
		<select class="element select medium" id="element_34" name="element_34"> 
			<option value="1" selected="selected">styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>

		</select>

					
</div><p class="guidelines" id="guide_34"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 

					

</TD>
</TR>
</TABLE>
	
				
				</li>
				<li class="section_dottedbreak"> </li>

				
				
					<li id="li_7" >
		<label class="description" for="element_7">Crumb Name Text - 02 </label>
		<div>
			<input id="element_7" name="element_7" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_7"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>	
				
				
				
				<li id="li_35" >
		<label class="description" for="element_35">Link to Style</label>
		<div>
		<select class="element select medium" id="element_35" name="element_35"> 
			<option value="1" >styleid_20</option>
<option value="2" selected="selected">styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>

		</select>
		</div><p class="guidelines" id="guide_35"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>	
			<li class="section_dottedbreak"> </li>
				<li id="li_8" >
		<label class="description" for="element_8">Crumb Name Text - 03 </label>
		<div>
			<input id="element_8" name="element_8" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_8"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>		
			<li id="li_36" >
		<label class="description" for="element_36">Link to Style</label>
		<div>
		<select class="element select medium" id="element_36" name="element_36"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" selected="selected">styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>
		</select>
		</div><p class="guidelines" id="guide_36"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>		
				

			<li class="section_dottedbreak"> </li>
				
		<li id="li_6" >
		<label class="description" for="element_6">Crumb Name Text - 04 </label>
		<div>
			<input id="element_6" name="element_6" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_6"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>	
				<li id="li_34" >
		<label class="description" for="element_34">Link to Style</label>
		<div>
		<select class="element select medium" id="element_34" name="element_34"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" selected="selected">styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>

		</select>
		</div><p class="guidelines" id="guide_34"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
			</li>
				<li class="section_dottedbreak"> </li>

				
				
					<li id="li_7" >
		<label class="description" for="element_7">Crumb Name Text - 05 </label>
		<div>
			<input id="element_7" name="element_7" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_7"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>	
				
				
				
				<li id="li_35" >
		<label class="description" for="element_35">Link to Style</label>
		<div>
		<select class="element select medium" id="element_35" name="element_35"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" selected="selected">styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>

		</select>
		</div><p class="guidelines" id="guide_35"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>	
			<li class="section_dottedbreak"> </li>
				<li id="li_8" >
		<label class="description" for="element_8">Crumb Name Text - 06 </label>
		<div>
			<input id="element_8" name="element_8" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_8"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>		
			<li id="li_36" >
		<label class="description" for="element_36">Link to Style</label>
		<div>
		<select class="element select medium" id="element_36" name="element_36"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" selected="selected">styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>
		</select>
		</div><p class="guidelines" id="guide_36"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>		

				
				
			<li class="section_dottedbreak"> </li>
				
						<li id="li_6" >
		<label class="description" for="element_6">Crumb Name Text - 07 </label>
		<div>
			<input id="element_6" name="element_6" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_6"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>	
				<li id="li_34" >
		<label class="description" for="element_34">Link to Style</label>
		<div>
		<select class="element select medium" id="element_34" name="element_34"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" selected="selected">styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>

		</select>
		</div><p class="guidelines" id="guide_34"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
			</li>
				<li class="section_dottedbreak"> </li>

				
				
					<li id="li_7" >
		<label class="description" for="element_7">Crumb Name Text - 08 </label>
		<div>
			<input id="element_7" name="element_7" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_7"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>	
				
				
				
				<li id="li_35" >
		<label class="description" for="element_35">Link to Style</label>
		<div>
		<select class="element select medium" id="element_35" name="element_35"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" selected="selected">styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>

		</select>
		</div><p class="guidelines" id="guide_35"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>	
			<li class="section_dottedbreak"> </li>
				<li id="li_8" >
		<label class="description" for="element_8">Crumb Name Text - 09 </label>
		<div>
			<input id="element_8" name="element_8" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_8"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>		
			<li id="li_36" >
		<label class="description" for="element_36">Link to Style</label>
		<div>
		<select class="element select medium" id="element_36" name="element_36"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" selected="selected">styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>
		</select>
		</div><p class="guidelines" id="guide_36"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>		

				
				
			<li class="section_dottedbreak"> </li>
				
						<li id="li_6" >
		<label class="description" for="element_6">Crumb Name Text - 10 </label>
		<div>
			<input id="element_6" name="element_6" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_6"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>	
				<li id="li_34" >
		<label class="description" for="element_34">Link to Style</label>
		<div>
		<select class="element select medium" id="element_34" name="element_34"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" selected="selected">styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" >styleid_31</option>

		</select>
		</div><p class="guidelines" id="guide_34"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
			</li>
				<li class="section_dottedbreak"> </li>

				
				
					<li id="li_7" >
		<label class="description" for="element_7">Crumb Name Text - 11 </label>
		<div>
			<input id="element_7" name="element_7" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_7"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>	
				
				
				
				<li id="li_35" >
		<label class="description" for="element_35">Link to Style</label>
		<div>
		<select class="element select medium" id="element_35" name="element_35"> 
			<option value="1" >styleid_20</option>
<option value="2" selected="selected">styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" selected="selected">styleid_30</option>
<option value="12" >styleid_31</option>

		</select>
		</div><p class="guidelines" id="guide_35"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>	
			<li class="section_dottedbreak"> </li>
				<li id="li_8" >
		<label class="description" for="element_8">Crumb Name Text - 12 </label>
		<div>
			<input id="element_8" name="element_8" class="element text medium" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_8"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
trailer,solar</small></p> 
		</li>		
			<li id="li_36" >
		<label class="description" for="element_36">Link to Style</label>
		<div>
		<select class="element select medium" id="element_36" name="element_36"> 
			<option value="1" >styleid_20</option>
<option value="2" >styleid_21</option>
<option value="3" >styleid_22</option>
<option value="4" >styleid_23</option>
<option value="5" >styleid_24</option>
<option value="6" >styleid_25</option>
<option value="7" >styleid_26</option>
<option value="8" >styleid_27</option>
<option value="9" >styleid_28</option>
<option value="10" >styleid_29</option>
<option value="11" >styleid_30</option>
<option value="12" selected="selected">styleid_31</option>
		</select>
		</div><p class="guidelines" id="guide_36"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p> 
		</li>		

				
				
				
				
				
				<li class="section_break">
			<h3>Style ID Profiles</h3>
			<p>Style definitions for the BreadCrumb Icons</p>
		</li>		
				
				<li id="li_10" >
		<label class="description" for="element_10">Styleid_20 - Icon Description </label>
		<div>
			<input id="element_10" name="element_10" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_10"><small>Description of this style icon</small></p> 
		</li>		<li id="li_15" >
		<label class="description" for="element_15">Styleid_20 - Icon .PNG Link Address </label>
		<div>
			<input id="element_15" name="element_15" class="element text large" type="text" maxlength="255" value="http://"/> 
		</div> 
		</li>		<li id="li_38" >
		<label class="description" for="element_38">Styleid_20 - Scale Multiplier </label>
		<div>
		<select class="element select small" id="element_38" name="element_38"> 
			<option value="1" >.25</option>
<option value="2" >.5</option>
<option value="3" selected="selected">.75</option>
<option value="4" >1</option>
<option value="5" >1.25</option>
<option value="6" >1.5</option>
<option value="7" >1.75</option>
<option value="8" >2</option>

		</select>
		</div><p class="guidelines" id="guide_38"><small>Increases or decreases the size of the icon.</small></p> 
		</li>		<li id="li_41" >
		<label class="description" for="element_41">Styleid_20 - Color </label>
		<div>
		<select class="element select small" id="element_41" name="element_41"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_41"><small>Colorize the icon.</small></p> 
		</li>	
				<li class="section_dottedbreak"> </li>
				
				
				<li id="li_11" >
		<label class="description" for="element_11">Styleid_21 - Icon Description </label>
		<div>
			<input id="element_11" name="element_11" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_11"><small>Description of this style icon</small></p> 
		</li>		<li id="li_12" >
		<label class="description" for="element_12">Styleid_21 - Icon .PNG Link Address </label>
		<div>
			<input id="element_12" name="element_12" class="element text large" type="text" maxlength="255" value="http://"/> 
		</div> 
		</li>		<li id="li_43" >
		<label class="description" for="element_43">Styleid_21 - Scale Multiplier </label>
		<div>
		<select class="element select small" id="element_43" name="element_43"> 
			<option value="1" >.25</option>
<option value="2" >.5</option>
<option value="3" selected="selected">.75</option>
<option value="4" >1</option>
<option value="5" >1.25</option>
<option value="6" >1.5</option>
<option value="7" >1.75</option>
<option value="8" >2</option>

		</select>
		</div><p class="guidelines" id="guide_43"><small>Increases or decreases the size of the icon.</small></p> 
		</li>		<li id="li_42" >
		<label class="description" for="element_42">Styleid_21 - Color </label>
		<div>
		<select class="element select small" id="element_42" name="element_42"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_42"><small>Colorize the icon.</small></p> 
		</li>	
				<li class="section_dottedbreak"> </li>
				<li id="li_14" >
		<label class="description" for="element_14">STYLEID_22<br><br>Icon Description </label>
		<div>
			<input id="element_14" name="element_14" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_14"><small>Description of this style icon</small></p> 
		</li>		<li id="li_13" >
		<label class="description" for="element_13">Icon .PNG Link Address </label>
		<div>
			<input id="element_13" name="element_13" class="element text large" type="text" maxlength="255" value="http://"/> 
		</div> 
		</li>		<li id="li_40" >
		<label class="description" for="element_40">Scale Multiplier </label>
		<div>
		<select class="element select small" id="element_40" name="element_40"> 
			<option value="1" >.25</option>
<option value="2" >.5</option>
<option value="3" selected="selected">.75</option>
<option value="4" >1</option>
<option value="5" >1.25</option>
<option value="6" >1.5</option>
<option value="7" >1.75</option>
<option value="8" >2</option>

		</select>
		</div><p class="guidelines" id="guide_40"><small>Increases or decreases the size of the icon.</small></p> 
		</li>		<li id="li_39" >
		<label class="description" for="element_39">Color </label>
		<div>
		<select class="element select small" id="element_39" name="element_39"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_39"><small>Colorize the icon.</small></p> 
		</li>		<li class="section_break">
			<h3>Breadcrumb SNR Icons</h3>
			<p></p>
		</li>		<li id="li_22" >
		<label class="description" for="element_22">SNR Icon .PNG Link Address </label>
		<div>
			<input id="element_22" name="element_22" class="element text large" type="text" maxlength="255" value="http://"/> 
		</div><p class="guidelines" id="guide_22"><small>Icon for each SNR plot.</small></p> 
		</li>		<li id="li_88" >
		<label class="description" for="element_88">SNR Icon Scale Multiplier </label>
		<div>
		<select class="element select small" id="element_88" name="element_88"> 
			<option value="1" >.25</option>
<option value="2" >.5</option>
<option value="3" selected="selected">.75</option>
<option value="4" >1</option>
<option value="5" >1.25</option>
<option value="6" >1.5</option>
<option value="7" >1.75</option>
<option value="8" >2</option>

		</select>
		</div><p class="guidelines" id="guide_88"><small>Increases or decreases the size of the icon.</small></p> 
		</li>	
				
				
				<li class="section_break">
			<h3>Breadcrumb SNR Values</h3>
			<p></p>
		</li>		<li id="li_68" >
		<label class="description" for="element_68">SNR Value 01 [minimum] </label>
		<div>
			<input id="element_68" name="element_68" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_68"><small>Min SNR value</small></p> 
		</li>		<li id="li_69" >
		<label class="description" for="element_69">SNR Value 01 - Icon Description </label>
		<div>
			<input id="element_69" name="element_69" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_69"><small>Description of this style icon</small></p> 
		</li>		<li id="li_81" >
		<label class="description" for="element_81">SNR Value 01 - Color </label>
		<div>
		<select class="element select small" id="element_81" name="element_81"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_81"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_17" >
		<label class="description" for="element_17">SNR Value 02 </label>
		<div>
			<input id="element_17" name="element_17" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_17"><small>mid SNR value</small></p> 
		</li>		<li id="li_26" >
		<label class="description" for="element_26">SNR Value 02 - Icon Description </label>
		<div>
			<input id="element_26" name="element_26" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_26"><small>Description of this style icon</small></p> 
		</li>		<li id="li_46" >
		<label class="description" for="element_46">SNR Value 02 - Color </label>
		<div>
		<select class="element select small" id="element_46" name="element_46"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_46"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_21" >
		<label class="description" for="element_21">SNR Value 03 </label>
		<div>
			<input id="element_21" name="element_21" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_21"><small>Mid SNR value</small></p> 
		</li>		<li id="li_28" >
		<label class="description" for="element_28">SNR Value 03 - Icon Description </label>
		<div>
			<input id="element_28" name="element_28" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_28"><small>Description of this style icon</small></p> 
		</li>		<li id="li_47" >
		<label class="description" for="element_47">SNR Value 03 - Color </label>
		<div>
		<select class="element select small" id="element_47" name="element_47"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_47"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_20" >
		<label class="description" for="element_20">SNR Value 04 </label>
		<div>
			<input id="element_20" name="element_20" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_20"><small>Mid SNR value</small></p> 
		</li>		<li id="li_29" >
		<label class="description" for="element_29">SNR Value 04 - Icon Description </label>
		<div>
			<input id="element_29" name="element_29" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_29"><small>Description of this style icon</small></p> 
		</li>		<li id="li_48" >
		<label class="description" for="element_48">SNR Value 04 - Color </label>
		<div>
		<select class="element select small" id="element_48" name="element_48"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_48"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_19" >
		<label class="description" for="element_19">SNR Value 05 </label>
		<div>
			<input id="element_19" name="element_19" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_19"><small>Mid SNR value</small></p> 
		</li>		<li id="li_30" >
		<label class="description" for="element_30">SNR Value 05 - Icon Description </label>
		<div>
			<input id="element_30" name="element_30" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_30"><small>Description of this style icon</small></p> 
		</li>		<li id="li_49" >
		<label class="description" for="element_49">SNR Value 05 - Color </label>
		<div>
		<select class="element select small" id="element_49" name="element_49"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_49"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_18" >
		<label class="description" for="element_18">SNR Value 06 [maximum] </label>
		<div>
			<input id="element_18" name="element_18" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_18"><small>Max SNR value</small></p> 
		</li>		<li id="li_27" >
		<label class="description" for="element_27">SNR Value 06 - Icon Description </label>
		<div>
			<input id="element_27" name="element_27" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_27"><small>Description of this style icon</small></p> 
		</li>		<li id="li_37" >
		<label class="description" for="element_37">SNR Value 06 - Color </label>
		<div>
		<select class="element select small" id="element_37" name="element_37"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_37"><small>Colorize the icon.</small></p> 
		</li>		<li class="section_break">
			<h3>SNR-KML Output Files</h3>
			<p>File options for SNR KML files.</p>
		</li>		<li id="li_53" >
		<label class="description" for="element_53">SNR Output No 1 </label>
		<span>
			<input id="element_53_1" name="element_53" class="element radio" type="radio" value="1" checked="checked"/>
<label class="choice" for="element_53_1">Enabled</label>
<input id="element_53_2" name="element_53" class="element radio" type="radio" value="2" />
<label class="choice" for="element_53_2">Disabled</label>

		</span> 
		</li>		<li id="li_54" >
		<label class="description" for="element_54">SNR No 1 - Target Frequency/Slot </label>
		<div>
		<select class="element select medium" id="element_54" name="element_54"> 
			<option value="1" selected="selected">Radio Slot 1</option>
<option value="2" >Radio Slot 2</option>
<option value="3" >Radio Slot 3</option>
<option value="4" >Radio Slot 4</option>
<option value="5" >All</option>

		</select>
		</div><p class="guidelines" id="guide_54"><small>Use slot no of radio and leave optional data blank ,
OR
Use all and select the frequency in the optional data section. </small></p> 
		</li>		<li id="li_50" >
		<label class="description" for="element_50">SNR No 1 - Optional Data </label>
		<div>
		<select class="element select medium" id="element_50" name="element_50"> 
			<option value="1" selected="selected">Auto detect</option>
<option value="2" >All</option>
<option value="3" >2.4Ghz</option>
<option value="4" >5.8Ghz</option>
<option value="5" >900Mhz</option>
<option value="6" >2.4Ghz,5.8Ghz</option>
<option value="7" >2.4Ghz,900Mhz</option>
<option value="8" >5.8Ghz,900Mhz</option>

		</select>
		</div><p class="guidelines" id="guide_50"><small>If Target Frequency/Slot = slot no , then choose Auto detect.
If Target Frequency/Slot = All , then use selection for the required frequency.</small></p> 
		</li>		<li id="li_56" >
		<label class="description" for="element_56">SNR Output No 2 </label>
		<span>
			<input id="element_56_1" name="element_56" class="element radio" type="radio" value="1" checked="checked"/>
<label class="choice" for="element_56_1">Enabled</label>
<input id="element_56_2" name="element_56" class="element radio" type="radio" value="2" />
<label class="choice" for="element_56_2">Disabled</label>

		</span> 
		</li>		<li id="li_57" >
		<label class="description" for="element_57">SNR No 2 - Target Frequency/Slot </label>
		<div>
		<select class="element select medium" id="element_57" name="element_57"> 
			<option value="1" >Radio Slot 1</option>
<option value="2" selected="selected">Radio Slot 2</option>
<option value="3" >Radio Slot 3</option>
<option value="4" >Radio Slot 4</option>
<option value="5" >All</option>

		</select>
		</div><p class="guidelines" id="guide_57"><small>Use slot no of radio and leave optional data blank ,
OR
Use all and select the frequency in the optional data section. </small></p> 
		</li>		<li id="li_62" >
		<label class="description" for="element_62">SNR No 2 - Optional Data </label>
		<div>
		<select class="element select medium" id="element_62" name="element_62"> 
			<option value="1" selected="selected">Auto detect</option>
<option value="2" >All</option>
<option value="3" >2.4Ghz</option>
<option value="4" >5.8Ghz</option>
<option value="5" >900Mhz</option>
<option value="6" >2.4Ghz,5.8Ghz</option>
<option value="7" >2.4Ghz,900Mhz</option>
<option value="8" >5.8Ghz,900Mhz</option>

		</select>
		</div><p class="guidelines" id="guide_62"><small>If Target Frequency/Slot = slot no , then choose Auto detect.
If Target Frequency/Slot = All , then use selection for the required frequency.</small></p> 
		</li>		<li id="li_59" >
		<label class="description" for="element_59">SNR Output No 3 </label>
		<span>
			<input id="element_59_1" name="element_59" class="element radio" type="radio" value="1" checked="checked"/>
<label class="choice" for="element_59_1">Enabled</label>
<input id="element_59_2" name="element_59" class="element radio" type="radio" value="2" />
<label class="choice" for="element_59_2">Disabled</label>

		</span> 
		</li>		<li id="li_60" >
		<label class="description" for="element_60">SNR No 3 - Target Frequency/Slot </label>
		<div>
		<select class="element select medium" id="element_60" name="element_60"> 
			<option value="1" >Radio Slot 1</option>
<option value="2" >Radio Slot 2</option>
<option value="3" selected="selected">Radio Slot 3</option>
<option value="4" >Radio Slot 4</option>
<option value="5" >All</option>

		</select>
		</div><p class="guidelines" id="guide_60"><small>Use slot no of radio and leave optional data blank ,
OR
Use all and select the frequency in the optional data section. </small></p> 
		</li>		<li id="li_58" >
		<label class="description" for="element_58">SNR No 3 - Optional Data </label>
		<div>
		<select class="element select medium" id="element_58" name="element_58"> 
			<option value="1" selected="selected">Auto detect</option>
<option value="2" >All</option>
<option value="3" >2.4Ghz</option>
<option value="4" >5.8Ghz</option>
<option value="5" >900Mhz</option>
<option value="6" >2.4Ghz,5.8Ghz</option>
<option value="7" >2.4Ghz,900Mhz</option>
<option value="8" >5.8Ghz,900Mhz</option>

		</select>
		</div><p class="guidelines" id="guide_58"><small>If Target Frequency/Slot = slot no , then choose Auto detect.
If Target Frequency/Slot = All , then use selection for the required frequency.</small></p> 
		</li>		<li id="li_61" >
		<label class="description" for="element_61">SNR Output No 4 </label>
		<span>
			<input id="element_61_1" name="element_61" class="element radio" type="radio" value="1" checked="checked"/>
<label class="choice" for="element_61_1">Enabled</label>
<input id="element_61_2" name="element_61" class="element radio" type="radio" value="2" />
<label class="choice" for="element_61_2">Disabled</label>

		</span> 
		</li>		<li id="li_63" >
		<label class="description" for="element_63">SNR No 4 - Target Frequency/Slot </label>
		<div>
		<select class="element select medium" id="element_63" name="element_63"> 
			<option value="1" >Radio Slot 1</option>
<option value="2" >Radio Slot 2</option>
<option value="3" >Radio Slot 3</option>
<option value="4" selected="selected">Radio Slot 4</option>
<option value="5" >All</option>

		</select>
		</div><p class="guidelines" id="guide_63"><small>Use slot no of radio and leave optional data blank ,
OR
Use all and select the frequency in the optional data section. </small></p> 
		</li>		<li id="li_64" >
		<label class="description" for="element_64">SNR No 4 - Optional Data </label>
		<div>
		<select class="element select medium" id="element_64" name="element_64"> 
			<option value="1" selected="selected">Auto detect</option>
<option value="2" >All</option>
<option value="3" >2.4Ghz</option>
<option value="4" >5.8Ghz</option>
<option value="5" >900Mhz</option>
<option value="6" >2.4Ghz,5.8Ghz</option>
<option value="7" >2.4Ghz,900Mhz</option>
<option value="8" >5.8Ghz,900Mhz</option>

		</select>
		</div><p class="guidelines" id="guide_64"><small>If Target Frequency/Slot = slot no , then choose Auto detect.
If Target Frequency/Slot = All , then use selection for the required frequency.</small></p> 
		</li>		<li id="li_65" >
		<label class="description" for="element_65">SNR Output No 5 </label>
		<span>
			<input id="element_65_1" name="element_65" class="element radio" type="radio" value="1" checked="checked"/>
<label class="choice" for="element_65_1">Enabled</label>
<input id="element_65_2" name="element_65" class="element radio" type="radio" value="2" />
<label class="choice" for="element_65_2">Disabled</label>

		</span> 
		</li>		<li id="li_66" >
		<label class="description" for="element_66">SNR No 5 - Target Frequency/Slot </label>
		<div>
		<select class="element select medium" id="element_66" name="element_66"> 
			<option value="1" >Radio Slot 1</option>
<option value="2" >Radio Slot 2</option>
<option value="3" >Radio Slot 3</option>
<option value="4" >Radio Slot 4</option>
<option value="5" selected="selected">All</option>

		</select>
		</div><p class="guidelines" id="guide_66"><small>Use slot no of radio and leave optional data blank ,
OR
Use all and select the frequency in the optional data section. </small></p> 
		</li>		<li id="li_67" >
		<label class="description" for="element_67">SNR No 5 - Optional Data </label>
		<div>
		<select class="element select medium" id="element_67" name="element_67"> 
			<option value="1" >Auto detect</option>
<option value="2" >All</option>
<option value="3" >2.4Ghz</option>
<option value="4" >5.8Ghz</option>
<option value="5" >900Mhz</option>
<option value="6" selected="selected">2.4Ghz,5.8Ghz</option>
<option value="7" >2.4Ghz,900Mhz</option>
<option value="8" >5.8Ghz,900Mhz</option>

		</select>
		</div><p class="guidelines" id="guide_67"><small>If Target Frequency/Slot = slot no , then choose Auto detect.
If Target Frequency/Slot = All , then use selection for the required frequency.</small></p> 
		</li>		<li id="li_51" >
		<label class="description" for="element_51">SNR Output No 6 </label>
		<span>
			<input id="element_51_1" name="element_51" class="element radio" type="radio" value="1" checked="checked"/>
<label class="choice" for="element_51_1">Enabled</label>
<input id="element_51_2" name="element_51" class="element radio" type="radio" value="2" />
<label class="choice" for="element_51_2">Disabled</label>

		</span> 
		</li>		<li id="li_52" >
		<label class="description" for="element_52">SNR No 6 - Target Frequency/Slot </label>
		<div>
		<select class="element select medium" id="element_52" name="element_52"> 
			<option value="1" >Radio Slot 1</option>
<option value="2" >Radio Slot 2</option>
<option value="3" >Radio Slot 3</option>
<option value="4" >Radio Slot 4</option>
<option value="5" selected="selected">All</option>

		</select>
		</div><p class="guidelines" id="guide_52"><small>Use slot no of radio and leave optional data blank ,
OR
Use all and select the frequency in the optional data section. </small></p> 
		</li>		<li id="li_55" >
		<label class="description" for="element_55">SNR No 6 - Optional Data </label>
		<div>
		<select class="element select medium" id="element_55" name="element_55"> 
			<option value="1" >Auto detect</option>
<option value="2" >All</option>
<option value="3" selected="selected">2.4Ghz</option>
<option value="4" >5.8Ghz</option>
<option value="5" >900Mhz</option>
<option value="6" >2.4Ghz,5.8Ghz</option>
<option value="7" >2.4Ghz,900Mhz</option>
<option value="8" >5.8Ghz,900Mhz</option>

		</select>
		</div><p class="guidelines" id="guide_55"><small>If Target Frequency/Slot = slot no , then choose Auto detect.
If Target Frequency/Slot = All , then use selection for the required frequency.</small></p> 
		</li>		<li class="section_break">
			<h3>Ping Section - General settings</h3>
			<p>Ping variables for KML output</p>
		</li>		<li id="li_80" >
		<label class="description" for="element_80">Ping Icon .PNG Link Address </label>
		<div>
			<input id="element_80" name="element_80" class="element text large" type="text" maxlength="255" value="http://"/> 
		</div><p class="guidelines" id="guide_80"><small>Icon for each Ping plot.</small></p> 
		</li>		<li id="li_44" >
		<label class="description" for="element_44">SNR Icon Scale Multiplier </label>
		<div>
		<select class="element select small" id="element_44" name="element_44"> 
			<option value="1" >.25</option>
<option value="2" >.5</option>
<option value="3" selected="selected">.75</option>
<option value="4" >1</option>
<option value="5" >1.25</option>
<option value="6" >1.5</option>
<option value="7" >1.75</option>
<option value="8" >2</option>

		</select>
		</div><p class="guidelines" id="guide_44"><small>Increases or decreases the size of the icon.</small></p> 
		</li>		<li class="section_break">
			<h3>Ping Section - Individual value settings</h3>
			<p>Ping variables for KML output</p>
		</li>		<li id="li_70" >
		<label class="description" for="element_70">Ping Value 00 [minimum] </label>
		<div>
			<input id="element_70" name="element_70" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_70"><small>Min Ping value</small></p> 
		</li>		<li id="li_71" >
		<label class="description" for="element_71">Ping Value 00 - Icon Description </label>
		<div>
			<input id="element_71" name="element_71" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_71"><small>Description of this style icon</small></p> 
		</li>		<li id="li_82" >
		<label class="description" for="element_82">Ping Value 00 - Color </label>
		<div>
		<select class="element select small" id="element_82" name="element_82"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_82"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_79" >
		<label class="description" for="element_79">Ping Value 01 </label>
		<div>
			<input id="element_79" name="element_79" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_79"><small>Med Ping value</small></p> 
		</li>		<li id="li_78" >
		<label class="description" for="element_78">Ping Value 01 - Icon Description </label>
		<div>
			<input id="element_78" name="element_78" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_78"><small>Description of this style icon</small></p> 
		</li>		<li id="li_86" >
		<label class="description" for="element_86">Ping Value 01 - Color </label>
		<div>
		<select class="element select small" id="element_86" name="element_86"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_86"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_72" >
		<label class="description" for="element_72">Ping Value 02 </label>
		<div>
			<input id="element_72" name="element_72" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_72"><small>Med Ping value</small></p> 
		</li>		<li id="li_73" >
		<label class="description" for="element_73">Ping Value 02 - Icon Description </label>
		<div>
			<input id="element_73" name="element_73" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_73"><small>Description of this style icon</small></p> 
		</li>		<li id="li_83" >
		<label class="description" for="element_83">Ping Value 02 - Color </label>
		<div>
		<select class="element select small" id="element_83" name="element_83"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_83"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_74" >
		<label class="description" for="element_74">Ping Value 03 </label>
		<div>
			<input id="element_74" name="element_74" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_74"><small>Med Ping value</small></p> 
		</li>		<li id="li_75" >
		<label class="description" for="element_75">Ping Value 03 - Icon Description </label>
		<div>
			<input id="element_75" name="element_75" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_75"><small>Description of this style icon</small></p> 
		</li>		<li id="li_84" >
		<label class="description" for="element_84">Ping Value 03 - Color </label>
		<div>
		<select class="element select small" id="element_84" name="element_84"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_84"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_76" >
		<label class="description" for="element_76">Ping Value 04 </label>
		<div>
			<input id="element_76" name="element_76" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_76"><small>Med Ping value</small></p> 
		</li>		<li id="li_77" >
		<label class="description" for="element_77">Ping Value 04 - Icon Description </label>
		<div>
			<input id="element_77" name="element_77" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_77"><small>Description of this style icon</small></p> 
		</li>		<li id="li_85" >
		<label class="description" for="element_85">Ping Value 04 - Color </label>
		<div>
		<select class="element select small" id="element_85" name="element_85"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_85"><small>Colorize the icon.</small></p> 
		</li>		<li id="li_16" >
		<label class="description" for="element_16">Ping Value 05 </label>
		<div>
			<input id="element_16" name="element_16" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_16"><small>Max Ping value</small></p> 
		</li>		<li id="li_25" >
		<label class="description" for="element_25">Ping Value 05 - Icon Description </label>
		<div>
			<input id="element_25" name="element_25" class="element text small" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_25"><small>Description of this style icon</small></p> 
		</li>		<li id="li_45" >
		<label class="description" for="element_45">Ping Value 05 - Color </label>
		<div>
		<select class="element select small" id="element_45" name="element_45"> 
			<option value="1" >Black,ff00ffff</option>
<option value="2" >Red,ff0000ff</option>
<option value="3" selected="selected">Orange,</option>
<option value="4" >Yellow,</option>
<option value="5" >Bright Green,</option>
<option value="6" >Dark Green</option>
<option value="7" >Medium Green</option>
<option value="8" >Blue,</option>

		</select>
		</div><p class="guidelines" id="guide_45"><small>Colorize the icon.</small></p> 
		</li>
			
					<li class="buttons">
			    <input type="hidden" name="form_id" value="14872" />
			    
				<input id="saveForm" class="button_text" type="submit" name="submit" value="Submit" />
		</li>
			</ul>
		</form>	
		<div id="footer">
			Generated by <a href="http://www.phpform.org">pForm</a>
		</div>
	</div>
	<img id="bottom" src="bottom.png" alt="">
	</body>
</html>

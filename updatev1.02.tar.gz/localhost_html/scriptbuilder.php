<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>CC2KML Configuration</title>
      <link rel="stylesheet" type="text/css" href="view.css" media="all">
      <script type="text/javascript" src="view.js"></script>
      <style>
      </style>
   </head>
   <?php
      function readkmlset($filename)
      {
      	if (!file_exists($filename)) {
      		//dbg("d", "file not found $filename");
      		$filename = "/home/mst/localhost_html/cc2kml/kmlset_default.ini";
      		//dbg("d", "using instead the default file $filename");
      		if (!file_exists($filename)) {
      			//dbg("d", "default file not found $filename");
      			setdefaults($filename);
      			//dbg("d", "created new default file $filename");
      		}
      	}
      	else {
      		//dbg("d", "file found , using file $filename");
      	}
      	return parse_ini_file($filename, true);
      } //end of func readkmlset
      
      function getval($type,$setkmlarray)
      {
      	
      	return (" ");
      }
      	
      if ($_GET["filename"] == "kmlset_default (original backup).ini"){
      $setkmlarray = readkmlset("/home/mst/localhost_html/cc2kml/kmlset_default (original backup).ini");
      //echo "default loaded";	
      }else{
      $setkmlarray = readkmlset("/home/mst/localhost_html/cc2kml/kmlset_default.ini");
      //echo "standard";
      }
      	
      	
      if ($_POST['postfullform'] == 'Submit'){
      	$date = new DateTime();
      $date = $date->format("y:m:d h:i:s");
      echo copy("/home/mst/localhost_html/cc2kml/kmlset_default.ini","/home/mst/localhost_html/logs/kmlset_default.ini.$date");
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"targetcrumbgpspreference\" \"\\\"".($_POST['element_33'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"includecrumbswith\" \"\\\"".($_POST['element_1'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"excludecrumbswith\" \"\\\"".($_POST['element_2'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapshortcutname\" \"\\\"".($_POST['element_5'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_01\" \"\\\"".($_POST['element_6'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_01\" \"\\\"".($_POST['element_34'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_02\" \"\\\"".($_POST['element_7'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_02\" \"\\\"".($_POST['element_35'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_03\" \"\\\"".($_POST['element_8'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_03\" \"\\\"".($_POST['element_36'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_04\" \"\\\"".($_POST['element_106'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_04\" \"\\\"".($_POST['element_134'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_05\" \"\\\"".($_POST['element_107'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_05\" \"\\\"".($_POST['element_135'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_06\" \"\\\"".($_POST['element_108'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_06\" \"\\\"".($_POST['element_136'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_07\" \"\\\"".($_POST['element_206'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_07\" \"\\\"".($_POST['element_234'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_08\" \"\\\"".($_POST['element_207'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_08\" \"\\\"".($_POST['element_235'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_09\" \"\\\"".($_POST['element_208'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_09\" \"\\\"".($_POST['element_236'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_10\" \"\\\"".($_POST['element_306'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_10\" \"\\\"".($_POST['element_334'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_11\" \"\\\"".($_POST['element_307'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_11\" \"\\\"".($_POST['element_335'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstring_12\" \"\\\"".($_POST['element_308'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"mapcrumbstyleid_12\" \"\\\"".($_POST['element_336'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_20\" \"\\\"".($_POST['element_10'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_20\" \"\\\"".($_POST['element_15'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_20\" \"\\\"".($_POST['element_38'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_20\" \"\\\"".($_POST['element_41'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_21\" \"\\\"".($_POST['element_11'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_21\" \"\\\"".($_POST['element_12'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_21\" \"\\\"".($_POST['element_43'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_21\" \"\\\"".($_POST['element_42'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_22\" \"\\\"".($_POST['element_14'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_22\" \"\\\"".($_POST['element_13'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_22\" \"\\\"".($_POST['element_40'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_22\" \"\\\"".($_POST['element_39'])."\\\"\"");
      	
      	
      	
      	
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_23\" \"\\\"".($_POST['element_110'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_23\" \"\\\"".($_POST['element_115'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_23\" \"\\\"".($_POST['element_138'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_23\" \"\\\"".($_POST['element_141'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_24\" \"\\\"".($_POST['element_111'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_24\" \"\\\"".($_POST['element_112'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_24\" \"\\\"".($_POST['element_143'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_24\" \"\\\"".($_POST['element_142'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_25\" \"\\\"".($_POST['element_114'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_25\" \"\\\"".($_POST['element_113'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_25\" \"\\\"".($_POST['element_140'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_25\" \"\\\"".($_POST['element_139'])."\\\"\"");
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_26\" \"\\\"".($_POST['element_210'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_26\" \"\\\"".($_POST['element_215'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_26\" \"\\\"".($_POST['element_238'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_26\" \"\\\"".($_POST['element_241'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_27\" \"\\\"".($_POST['element_211'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_27\" \"\\\"".($_POST['element_212'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_27\" \"\\\"".($_POST['element_243'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_27\" \"\\\"".($_POST['element_242'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_28\" \"\\\"".($_POST['element_214'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_28\" \"\\\"".($_POST['element_213'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_28\" \"\\\"".($_POST['element_240'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_28\" \"\\\"".($_POST['element_239'])."\\\"\"");
      	
      	
      	
      	
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_29\" \"\\\"".($_POST['element_310'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_29\" \"\\\"".($_POST['element_315'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_29\" \"\\\"".($_POST['element_338'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_29\" \"\\\"".($_POST['element_341'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_30\" \"\\\"".($_POST['element_311'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_30\" \"\\\"".($_POST['element_312'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_30\" \"\\\"".($_POST['element_343'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_30\" \"\\\"".($_POST['element_342'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_31\" \"\\\"".($_POST['element_314'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_31\" \"\\\"".($_POST['element_313'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_31\" \"\\\"".($_POST['element_340'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_31\" \"\\\"".($_POST['element_339'])."\\\"\"");
      
      	
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_06\" \"\\\"".($_POST['element_900'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01styleurl06\" \"\\\"".($_POST['element_901'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_06\" \"\\\"".($_POST['element_902'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_06\" \"\\\"".($_POST['element_903'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_06\" \"\\\"".($_POST['element_904'])."\\\"\"");
      	
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_07\" \"\\\"".($_POST['element_910'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01styleurl07\" \"\\\"".($_POST['element_911'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_07\" \"\\\"".($_POST['element_912'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_07\" \"\\\"".($_POST['element_913'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_07\" \"\\\"".($_POST['element_914'])."\\\"\"");
      	
      	
      	
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_08\" \"\\\"".($_POST['element_920'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01styleurl08\" \"\\\"".($_POST['element_921'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_08\" \"\\\"".($_POST['element_922'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_08\" \"\\\"".($_POST['element_923'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_08\" \"\\\"".($_POST['element_924'])."\\\"\"");
      	
      	
      	
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_09\" \"\\\"".($_POST['element_930'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01styleurl09\" \"\\\"".($_POST['element_931'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_09\" \"\\\"".($_POST['element_932'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_09\" \"\\\"".($_POST['element_933'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_09\" \"\\\"".($_POST['element_934'])."\\\"\"");
      	
      	
      	
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_10\" \"\\\"".($_POST['element_940'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01styleurl10\" \"\\\"".($_POST['element_941'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_10\" \"\\\"".($_POST['element_942'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_10\" \"\\\"".($_POST['element_943'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_10\" \"\\\"".($_POST['element_944'])."\\\"\"");
      	
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"styleid_11\" \"\\\"".($_POST['element_950'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01styleurl11\" \"\\\"".($_POST['element_951'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"iconref_11\" \"\\\"".($_POST['element_952'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"scale_11\" \"\\\"".($_POST['element_953'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"color_11\" \"\\\"".($_POST['element_954'])."\\\"\"");
      		
      	
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutenabled01\" \"\\\"".($_POST['element_53'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutspecialdata01\" \"\\\"".($_POST['element_54'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutoptiondata01\" \"\\\"".($_POST['element_50'])."\\\"\"");
      
      
      	
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutenabled02\" \"\\\"".($_POST['element_56'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutspecialdata02\" \"\\\"".($_POST['element_57'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutoptiondata02\" \"\\\"".($_POST['element_62'])."\\\"\"");
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutenabled03\" \"\\\"".($_POST['element_59'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutspecialdata03\" \"\\\"".($_POST['element_60'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutoptiondata03\" \"\\\"".($_POST['element_58'])."\\\"\"");
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutenabled04\" \"\\\"".($_POST['element_61'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutspecialdata04\" \"\\\"".($_POST['element_63'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutoptiondata04\" \"\\\"".($_POST['element_64'])."\\\"\"");
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutenabled05\" \"\\\"".($_POST['element_65'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutspecialdata05\" \"\\\"".($_POST['element_66'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutoptiondata05\" \"\\\"".($_POST['element_67'])."\\\"\"");
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutenabled06\" \"\\\"".($_POST['element_51'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutspecialdata06\" \"\\\"".($_POST['element_52'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"BCC\" \"pm01kmloutoptiondata06\" \"\\\"".($_POST['element_55'])."\\\"\"");
      
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"styleid_00\" \"\\\"".($_POST['element_800'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"pm01styleurl00\" \"\\\"".($_POST['element_801'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"iconref_00\" \"\\\"".($_POST['element_802'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"scale_00\" \"\\\"".($_POST['element_803'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"color_00\" \"\\\"".($_POST['element_804'])."\\\"\"");
      	
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"styleid_01\" \"\\\"".($_POST['element_810'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"pm01styleurl01\" \"\\\"".($_POST['element_811'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"iconref_01\" \"\\\"".($_POST['element_812'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"scale_01\" \"\\\"".($_POST['element_813'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"color_01\" \"\\\"".($_POST['element_814'])."\\\"\"");
      	
      	
      	
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"styleid_02\" \"\\\"".($_POST['element_820'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"pm01styleurl02\" \"\\\"".($_POST['element_821'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"iconref_02\" \"\\\"".($_POST['element_822'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"scale_02\" \"\\\"".($_POST['element_823'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"color_02\" \"\\\"".($_POST['element_824'])."\\\"\"");
      	
      	
      	
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"styleid_03\" \"\\\"".($_POST['element_830'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"pm01styleurl03\" \"\\\"".($_POST['element_831'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"iconref_03\" \"\\\"".($_POST['element_832'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"scale_03\" \"\\\"".($_POST['element_833'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"color_03\" \"\\\"".($_POST['element_834'])."\\\"\"");
      	
      	
      	
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"styleid_04\" \"\\\"".($_POST['element_840'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"pm01styleurl04\" \"\\\"".($_POST['element_841'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"iconref_04\" \"\\\"".($_POST['element_842'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"scale_04\" \"\\\"".($_POST['element_843'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"color_04\" \"\\\"".($_POST['element_844'])."\\\"\"");
      	
      
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"styleid_05\" \"\\\"".($_POST['element_850'])."\\\"\"");
      	usleep(005000);	
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"pm01styleurl05\" \"\\\"".($_POST['element_851'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"iconref_05\" \"\\\"".($_POST['element_852'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"scale_05\" \"\\\"".($_POST['element_853'])."\\\"\"");
      	usleep(005000);
      	exec("\"/usr/bin/crudini\" --set --existing \"/home/mst/localhost_html/cc2kml/kmlset_default.ini\" \"Ping\" \"color_05\" \"\\\"".($_POST['element_854'])."\\\"\"");
      		
      	
      	
      	
      //temp entries for troubleshooting	
      //echo "\n06=".($_POST['element_06'])."\n";
      //echo "34=".($_POST['element_34'])."\n";
      //echo "\n07=".($_POST['element_07'])."\n";
      //echo "35=".($_POST['element_35'])."\n";
      	
      header("Location: http://127.0.0.1/~mst/default.html");
      
      	//if(isset($_REQUEST["destination"])){
          //  header("Location: {$_REQUEST["destination"]}");
      //}else if(isset($_SERVER["HTTP_REFERER"])){
        //    header("Location: {$_SERVER["HTTP_REFERER"]}");
      //}else{
             /* some fallback, maybe redirect to index.php */
      	//header("Location: http://127.0.0.1/~mst/default.html");
      	
      	
      	
      //}
      	
      	
      }else{
      	//tempdebug to screen
      	//#$debuglevel = $setkmlarray['General']['debuglevel'];
      	//echo $setkmlarray['BCC']['mapcrumbstyleid_02'];
      	
      	
      ?>
   <body id="main_body" >
      <img id="top" src="top.png" alt="">
      <div id="form_container">
      <h1><a>CC2KML Configuration Editor</a></h1>
      <form id="form_14872" class="appnitro"  method="post" action="" name="formname">
         <div class="form_description">
            <h2>CC2KML Configuration Editor</h2>
            <p></p>
         </div>
         <ul >
            <p>This page is used to edit the configuration file that determines the attribrutes of the KML Making proccess. It loads the last used config file and when submitted overwrites the last configuration. A backup copy of the edited config file can be found in /home/mst/local_host/logs/config.ini.date.time. These configuration files can be reused if required , but no naming/automating convention/process was created so if this is required, it needs to be done manually. The default config can be reloaded via the hyperlink below the submit button at the bottom of this page.</p>
            <li class="section_minibreak"> </li>
            <li class="section_break">
               <h3>Breadcrumb Section</h3>
               <p>This section refers to the breadcrumb KML outputs.</p>
            </li>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >General Breadcrumb Options
            </button>
            <div class="panel">
               <li id="li_33" >
                  <label class="description" for="element_33">Breadcrumb GPS Preference </label>
                  <div>
                     <select class="element select medium" id="element_33" name="element_33">
                        <option <?php if ($setkmlarray['BCC']['targetcrumbgpspreference'] == "Auto") { echo " selected = \"selected\"";}else{ echo "";}?> autocomplete="off" value="Auto" >Auto</option>
                        <option <?php if ($setkmlarray['BCC']['targetcrumbgpspreference'] == "Injected") { echo " selected = \"selected\"";}else{ echo "";}?> autocomplete="off" value="Injected" >Injected</option>
                        <option <?php if ($setkmlarray['BCC']['targetcrumbgpspreference'] == "Manual") { echo " selected = \"selected\"";}else{ echo "";}?> autocomplete="off" value="Manual" >Manual</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_33"><small>"Auto" = Crumb GPS , "Injected" = pc/local USB GPS, "Manual" = Manual location in programmed  in the crumb</small></p>
               </li>
               <li id="li_1" >
                  <label class="description" for="element_1">Include these Breadcrumbs </label>
                  <div>
                     <input id="element_1" name="element_1" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['includecrumbswith']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_1"><small>CSV Include list of matching Breadcrumbs names. This list is processed first, prior to the 'Exclude List' below.</small></p>
               </li>
               <li id="li_2" >
                  <label class="description" for="element_2">Exclude these Breadcrumbs </label>
                  <div>
                     <input id="element_2" name="element_2" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['excludecrumbswith']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_2"><small>CSV Exclude list of matching Breadcrumbs names. This list is processed last, after the 'Include List' above.</small></p>
               </li>
               <li id="li_5" >
                  <label class="description" for="element_5">Breadcrumb Name Search n Replace </label>
                  <div>
                     <input id="element_5" name="element_5" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapshortcutname']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_5"><small>Each field is separated by a carat ^.
                     Each field consists of a find value and replace value seperated by a comma. So if we replace BMA with @bma and BC with Crumb and Building Number with BNO and JPC with null then the string to enter is...
                     BMA,@bma^BC,Crumb^Building Number,BNO^JPC,</small>
                  </p>
               </li>
            </div>
            <li class="section_minibreak"> </li>
            <TABLE BORDER=0>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 01
            </button>
            <div class="panel">
               <li id="li_6" >
                  <label class="description" for="element_6">Crumb Name Text - 01  </label>
                  <div>
                     <input id="element_6" name="element_6" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_01']?>"/> 
                  <p class="guidelines" id="guide_6"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>

				   </div>
               </li>
               <li id="li_34" >
                  <label class="description" for="element_34">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_34" name="element_34">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_01'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_34"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 02
            </button>
            <div class="panel">
               <li id="li_7" >
                  <label class="description" for="element_7">Crumb Name Text - 02  </label>
                  <div>
                     <input id="element_7" name="element_7" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_02']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_7"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_35" >
                  <label class="description" for="element_35">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_35" name="element_35">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_02'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_35"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 03
            </button>
            <div class="panel">
               <li id="li_8" >
                  <label class="description" for="element_8">Crumb Name Text - 03 </label>
                  <div>
                     <input id="element_8" name="element_8" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_03']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_8"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_36" >
                  <label class="description" for="element_36">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_36" name="element_36">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_03'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_36"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 04
            </button>
            <div class="panel">
               <li id="li_106" >
                  <label class="description" for="element_106">Crumb Name Text - 04 </label>
                  <div>
                     <input id="element_106" name="element_106" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_04']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_106"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_134" >
                  <label class="description" for="element_134">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_134" name="element_134">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_04'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_134"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 05
            </button>
            <div class="panel">
               <li id="li_107" >
                  <label class="description" for="element_107">Crumb Name Text - 05 </label>
                  <div>
                     <input id="element_107" name="element_107" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_05']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_107"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_135" >
                  <label class="description" for="element_135">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_135" name="element_135">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_05'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_135"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 06
            </button>
            <div class="panel">
               <li id="li_108" >
                  <label class="description" for="element_108">Crumb Name Text - 06 </label>
                  <div>
                     <input id="element_108" name="element_108" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_06']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_108"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_136" >
                  <label class="description" for="element_136">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_136" name="element_136">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_06'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_136"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 07
            </button>
            <div class="panel">
               <li id="li_206" >
                  <label class="description" for="element_206">Crumb Name Text - 07 </label>
                  <div>
                     <input id="element_206" name="element_206" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_07']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_206"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_234" >
                  <label class="description" for="element_234">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_234" name="element_234">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_07'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_234"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
               <li class="section_dottedbreak"> </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 08
            </button>
            <div class="panel">
               <li id="li_207" >
                  <label class="description" for="element_207">Crumb Name Text - 08 </label>
                  <div>
                     <input id="element_207" name="element_207" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_08']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_207"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_235" >
                  <label class="description" for="element_235">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_235" name="element_235">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_08'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_235"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 09
            </button>
            <div class="panel">
               <li id="li_208" >
                  <label class="description" for="element_208">Crumb Name Text - 09 </label>
                  <div>
                     <input id="element_208" name="element_208" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_09']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_208"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_236" >
                  <label class="description" for="element_236">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_236" name="element_236">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_09'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_236"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 10
            </button>
            <div class="panel">
               <li id="li_306" >
                  <label class="description" for="element_306">Crumb Name Text - 10 </label>
                  <div>
                     <input id="element_306" name="element_306" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_10']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_306"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_334" >
                  <label class="description" for="element_334">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_334" name="element_334">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_10'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_334"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 11
            </button>
            <div class="panel">
               <li id="li_307" >
                  <label class="description" for="element_307">Crumb Name Text - 11 </label>
                  <div>
                     <input id="element_307" name="element_307" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_11']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_307"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_335" >
                  <label class="description" for="element_335">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_335" name="element_335">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_11'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_335"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Match Name to Icon - 12
            </button>
            <div class="panel">
               <li id="li_308" >
                  <label class="description" for="element_308">Crumb Name Text - 12 </label>
                  <div>
                     <input id="element_308" name="element_308" class="element text medium" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['mapcrumbstring_12']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_308"><small>CSV list of names to match. For example if you want to match 'trailer' and 'solar'  names then the input would be ...
                     trailer,solar</small>
                  </p>
               </li>
               <li id="li_336" >
                  <label class="description" for="element_336">Link to Style</label>
                  <div>
                     <select class="element select medium" id="element_336" name="element_336">
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_20") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_20" >styleid_20</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_21") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_21" >styleid_21</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_22") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_22" >styleid_22</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_23") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_23" >styleid_23</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_24") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_24" >styleid_24</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_25") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_25" >styleid_25</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_26") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_26" >styleid_26</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_27") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_27" >styleid_27</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_28") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_28" >styleid_28</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_29") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_29" >styleid_29</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_30") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_30" >styleid_30</option>
                        <option <?php if ($setkmlarray['BCC']['mapcrumbstyleid_12'] == "styleid_31") { echo " selected = \"selected\"";}else{ echo "";}?> value="styleid_31" >styleid_31</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_336"><small>Match an Icon Style to the Name to use in the Breadcrumb KML output files.</small></p>
               </li>
            </div>
            <li class="section_break">
               <h3>Breadcrumb Icon Style ID Profiles</h3>
               <p>Style definitions for the BreadCrumb Icons</p>
            </li>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 20
            </button>
            <div class="panel">
               <li id="li_10" >
                  <label class="description" for="element_10">Icon Description </label>
                  <div>
                     <input id="element_10" name="element_10" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_20']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_10"><small>Description of this style icon</small></p>
               </li>
               <li id="li_15" >
                  <label class="description" for="element_15">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_15" name="element_15" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_20']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_15"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_20']."\">"?> </p>
                  </div>
               </li>
               <li id="li_38" >
                  <label class="description" for="element_38">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_38" name="element_38">
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_20'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_38"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_41" >
                  <label class="description" for="element_41">Color </label>
                  <div>
                     <select class="element select small" id="element_41" name="element_41">
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_20'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_41"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 21
            </button>
            <div class="panel">
               <li id="li_11" >
                  <label class="description" for="element_11">Icon Description </label>
                  <div>
                     <input id="element_11" name="element_11" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_21']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_11"><small>Description of this style icon</small></p>
               </li>
               <li id="li_12" >
                  <label class="description" for="element_12">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_12" name="element_12" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_21']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_12"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_21']."\">"?> </p>
                  </div>
               </li>
               <li id="li_43" >
                  <label class="description" for="element_43">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_43" name="element_43">
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_21'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_43"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_42" >
                  <label class="description" for="element_42">Color </label>
                  <div>
                     <select class="element select small" id="element_42" name="element_42">
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_21'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_42"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 22
            </button>
            <div class="panel">
               <li class="section_dottedbreak"> </li>
               <li id="li_14" >
                  <label class="description" for="element_14">STYLEID_22<br><br>Icon Description </label>
                  <div>
                     <input id="element_14" name="element_14" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_22']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_14"><small>Description of this style icon</small></p>
               </li>
               <li id="li_13" >
                  <label class="description" for="element_13">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_13" name="element_13" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_22']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_13"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_22']."\">"?> </p>
                  </div>
               </li>
               <li id="li_40" >
                  <label class="description" for="element_40">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_40" name="element_40">
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_22'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_40"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_39" >
                  <label class="description" for="element_39">Color </label>
                  <div>
                     <select class="element select small" id="element_39" name="element_39">
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_22'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_39"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 23
            </button>
            <div class="panel">
               <li id="li_110" >
                  <label class="description" for="element_110">Icon Description </label>
                  <div>
                     <input id="element_110" name="element_110" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_23']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_110"><small>Description of this style icon</small></p>
               </li>
               <li id="li_115" >
                  <label class="description" for="element_115">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_115" name="element_115" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_23']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_115"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_23']."\">"?> </p>
                  </div>
               </li>
               <li id="li_138" >
                  <label class="description" for="element_138">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_138" name="element_138">
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_23'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_138"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_141" >
                  <label class="description" for="element_141">Color </label>
                  <div>
                     <select class="element select small" id="element_141" name="element_141">
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_23'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_141"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 24
            </button>
            <div class="panel">
               <li id="li_111" >
                  <label class="description" for="element_111">Icon Description </label>
                  <div>
                     <input id="element_111" name="element_111" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_24']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_111"><small>Description of this style icon</small></p>
               </li>
               <li id="li_112" >
                  <label class="description" for="element_112">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_112" name="element_112" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_24']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_112"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_24']."\">"?> </p>
                  </div>
               </li>
               <li id="li_143" >
                  <label class="description" for="element_143">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_143" name="element_143">
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_24'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_143"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_142" >
                  <label class="description" for="element_142">Color </label>
                  <div>
                     <select class="element select small" id="element_142" name="element_142">
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_24'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_142"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 25
            </button>
            <div class="panel">
               <li id="li_114" >
                  <label class="description" for="element_114">Icon Description </label>
                  <div>
                     <input id="element_114" name="element_114" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_25']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_114"><small>Description of this style icon</small></p>
               </li>
               <li id="li_113" >
                  <label class="description" for="element_113">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_113" name="element_113" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_25']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_113"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_25']."\">"?> </p>
                  </div>
               </li>
               <li id="li_140" >
                  <label class="description" for="element_140">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_140" name="element_140">
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_25'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_140"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_139" >
                  <label class="description" for="element_139">Color </label>
                  <div>
                     <select class="element select small" id="element_139" name="element_139">
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_25'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_139"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 26
            </button>
            <div class="panel">
               <li id="li_210" >
                  <label class="description" for="element_210">Icon Description </label>
                  <div>
                     <input id="element_210" name="element_210" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_26']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_210"><small>Description of this style icon</small></p>
               </li>
               <li id="li_215" >
                  <label class="description" for="element_215">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_215" name="element_215" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_26']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_215"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_26']."\">"?> </p>
                  </div>
               </li>
               <li id="li_238" >
                  <label class="description" for="element_238">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_238" name="element_238">
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_26'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_238"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_241" >
                  <label class="description" for="element_241">Color </label>
                  <div>
                     <select class="element select small" id="element_241" name="element_241">
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_26'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_241"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 27
            </button>
            <div class="panel">
               <li id="li_211" >
                  <label class="description" for="element_11">Icon Description </label>
                  <div>
                     <input id="element_211" name="element_211" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_27']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_211"><small>Description of this style icon</small></p>
               </li>
               <li id="li_212" >
                  <label class="description" for="element_212">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_212" name="element_212" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_27']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_212"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_27']."\">"?> </p>
                  </div>
               </li>
               <li id="li_243" >
                  <label class="description" for="element_243">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_243" name="element_243">
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_27'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_243"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_242" >
                  <label class="description" for="element_242">Color </label>
                  <div>
                     <select class="element select small" id="element_242" name="element_242">
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_27'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_242"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 28
            </button>
            <div class="panel">
               <li id="li_214" >
                  <label class="description" for="element_214">Icon Description </label>
                  <div>
                     <input id="element_214" name="element_214" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_28']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_214"><small>Description of this style icon</small></p>
               </li>
               <li id="li_213" >
                  <label class="description" for="element_213">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_213" name="element_213" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_28']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_213"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_28']."\">"?> </p>
                  </div>
               </li>
               <li id="li_240" >
                  <label class="description" for="element_240">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_240" name="element_240">
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_28'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_240"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_239" >
                  <label class="description" for="element_239">Color </label>
                  <div>
                     <select class="element select small" id="element_239" name="element_239">
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_28'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_239"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 29
            </button>
            <div class="panel">
               <li id="li_310" >
                  <label class="description" for="element_310">Icon Description </label>
                  <div>
                     <input id="element_310" name="element_310" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_29']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_310"><small>Description of this style icon</small></p>
               </li>
               <li id="li_315" >
                  <label class="description" for="element_315">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_315" name="element_315" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_29']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_315"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_29']."\">"?> </p>
                  </div>
               </li>
               <li id="li_338" >
                  <label class="description" for="element_338">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_338" name="element_338">
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_29'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_338"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_341" >
                  <label class="description" for="element_341">Color </label>
                  <div>
                     <select class="element select small" id="element_341" name="element_341">
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_29'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_341"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 30
            </button>
            <div class="panel">
               <li id="li_311" >
                  <label class="description" for="element_311">Icon Description </label>
                  <div>
                     <input id="element_311" name="element_311" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_30']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_311"><small>Description of this style icon</small></p>
               </li>
               <li id="li_312" >
                  <label class="description" for="element_312">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_312" name="element_312" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_30']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_312"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_30']."\">"?> </p>
                  </div>
               </li>
               <li id="li_343" >
                  <label class="description" for="element_343">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_343" name="element_343">
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_30'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_343"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_342" >
                  <label class="description" for="element_342">Color </label>
                  <div>
                     <select class="element select small" id="element_342" name="element_342">
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_30'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_342"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Breadcrumb Icon Style - 31
            </button>
            <div class="panel">
               <li id="li_314" >
                  <label class="description" for="element_314">Icon Description </label>
                  <div>
                     <input id="element_314" name="element_314" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_31']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_314"><small>Description of this style icon</small></p>
               </li>
               <li id="li_313" >
                  <label class="description" for="element_313">Icon .PNG Link Address </label>
                  <div>
                     <input id="element_313" name="element_313" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_31']?>"
                     <p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p>
                     <p class="guidelines" id="guide_313"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_31']."\">"?> </p>
                  </div>
               </li>
               <li id="li_340" >
                  <label class="description" for="element_340">Scale Multiplier </label>
                  <div>
                     <select class="element select small" id="element_340" name="element_340">
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                        <option <?php if ($setkmlarray['BCC']['scale_31'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_340"><small>Increases or decreases the size of the icon.</small></p>
               </li>
               <li id="li_339" >
                  <label class="description" for="element_339">Color </label>
                  <div>
                     <select class="element select small" id="element_339" name="element_339">
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                        <option <?php if ($setkmlarray['BCC']['color_31'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_339"><small>Colorize the icon.</small></p>
               </li>
            </div>
            <li class="section_dottedbreak"> </li>
            <li class="section_break">
               <h3>Breadcrumb SNR Location Plotting Icons</h3>
               <p>Change the SNR plots icons</p>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Style - 1
            </button>
            <div class="panel">
            <li id="li_900" >
               <label class="description" for="element_900">Icon Description </label>
               <div>
                  <input id="element_900" name="element_900" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_06']?>"/> 
               </div>
               <p class="guidelines" id="guide_900"><small>Description of this style icon</small></p>
            </li>
            <li id="li_901" >
               <label class="description" for="element_901">SNR Value 01 [minimum] </label>
               <input id="element_901" name="element_901" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['pm01styleurl06']?>"/> 
               <div>
                  <p class="guidelines" id="guide_901"><small>Value to apply to this SNR icon, Default is " data,==,0 "</small></p>
            </li>
            <li id="li_902" >
            <label class="description" for="element_902">Icon .PNG Link Address </label>
            <div>
            <input id="element_902" name="element_902" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_06']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
            <p class="guidelines" id="guide_902"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_06']."\">"?> </p>
            </div> 
            </li>		<li id="li_903" >
            <label class="description" for="element_903">Scale Multiplier </label>
            <div>
            <select class="element select small" id="element_903" name="element_903"> 
            <option <?php if ($setkmlarray['BCC']['scale_06'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
            <option <?php if ($setkmlarray['BCC']['scale_06'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
            </select>
            </div><p class="guidelines" id="guide_903"><small>Increases or decreases the size of the icon.</small></p> 
            </li>		<li id="li_904" >
            <label class="description" for="element_904">Color </label>
            <div>
            <select class="element select small" id="element_904" name="element_904"> 
            <option <?php if ($setkmlarray['BCC']['color_06'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
            <option <?php if ($setkmlarray['BCC']['color_06'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
            </select>
            </div><p class="guidelines" id="guide_904"><small>Colorize the icon.</small></p> 
            </li>	
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Style - 2
            </button>
            <div class="panel">
            <li id="li_910" >
               <label class="description" for="element_910">Icon Description </label>
               <div>
                  <input id="element_910" name="element_910" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_07']?>"/> 
               </div>
               <p class="guidelines" id="guide_910"><small>Description of this style icon</small></p>
            </li>
            <li id="li_911" >
               <label class="description" for="element_911">SNR Value 02 </label>
               <input id="element_901" name="element_911" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['pm01styleurl07']?>"/> 
               <div>
                  <p class="guidelines" id="guide_911"><small>Value to apply to this SNR icon, Default is " data,<=,8 "</small></p>
            </li>
            <li id="li_912" >
            <label class="description" for="element_912">Icon .PNG Link Address </label>
            <div>
            <input id="element_912" name="element_912" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_07']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
            <p class="guidelines" id="guide_912"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_07']."\">"?> </p>
            </div> 
            </li>		<li id="li_913" >
            <label class="description" for="element_913">Scale Multiplier </label>
            <div>
            <select class="element select small" id="element_913" name="element_913"> 
            <option <?php if ($setkmlarray['BCC']['scale_07'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
            <option <?php if ($setkmlarray['BCC']['scale_07'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
            </select>
            </div><p class="guidelines" id="guide_913"><small>Increases or decreases the size of the icon.</small></p> 
            </li>		<li id="li_914" >
            <label class="description" for="element_914">Color </label>
            <div>
            <select class="element select small" id="element_914" name="element_914"> 
            <option <?php if ($setkmlarray['BCC']['color_07'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
            <option <?php if ($setkmlarray['BCC']['color_07'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
            </select>
            </div><p class="guidelines" id="guide_914"><small>Colorize the icon.</small></p> 
            </li>	
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Style - 3
            </button>
            <div class="panel">
            <li id="li_920" >
               <label class="description" for="element_920">Icon Description </label>
               <div>
                  <input id="element_920" name="element_920" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_08']?>"/> 
               </div>
               <p class="guidelines" id="guide_920"><small>Description of this style icon</small></p>
            </li>
            <li id="li_921" >
               <label class="description" for="element_921">SNR Value 03 </label>
               <input id="element_921" name="element_921" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['pm01styleurl08']?>"/> 
               <div>
                  <p class="guidelines" id="guide_921"><small>Value to apply to this SNR icon Default is " data,==,16 "</small></p>
            </li>
            <li id="li_922" >
            <label class="description" for="element_922">Icon .PNG Link Address </label>
            <div>
            <input id="element_922" name="element_922" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_08']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
            <p class="guidelines" id="guide_922"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_08']."\">"?> </p>
            </div> 
            </li>		<li id="li_923" >
            <label class="description" for="element_923">Scale Multiplier </label>
            <div>
            <select class="element select small" id="element_923" name="element_923"> 
            <option <?php if ($setkmlarray['BCC']['scale_08'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
            <option <?php if ($setkmlarray['BCC']['scale_08'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
            </select>
            </div><p class="guidelines" id="guide_923"><small>Increases or decreases the size of the icon.</small></p> 
            </li>		<li id="li_924" >
            <label class="description" for="element_924">Color </label>
            <div>
            <select class="element select small" id="element_924" name="element_924"> 
            <option <?php if ($setkmlarray['BCC']['color_08'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
            <option <?php if ($setkmlarray['BCC']['color_08'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
            </select>
            </div><p class="guidelines" id="guide_924"><small>Colorize the icon.</small></p> 
            </li>	
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Style - 4
            </button>
            <div class="panel">
            <li id="li_930" >
               <label class="description" for="element_930">Icon Description </label>
               <div>
                  <input id="element_930" name="element_930" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_09']?>"/> 
               </div>
               <p class="guidelines" id="guide_930"><small>Description of this style icon</small></p>
            </li>
            <li id="li_931" >
               <label class="description" for="element_931">SNR Value 04 </label>
               <input id="element_931" name="element_931" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['pm01styleurl09']?>"/> 
               <div>
                  <p class="guidelines" id="guide_931"><small>Value to apply to this SNR icon Default is " data,<=,24 "</small></p>
            </li>
            <li id="li_932" >
            <label class="description" for="element_932">Icon .PNG Link Address </label>
            <div>
            <input id="element_932" name="element_932" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_09']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
            <p class="guidelines" id="guide_932"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_09']."\">"?> </p>
            </div> 
            </li>		<li id="li_933" >
            <label class="description" for="element_933">Scale Multiplier </label>
            <div>
            <select class="element select small" id="element_933" name="element_933"> 
            <option <?php if ($setkmlarray['BCC']['scale_09'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
            <option <?php if ($setkmlarray['BCC']['scale_09'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
            </select>
            </div><p class="guidelines" id="guide_933"><small>Increases or decreases the size of the icon.</small></p> 
            </li>		<li id="li_934" >
            <label class="description" for="element_934">Color </label>
            <div>
            <select class="element select small" id="element_934" name="element_934"> 
            <option <?php if ($setkmlarray['BCC']['color_09'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
            <option <?php if ($setkmlarray['BCC']['color_09'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
            </select>
            </div><p class="guidelines" id="guide_934"><small>Colorize the icon.</small></p> 
            </li>	
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Style - 5
            </button>
            <div class="panel">
            <li id="li_940" >
               <label class="description" for="element_940">Icon Description </label>
               <div>
                  <input id="element_940" name="element_940" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_10']?>"/> 
               </div>
               <p class="guidelines" id="guide_940"><small>Description of this style icon</small></p>
            </li>
            <li id="li_941" >
               <label class="description" for="element_941">SNR Value 05 </label>
               <input id="element_941" name="element_941" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['pm01styleurl10']?>"/> 
               <div>
                  <p class="guidelines" id="guide_941"><small>Value to apply to this SNR icon Default is " data,<=,32 "</small></p>
            </li>
            <li id="li_942" >
            <label class="description" for="element_942">Icon .PNG Link Address </label>
            <div>
            <input id="element_942" name="element_942" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_10']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
            <p class="guidelines" id="guide_942"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_10']."\">"?> </p>
            </div> 
            </li>		<li id="li_943" >
            <label class="description" for="element_943">Scale Multiplier </label>
            <div>
            <select class="element select small" id="element_943" name="element_943"> 
            <option <?php if ($setkmlarray['BCC']['scale_10'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
            <option <?php if ($setkmlarray['BCC']['scale_10'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
            </select>
            </div><p class="guidelines" id="guide_943"><small>Increases or decreases the size of the icon.</small></p> 
            </li>		<li id="li_944" >
            <label class="description" for="element_944">Color </label>
            <div>
            <select class="element select small" id="element_944" name="element_944"> 
            <option <?php if ($setkmlarray['BCC']['color_10'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
            <option <?php if ($setkmlarray['BCC']['color_10'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
            </select>
            </div><p class="guidelines" id="guide_944"><small>Colorize the icon.</small></p> 
            </li>	
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Style - 6
            </button>
            <div class="panel">
            <li id="li_950" >
               <label class="description" for="element_950">Icon Description </label>
               <div>
                  <input id="element_950" name="element_950" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['styleid_11']?>"/> 
               </div>
               <p class="guidelines" id="guide_950"><small>Description of this style icon</small></p>
            </li>
            <li id="li_951" >
               <label class="description" for="element_951">SNR Value 06 </label>
               <input id="element_951" name="element_951" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['pm01styleurl11']?>"/> 
               <div>
                  <p class="guidelines" id="guide_951"><small>Value to apply to this SNR icon Default is " data,>,32 "</small></p>
            </li>
            <li id="li_952" >
            <label class="description" for="element_952">Icon .PNG Link Address </label>
            <div>
            <input id="element_952" name="element_952" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['BCC']['iconref_11']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
            <p class="guidelines" id="guide_952"><?php echo "<img src=\"".$setkmlarray['BCC']['iconref_11']."\">"?> </p>
            </div> 
            </li>		<li id="li_953" >
            <label class="description" for="element_953">Scale Multiplier </label>
            <div>
            <select class="element select small" id="element_953" name="element_953"> 
            <option <?php if ($setkmlarray['BCC']['scale_11'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
            <option <?php if ($setkmlarray['BCC']['scale_11'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
            </select>
            </div><p class="guidelines" id="guide_953"><small>Increases or decreases the size of the icon.</small></p> 
            </li>		<li id="li_954" >
            <label class="description" for="element_954">Color </label>
            <div>
            <select class="element select small" id="element_954" name="element_954"> 
            <option <?php if ($setkmlarray['BCC']['color_11'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
            <option <?php if ($setkmlarray['BCC']['color_11'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
            </select>
            </div><p class="guidelines" id="guide_954"><small>Colorize the icon.</small></p> 
            </li>	
            </div>			
            <li class="section_dottedbreak"> </li>
            <li class="section_break">
               <h3>SNR-KML Output Files</h3>
               <p>File options for SNR KML files.</p>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Output File - 1
            </button>
            <div class="panel">
               <li id="li_53" >
                  <label class="description" for="element_53"></label>
                  <span>
                  <input id="element_53_1" name="element_53" class="element radio" type="radio" value="True" <?php if ($setkmlarray['BCC']['pm01kmloutenabled01'] == "True") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_53_1">Enabled</label>
                  <input id="element_53_2" name="element_53" class="element radio" type="radio" value="False" <?php if ($setkmlarray['BCC']['pm01kmloutenabled01'] == "False") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_53_2">Disabled</label>
                  </span> 
               </li>
               <li id="li_54" >
                  <label class="description" for="element_54">SNR No 1 - Breadcrumb Radio Slot </label>
                  <div>
                     <select class="element select medium" id="element_54" name="element_54">
                        <option value="0" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata01'] == "0") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 0</option>
                        <option value="1" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata01'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 1</option>
                        <option value="2" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata01'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 2</option>
                        <option value="3" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata01'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 3</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata01'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_54"><small>Use slot no of radio,
                     OR
                     Use all and select the frequency in the Radio Freq section. </small>
                  </p>
               </li>
               <li id="li_50" >
                  <label class="description" for="element_50">SNR No 1 - Radio Freq </label>
                  <div>
                     <select class="element select medium" id="element_50" name="element_50">
                        <option value="Auto detect" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "Auto detect") { echo " selected = \"selected\"";}else{ echo "";}?>>Auto detect</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                        <option value="2.4Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "2.4Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz</option>
                        <option value="5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz</option>
                        <option value="900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>900Mhz</option>
                        <option value="2.4Ghz,5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "2.4Ghz,5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,5.8Ghz</option>
                        <option value="2.4Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "2.4Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,900Mhz</option>
                        <option value="5.8Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata01'] == "5.8Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz,900Mhz</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_50"><small>If Breadcrumb Radio Slot = slot no , then choose Auto detect.
                     If Breadcrumb Radio Slot = All , then use selection for the required frequency.</small>
                  </p>
               </li>
               <p> <br> </p>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Output File - 2
            </button>
            <div class="panel">
               <li id="li_56" >
                  <label class="description" for="element_56"> </label>
                  <span>
                  <input id="element_56_1" name="element_56" class="element radio" type="radio" value="True" <?php if ($setkmlarray['BCC']['pm01kmloutenabled02'] == "True") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_56_1">Enabled</label>
                  <input id="element_56_2" name="element_56" class="element radio" type="radio" value="False" <?php if ($setkmlarray['BCC']['pm01kmloutenabled02'] == "False") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_56_2">Disabled</label>
                  </span> 
               </li>
               <li id="li_57" >
                  <label class="description" for="element_57">SNR No 2 - Breadcrumb Radio Slot </label>
                  <div>
                     <select class="element select medium" id="element_57" name="element_57">
                        <option value="0" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata02'] == "0") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 0</option>
                        <option value="1" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata02'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 1</option>
                        <option value="2" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata02'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 2</option>
                        <option value="3" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata02'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 3</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata02'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_57"><small>Use slot no of radio and leave Radio Freq blank ,
                     OR
                     Use all and select the frequency in the Radio Freq section. </small>
                  </p>
               </li>
               <li id="li_62" >
                  <label class="description" for="element_62">SNR No 2 - Radio Freq </label>
                  <div>
                     <select class="element select medium" id="element_62" name="element_62">
                        <option value="Auto detect" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "Auto detect") { echo " selected = \"selected\"";}else{ echo "";}?>>Auto detect</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                        <option value="2.4Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "2.4Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz</option>
                        <option value="5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz</option>
                        <option value="900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>900Mhz</option>
                        <option value="2.4Ghz,5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "2.4Ghz,5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,5.8Ghz</option>
                        <option value="2.4Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "2.4Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,900Mhz</option>
                        <option value="5.8Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata02'] == "5.8Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz,900Mhz</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_62"><small>If Breadcrumb Radio Slot = slot no , then choose Auto detect.
                     If Breadcrumb Radio Slot = All , then use selection for the required frequency.</small>
                  </p>
               </li>
               <p> <br> </p>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Output File - 3
            </button>
            <div class="panel">
               <li id="li_59" >
                  <label class="description" for="element_59"> </label>
                  <span>
                  <input id="element_59_1" name="element_59" class="element radio" type="radio" value="True" <?php if ($setkmlarray['BCC']['pm01kmloutenabled03'] == "True") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_59_1">Enabled</label>
                  <input id="element_59_2" name="element_59" class="element radio" type="radio" value="False" <?php if ($setkmlarray['BCC']['pm01kmloutenabled03'] == "False") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_59_2">Disabled</label>
                  </span> 
               </li>
               <li id="li_60" >
                  <label class="description" for="element_60">SNR No 3 - Breadcrumb Radio Slot </label>
                  <div>
                     <select class="element select medium" id="element_60" name="element_60">
                        <option value="0" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata03'] == "0") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 0</option>
                        <option value="1" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata03'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 1</option>
                        <option value="2" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata03'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 2</option>
                        <option value="3" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata03'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 3</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata03'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_60"><small>Use slot no of radio and leave Radio Freq blank ,
                     OR
                     Use all and select the frequency in the Radio Freq section. </small>
                  </p>
               </li>
               <li id="li_58" >
                  <label class="description" for="element_58">SNR No 3 - Radio Freq </label>
                  <div>
                     <select class="element select medium" id="element_58" name="element_58">
                        <option value="Auto detect" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "Auto detect") { echo " selected = \"selected\"";}else{ echo "";}?>>Auto detect</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                        <option value="2.4Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "2.4Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz</option>
                        <option value="5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz</option>
                        <option value="900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>900Mhz</option>
                        <option value="2.4Ghz,5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "2.4Ghz,5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,5.8Ghz</option>
                        <option value="2.4Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "2.4Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,900Mhz</option>
                        <option value="5.8Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata03'] == "5.8Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz,900Mhz</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_58"><small>If Breadcrumb Radio Slot = slot no , then choose Auto detect.
                     If Breadcrumb Radio Slot = All , then use selection for the required frequency.</small>
                  </p>
               </li>
               <p> <br> </p>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Output File - 4
            </button>
            <div class="panel">
               <li id="li_61" >
                  <label class="description" for="element_61"> </label>
                  <span>
                  <input id="element_61_1" name="element_61" class="element radio" type="radio" value="True" <?php if ($setkmlarray['BCC']['pm01kmloutenabled04'] == "True") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_61_1">Enabled</label>
                  <input id="element_61_2" name="element_61" class="element radio" type="radio" value="False" <?php if ($setkmlarray['BCC']['pm01kmloutenabled04'] == "False") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_61_2">Disabled</label>
                  </span> 
               </li>
               <li id="li_63" >
                  <label class="description" for="element_63">SNR No 4 - Breadcrumb Radio Slot </label>
                  <div>
                     <select class="element select medium" id="element_63" name="element_63">
                        <option value="0" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata04'] == "0") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 0</option>
                        <option value="1" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata04'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 1</option>
                        <option value="2" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata04'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 2</option>
                        <option value="3" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata04'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 3</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata04'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_63"><small>Use slot no of radio and leave Radio Freq blank ,
                     OR
                     Use all and select the frequency in the Radio Freq section. </small>
                  </p>
               </li>
               <li id="li_64" >
                  <label class="description" for="element_64">SNR No 4 - Radio Freq </label>
                  <div>
                     <select class="element select medium" id="element_64" name="element_64">
                        <option value="Auto detect" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "Auto detect") { echo " selected = \"selected\"";}else{ echo "";}?>>Auto detect</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                        <option value="2.4Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "2.4Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz</option>
                        <option value="5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz</option>
                        <option value="900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>900Mhz</option>
                        <option value="2.4Ghz,5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "2.4Ghz,5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,5.8Ghz</option>
                        <option value="2.4Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "2.4Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,900Mhz</option>
                        <option value="5.8Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata04'] == "5.8Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz,900Mhz</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_64"><small>If Breadcrumb Radio Slot = slot no , then choose Auto detect.
                     If Breadcrumb Radio Slot = All , then use selection for the required frequency.</small>
                  </p>
               </li>
               <p> <br> </p>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Output File - 5
            </button>
            <div class="panel">
               <li id="li_65" >
                  <label class="description" for="element_65"> </label>
                  <span>
                  <input id="element_65_1" name="element_65" class="element radio" type="radio" value="True" <?php if ($setkmlarray['BCC']['pm01kmloutenabled05'] == "True") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_65_1">Enabled</label>
                  <input id="element_65_2" name="element_65" class="element radio" type="radio" value="False" <?php if ($setkmlarray['BCC']['pm01kmloutenabled05'] == "False") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_65_2">Disabled</label>
                  </span> 
               </li>
               <li id="li_66" >
                  <label class="description" for="element_66">SNR No 5 - Breadcrumb Radio Slot </label>
                  <div>
                     <select class="element select medium" id="element_66" name="element_66">
                        <option value="0" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata05'] == "0") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 0</option>
                        <option value="1" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata05'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 1</option>
                        <option value="2" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata05'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 2</option>
                        <option value="3" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata05'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 3</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata05'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_66"><small>Use slot no of radio and leave Radio Freq blank ,
                     OR
                     Use all and select the frequency in the Radio Freq section. </small>
                  </p>
               </li>
               <li id="li_67" >
                  <label class="description" for="element_67">SNR No 5 - Radio Freq </label>
                  <div>
                     <select class="element select medium" id="element_67" name="element_67">
                        <option value="Auto detect" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "Auto detect") { echo " selected = \"selected\"";}else{ echo "";}?>>Auto detect</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                        <option value="2.4Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "2.4Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz</option>
                        <option value="5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz</option>
                        <option value="900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>900Mhz</option>
                        <option value="2.4Ghz,5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "2.4Ghz,5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,5.8Ghz</option>
                        <option value="2.4Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "2.4Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,900Mhz</option>
                        <option value="5.8Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata05'] == "5.8Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz,900Mhz</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_67"><small>If Breadcrumb Radio Slot = slot no , then choose Auto detect.
                     If Breadcrumb Radio Slot = All , then use selection for the required frequency.</small>
                  </p>
               </li>
               <p> <br> </p>
            </div>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >SNR Output File - 6
            </button>
            <div class="panel">
               <li id="li_51" >
                  <label class="description" for="element_51"> </label>
                  <span>
                  <input id="element_51_1" name="element_51" class="element radio" type="radio" value="True" <?php if ($setkmlarray['BCC']['pm01kmloutenabled06'] == "True") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_51_1">Enabled</label>
                  <input id="element_51_2" name="element_51" class="element radio" type="radio" value="False" <?php if ($setkmlarray['BCC']['pm01kmloutenabled06'] == "False") { echo " checked = \"checked\"";}else{ echo "";}?>/>
                  <label class="choice" for="element_51_2">Disabled</label>
                  </span> 
               </li>
               <li id="li_52" >
                  <label class="description" for="element_52">SNR No 6 - Breadcrumb Radio Slot </label>
                  <div>
                     <select class="element select medium" id="element_52" name="element_52">
                        <option value="0" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata06'] == "0") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 0</option>
                        <option value="1" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata06'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 1</option>
                        <option value="2" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata06'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 2</option>
                        <option value="3" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata06'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?>>Radio Slot 3</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutspecialdata06'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_52"><small>Use slot no of radio and leave Radio Freq blank ,
                     OR
                     Use all and select the frequency in the Radio Freq section. </small>
                  </p>
               </li>
               <li id="li_55" >
                  <label class="description" for="element_55">SNR No 6 - Radio Freq </label>
                  <div>
                     <select class="element select medium" id="element_55" name="element_55">
                        <option value="Auto detect" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "Auto detect") { echo " selected = \"selected\"";}else{ echo "";}?>>Auto detect</option>
                        <option value="All" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "All") { echo " selected = \"selected\"";}else{ echo "";}?>>All</option>
                        <option value="2.4Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "2.4Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz</option>
                        <option value="5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz</option>
                        <option value="900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>900Mhz</option>
                        <option value="2.4Ghz,5.8Ghz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "2.4Ghz,5.8Ghz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,5.8Ghz</option>
                        <option value="2.4Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "2.4Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>2.4Ghz,900Mhz</option>
                        <option value="5.8Ghz,900Mhz" <?php if ($setkmlarray['BCC']['pm01kmloutoptiondata06'] == "5.8Ghz,900Mhz") { echo " selected = \"selected\"";}else{ echo "";}?>>5.8Ghz,900Mhz</option>
                     </select>
                  </div>
                  <p class="guidelines" id="guide_55"><small>If Breadcrumb Radio Slot = slot no , then choose Auto detect.
                     If Breadcrumb Radio Slot = All , then use selection for the required frequency.</small>
                  </p>
               </li>
               <p> <br> </p>
            </div>
            <li class="section_break">
               <h3>Ping Section - General settings</h3>
               <p>Ping variables for KML output</p>
            </li>
            <li class="section_dottedbreak"> </li>
            </li>
            <button type="button" class="accordion"  >Ping Style - 1
            </button>
            <div class="panel">
               <li id="li_800" >
                  <label class="description" for="element_800">Icon Description </label>
                  <div>
                     <input id="element_800" name="element_800" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['styleid_00']?>"/> 
                  </div>
                  <p class="guidelines" id="guide_800"><small>Description of this style icon</small></p>
               </li>
               <li id="li_801" >
                  <label class="description" for="element_801">Ping Value 01 [Failed] </label>
                  <input id="element_801" name="element_801" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['pm01styleurl00']?>"/> 
                  <div>
                     <p class="guidelines" id="guide_801"><small>Value to apply to this Ping icon, Default is "100% packet loss,==,100% packet loss"</small></p>
               </li>
               <li id="li_802" >
               <label class="description" for="element_802">Icon .PNG Link Address </label>
               <div>
               <input id="element_802" name="element_802" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['iconref_00']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
               <p class="guidelines" id="guide_802"><?php echo "<img src=\"".$setkmlarray['Ping']['iconref_00']."\">"?> </p>
               </div> 
               </li>		<li id="li_803" >
               <label class="description" for="element_803">Scale Multiplier </label>
               <div>
               <select class="element select small" id="element_803" name="element_803"> 
               <option <?php if ($setkmlarray['Ping']['scale_00'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
               <option <?php if ($setkmlarray['Ping']['scale_00'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
               </select>
               </div><p class="guidelines" id="guide_803"><small>Increases or decreases the size of the icon.</small></p> 
               </li>		<li id="li_804" >
               <label class="description" for="element_804">Color </label>
               <div>
               <select class="element select small" id="element_804" name="element_804"> 
               <option <?php if ($setkmlarray['Ping']['color_00'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
               <option <?php if ($setkmlarray['Ping']['color_00'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
               </select>
               </div><p class="guidelines" id="guide_804"><small>Colorize the icon.</small></p> 
               </li>	
               </div>
               <li class="section_dottedbreak"> </li>
               </li>
               <button type="button" class="accordion"  >Ping Style - 2
               </button>
               <div class="panel">
                  <li id="li_830" >
                     <label class="description" for="element_810">Icon Description </label>
                     <div>
                        <input id="element_810" name="element_810" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['styleid_01']?>"/> 
                     </div>
                     <p class="guidelines" id="guide_810"><small>Description of this style icon</small></p>
                  </li>
                  <li id="li_811" >
                     <label class="description" for="element_811">Ping Value 02 [Maximum]</label>
                     <input id="element_811" name="element_811" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['pm01styleurl01']?>"/> 
                     <div>
                        <p class="guidelines" id="guide_811"><small>Value to apply to this Ping icon, Default is "data,>,100"</small></p>
                  </li>
                  <li id="li_812" >
                  <label class="description" for="element_812">Icon .PNG Link Address </label>
                  <div>
                  <input id="element_812" name="element_812" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['iconref_01']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
                  <p class="guidelines" id="guide_812"><?php echo "<img src=\"".$setkmlarray['Ping']['iconref_01']."\">"?> </p>
                  </div> 
                  </li>		<li id="li_813" >
                  <label class="description" for="element_813">Scale Multiplier </label>
                  <div>
                  <select class="element select small" id="element_813" name="element_813"> 
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                  <option <?php if ($setkmlarray['Ping']['scale_01'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                  </select>
                  </div><p class="guidelines" id="guide_813"><small>Increases or decreases the size of the icon.</small></p> 
                  </li>		<li id="li_814" >
                  <label class="description" for="element_814">Color </label>
                  <div>
                  <select class="element select small" id="element_814" name="element_814"> 
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                  <option <?php if ($setkmlarray['Ping']['color_01'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                  </select>
                  </div><p class="guidelines" id="guide_814"><small>Colorize the icon.</small></p> 
                  </li>	
                  </div>
               </div>
               <li class="section_dottedbreak"> </li>
               </li>
               <button type="button" class="accordion"  >Ping Style - 3
               </button>
               <div class="panel">
                  <li id="li_820" >
                     <label class="description" for="element_820">Icon Description </label>
                     <div>
                        <input id="element_820" name="element_820" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['styleid_02']?>"/> 
                     </div>
                     <p class="guidelines" id="guide_820"><small>Description of this style icon</small></p>
                  </li>
                  <li id="li_821" >
                     <label class="description" for="element_821">Ping Value 03</label>
                     <input id="element_821" name="element_821" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['pm01styleurl02']?>"/> 
                     <div>
                        <p class="guidelines" id="guide_821"><small>Value to apply to this Ping icon, Default is "data,>,60"</small></p>
                  </li>
                  <li id="li_822" >
                  <label class="description" for="element_822">Icon .PNG Link Address </label>
                  <div>
                  <input id="element_822" name="element_822" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['iconref_02']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
                  <p class="guidelines" id="guide_822"><?php echo "<img src=\"".$setkmlarray['Ping']['iconref_02']."\">"?> </p>
                  </div> 
                  </li>		<li id="li_823" >
                  <label class="description" for="element_823">Scale Multiplier </label>
                  <div>
                  <select class="element select small" id="element_823" name="element_823"> 
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                  <option <?php if ($setkmlarray['Ping']['scale_02'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                  </select>
                  </div><p class="guidelines" id="guide_823"><small>Increases or decreases the size of the icon.</small></p> 
                  </li>		<li id="li_824" >
                  <label class="description" for="element_824">Color </label>
                  <div>
                  <select class="element select small" id="element_824" name="element_824"> 
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                  <option <?php if ($setkmlarray['Ping']['color_02'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                  </select>
                  </div><p class="guidelines" id="guide_824"><small>Colorize the icon.</small></p> 
                  </li>	
                  </div>
               </div>
               <li class="section_dottedbreak"> </li>
               </li>
               <button type="button" class="accordion"  >Ping Style - 4
               </button>
               <div class="panel">
                  <li id="li_830" >
                     <label class="description" for="element_830">Icon Description </label>
                     <div>
                        <input id="element_830" name="element_830" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['styleid_03']?>"/> 
                     </div>
                     <p class="guidelines" id="guide_830"><small>Description of this style icon</small></p>
                  </li>
                  <li id="li_831" >
                     <label class="description" for="element_831">Ping Value 04 </label>
                     <input id="element_831" name="element_831" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['pm01styleurl03']?>"/> 
                     <div>
                        <p class="guidelines" id="guide_831"><small>Value to apply to this Ping icon, Default is "data,>,40</small></p>
                  </li>
                  <li id="li_832" >
                  <label class="description" for="element_832">Icon .PNG Link Address </label>
                  <div>
                  <input id="element_832" name="element_832" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['iconref_03']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
                  <p class="guidelines" id="guide_832"><?php echo "<img src=\"".$setkmlarray['Ping']['iconref_03']."\">"?> </p>
                  </div> 
                  </li>		<li id="li_833" >
                  <label class="description" for="element_833">Scale Multiplier </label>
                  <div>
                  <select class="element select small" id="element_833" name="element_833"> 
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                  <option <?php if ($setkmlarray['Ping']['scale_03'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                  </select>
                  </div><p class="guidelines" id="guide_833"><small>Increases or decreases the size of the icon.</small></p> 
                  </li>		<li id="li_834" >
                  <label class="description" for="element_834">Color </label>
                  <div>
                  <select class="element select small" id="element_834" name="element_834"> 
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                  <option <?php if ($setkmlarray['Ping']['color_03'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                  </select>
                  </div><p class="guidelines" id="guide_834"><small>Colorize the icon.</small></p> 
                  </li>	
                  </div>
               </div>
               <li class="section_dottedbreak"> </li>
               </li>
               <button type="button" class="accordion"  >Ping Style - 5
               </button>
               <div class="panel">
                  <li id="li_840" >
                     <label class="description" for="element_840">Icon Description </label>
                     <div>
                        <input id="element_840" name="element_840" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['styleid_04']?>"/> 
                     </div>
                     <p class="guidelines" id="guide_840"><small>Description of this style icon</small></p>
                  </li>
                  <li id="li_841" >
                     <label class="description" for="element_841">Ping Value 05 </label>
                     <input id="element_841" name="element_841" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['pm01styleurl04']?>"/> 
                     <div>
                        <p class="guidelines" id="guide_841"><small>Value to apply to this Ping icon, Default is "data,>,20"</small></p>
                  </li>
                  <li id="li_842" >
                  <label class="description" for="element_842">Icon .PNG Link Address </label>
                  <div>
                  <input id="element_842" name="element_842" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['iconref_04']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
                  <p class="guidelines" id="guide_842"><?php echo "<img src=\"".$setkmlarray['Ping']['iconref_04']."\">"?> </p>
                  </div> 
                  </li>		<li id="li_843" >
                  <label class="description" for="element_843">Scale Multiplier </label>
                  <div>
                  <select class="element select small" id="element_843" name="element_843"> 
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                  <option <?php if ($setkmlarray['Ping']['scale_04'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                  </select>
                  </div><p class="guidelines" id="guide_843"><small>Increases or decreases the size of the icon.</small></p> 
                  </li>		<li id="li_844" >
                  <label class="description" for="element_844">Color </label>
                  <div>
                  <select class="element select small" id="element_844" name="element_844"> 
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                  <option <?php if ($setkmlarray['Ping']['color_04'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                  </select>
                  </div><p class="guidelines" id="guide_844"><small>Colorize the icon.</small></p> 
                  </li>	
                  </div>
               </div>
               <li class="section_dottedbreak"> </li>
               </li>
               <button type="button" class="accordion"  >Ping Style - 6
               </button>
               <div class="panel">
                  <li id="li_850" >
                     <label class="description" for="element_850">Icon Description </label>
                     <div>
                        <input id="element_850" name="element_850" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['styleid_05']?>"/> 
                     </div>
                     <p class="guidelines" id="guide_850"><small>Description of this style icon</small></p>
                  </li>
                  <li id="li_851" >
                     <label class="description" for="element_851">Ping Value 06 [minimum] </label>
                     <input id="element_851" name="element_851" class="element text small" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['pm01styleurl05']?>"/> 
                     <div>
                        <p class="guidelines" id="guide_851"><small>Value to apply to this Ping icon, Default is " data,>,0 "</small></p>
                  </li>
                  <li id="li_852" >
                  <label class="description" for="element_852">Icon .PNG Link Address </label>
                  <div>
                  <input id="element_852" name="element_852" class="element text large" type="text" maxlength="255" value="<?php echo $setkmlarray['Ping']['iconref_05']?>"<p> <a href="http://kml4earth.appspot.com/icons.html" target="_blank"><small>More?</small></a></p> 
                  <p class="guidelines" id="guide_852"><?php echo "<img src=\"".$setkmlarray['Ping']['iconref_05']."\">"?> </p>
                  </div> 
                  </li>		<li id="li_853" >
                  <label class="description" for="element_853">Scale Multiplier </label>
                  <div>
                  <select class="element select small" id="element_853" name="element_853"> 
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == ".25") { echo " selected = \"selected\"";}else{ echo "";}?> value=".25" >.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == ".5") { echo " selected = \"selected\"";}else{ echo "";}?> value=".5" >.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == ".75") { echo " selected = \"selected\"";}else{ echo "";}?> value=".75" >.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == "1") { echo " selected = \"selected\"";}else{ echo "";}?> value="1" >1</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == "1.25") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.25" >1.25</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == "1.5") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.5" >1.5</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == "1.75") { echo " selected = \"selected\"";}else{ echo "";}?> value="1.75" >1.75</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == "2") { echo " selected = \"selected\"";}else{ echo "";}?> value="2" >2</option>
                  <option <?php if ($setkmlarray['Ping']['scale_05'] == "3") { echo " selected = \"selected\"";}else{ echo "";}?> value="3" >3</option>
                  </select>
                  </div><p class="guidelines" id="guide_853"><small>Increases or decreases the size of the icon.</small></p> 
                  </li>		<li id="li_854" >
                  <label class="description" for="element_854">Color </label>
                  <div>
                  <select class="element select small" id="element_854" name="element_854"> 
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff000000" >Black</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "ff0000ff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff0000ff" >Red</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "ff00aaff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00aaff" >Orange</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "ff00ffff") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff00ffff" >Yellow</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "ff01ff91") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff01ff91" >Light Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "ff7b9d2b") { echo " selected = \"selected\"";}else{ echo "";}?> value="ff7b9d2b" >Green</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "50F0F014") { echo " selected = \"selected\"";}else{ echo "";}?> value="50F0F014" >Light Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "80ff0000") { echo " selected = \"selected\"";}else{ echo "";}?> value="80ff0000" >Blue</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "50780078") { echo " selected = \"selected\"";}else{ echo "";}?> value="50780078" >Violet</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "50A078F0") { echo " selected = \"selected\"";}else{ echo "";}?> value="50A078F0" >Pink</option>
                  <option <?php if ($setkmlarray['Ping']['color_05'] == "50969696") { echo " selected = \"selected\"";}else{ echo "";}?> value="50969696" >Grey</option>
                  </select>
                  </div><p class="guidelines" id="guide_854"><small>Colorize the icon.</small></p> 
                  </li>	
                  </div>
                  <li class="section_dottedbreak"> </li>
                  <p><br><br></p>
                  <li class="buttons">
                     <input type="hidden" name="form_id" value="14872" />
                     <input id="saveForm" class="button_text" type="submit" name="postfullform" value="Submit" />
                     <input type="hidden" name="destination" value="<?php echo $_SERVER["REQUEST_URI"]; ?>"/>
                     <p><br><br></p>
                     <a href='http://127.0.0.1/~mst/scriptbuilder.php?filename=kmlset_default (original backup).ini'>Click here to load the default values to this form?</a>
                     <p><br></p>
                  </li>
               </div>
         </ul>
      </form>
      <div id="footer">
      Generated by <a href="http://www.phpform.org">pForm</a> , then altered and improved.
      </div>
      </div>
      <img id="bottom" src="bottom.png" alt="">
      <?php } ?>
      <script>
         var acc = document.getElementsByClassName("accordion");
            
         	var i;
         
         for (i = 0; i < acc.length; i++) {
           acc[i].addEventListener("click", function() {
             this.classList.toggle("active");
             var panel = this.nextElementSibling;
             if (panel.style.maxHeight){
               panel.style.maxHeight = null;
             } else {
               panel.style.maxHeight = panel.scrollHeight + "px";
             } 
           });
         }
      </script>
   </body>
</html>

<html>
  <?php 
function remote_file_exists($url){
 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_NOBODY, true);
 curl_exec($ch);
 $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
 curl_close($ch);
 if( $httpCode == 200 ){return true;}
 return false;
}
function is_connected($url)
 {
 $connected = @fsockopen($url, 80); 
 //website, port  (try 80 or 443)
 if ($connected){
  $is_conn = true; //action when connected
  fclose($connected);
 }else{
  $is_conn = false; //action in connection failure
 }
 return $is_conn;
}

#DEFINE VARS HERE FOR VERSIONS , EACH TIME A NEW UPDATE IS MADE THESE NEED TO CHANGE
$inturlcheck="www.google.com";
$urltext="https://raw.githubusercontent.com/camjonesau/cc2kml/master/updatev1.02.txt";
$urlget="https://raw.githubusercontent.com/camjonesau/cc2kml/master/updatev1.02.tar.gz";
$urlpost=$urlget;

if (!is_connected($inturlcheck)){
 ?>
   <p style="width: 70%;margin: auto;margin-top: 5%;font-size:larger;text-align:center">
     Must be connected to the internet to check for updates , connect to the internet and refresh page to try again.
   </p>
   <?php
}else{
 ?>
   <?php
 if ($_SERVER['REQUEST_METHOD'] == 'POST'){
  if(file_exists(getcwd()."/update")) {
   echo " file exists";
   ?>
   <p style="width: 70%;margin: auto;font-size: bigger;text-align: center;position: fixed;top: 0;background: #fff;">
    <br><br><br><br>
    Request completed.
    <br> Reboot required for changes to take effect.
    <br>
    <br>
    Source: 
    <a href="https://github.com/camjonesau" target="_blank" style="color:#f60;text-decoration:none;"><?php echo $urlpost; ?>
    </a>
    <br>
    Destination:<?php echo getcwd().'/update';?>
    <br>
    Size:<?php echo filesize(getcwd().'/update') . ' bytes';?> 
    <br>
  </p>
  <?php
  }else{
  ?>	

   <p style="width: 70%;margin: auto;font-size: bigger;text-align: center;position: fixed;top: 0;background: #fff;">
    <br><br><br><br>
    ERROR no file , go back and check connection and re-download.
    <br>
   </p>
  <?php
  }
  ?>

  <?php
 }else{
  if (remote_file_exists($urltext)) {
   #echo "cool file $urltext exists\n";
   ?>
   <p style="width: 70%;margin: auto;margin-top: 5%;font-size:larger;text-align:center">
     A new version is available from Github.
     <br>
     <?php echo "\nFile=>$urlget\n" ?>
     <br>
     <br>
     <br>
     Notes and bug fixes:
    <br>
     <?php echo file_get_contents("$urltext");?>
     <br>
     <?php
   # if (false!==file($url1)) echo "Wow!\n";
  }else{
    echo "missing $urlpost \n";
  }
 #	echo file_get_contents("$urlcheck")"\n";
 ?>
 <p>
 <form method="post" style="width: 70%;margin: auto;margin-top: 10%;">
    [Watch status bar below ,once download is started it maytake 30- 60 secs depending on internet speed]
    <input name="submit" type="submit" value="Download" style="width: 30%;height: 10%;margin: 5% auto; display: block;">
    <input name="urlpost" size="8" placeholder="Source URL" style="width: 100%;height: 5%;font-size: 1em;padding:10px" value="<?php echo "$urlget" ?>" required>
    </p>
  <p style="width: 70%;margin: auto;margin-top: 10%;font-size:smaller;text-align:center">
 </form>

<?php
 }
?>

<?php
if (!isset($_POST['submit'])) die();
// folder to save downloaded files to. must end with slash
$destination_folder = '';
$url = $_POST['urlpost'];
#$newfname = $destination_folder . basename($url);
$newfname = $destination_folder . "update";

file_put_contents( $newfname, fopen($url, 'r'));
#if(file_exists($url)) {
#file_put_contents( $newfname, fopen($url, 'r'));
#}

#<?php
#from check internet at top
}
?>
</html>


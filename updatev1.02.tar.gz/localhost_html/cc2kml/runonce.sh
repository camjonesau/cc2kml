#!/bin/bash

kdialog --warningcontinuecancel 'Software update required. Connect to the internet before continuing'
#$? is answer 0 = yes or 2 = cancel
if [ "$?" = "0" ]
 then
 #wget https://dl.google.com/dl/earth/client/current/google-earth-stable_current_i386.deb
 #sudo dpkg -i google-earth-stable*.deb
 #sudo apt-get -f install -y
 #sudo dpkg -i google-earth-stable*.deb
clear
echo " "
echo "sudo pass = mst123"
echo " "
sudo apt-get update
sudo apt-get purge google-chrome-stable -y
sudo apt-get install crudini -y
echo "chmod 777 -R /home/mst/localhost_html" |sudo tee -a /usr/bin/updatecc2kml.sh
sudo echo "#description \"update cc2kml\"" >/home/mst/.config/upstart/cc2kml.conf
sudo echo "start on desktop-start" >>/home/mst/.config/upstart/cc2kml.conf
sudo echo "script" >>/home/mst/.config/upstart/cc2kml.conf
sudo echo "exec bash /usr/bin/updatecc2kml.sh" >>/home/mst/.config/upstart/cc2kml.conf
sudo echo "sudo chmod 777 -R /home/mst/localhost_html" >>/home/mst/.config/upstart/cc2kml.conf
sudo echo "exec bash /home/mst/localhost_html/cc2kml/runonce.sh" >>/home/mst/.config/upstart/cc2kml.conf
sudo echo "end script" >>/home/mst/.config/upstart/cc2kml.conf

sudo chmod 777 /home/mst/.config/upstart/cc2kml.conf


sudo cp /home/mst/localhost_html/cc2kml/gpsd /etc/default/gpsd
echo "******************************************"
echo "step 1 of 8"
sleep 3
dpkg --list 'google-earth*'
echo "******************************************"
echo "step 2 of 8"
sleep 3
sudo dpkg -P google-earth-pro-stable
echo "******************************************"
echo "step 3 of 8"
sleep 3
sudo apt-get install googleearth-package -y
echo "******************************************"
echo "step 4 of 8"
sleep 3
make-googleearth-package --force
echo "******************************************"
echo "step 5 of 8"
sleep 3
 sudo dpkg -i googleearth_6.0.3.2197+1.2.0-1_i386.deb
echo "******************************************"
echo "step 6 of 8"
sleep 3
 sudo apt-get -f install -y
echo "******************************************"
echo "step 7 of 8"
sleep 3
 sudo dpkg -i googleearth_6.0.3.2197+1.2.0-1_i386.deb
echo "******************************************"
echo "step 8 of 8"
sleep 3
 cp /home/mst/localhost_html/cc2kml/runonce.sh /home/mst/localhost_html.tar.gz
 mv /home/mst/localhost_html/cc2kml/runonce.sh "/home/mst/localhost_html/cc2kml/runonce.sh.backup.$(date +"%Y%m%d.%H%M%S")"
fi
echo "Finished ... [esc]"


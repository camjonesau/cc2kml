echo started bcclp_read.sh
echo user is $USER
echo project name is $1
echo pipefile name is $2


pipefilename=$2
if [ $1 == '' ] ; then 
 projname = 'default'
 mkdir $1
 echo no project name assigned , project name is now $projname
else
 projname=$1
fi


LOGNAME="$(date "+%Y%m%d%H%M")_$pipefilename.log"
OLDNAME=$LOGNAME
echo bcclp_read now writing to "$LOGNAME"

echo sleeping 3
sleep 3

while :
do

 read pipereadline<$pipefilename
 LOGNAME="$(date "+%Y%m%d%H%M")_"$pipefilename".log"

if [ $pipefilename == 'bcclp' ] ; then
	#echo "$pipereadline"
	#echo "$pipereadline"|awk 'BEGIN {FS = ","}; {if ($3 =="A") {print $2","$4","$5","$6","$7} else {print "ERROR,No LAT,,No LON,"}}'

	#save coords from redis to $tmp
 	tmp=$(/opt/redis-4.0.6/redis-4.0.6/src/redis-cli get coords.string)

	newpipereadline=""

	#inset tmp/gps data into every line if its is a date string ... inside if is regex , and replacement date example is awk -v dt="$date" 'BEGIN{FS=OFS=","}{$1=dt}1' inputFile
	newpipereadline=$(echo "$pipereadline"|stdbuf -o0 awk -v gps="$tmp" -W interactive 'BEGIN{FS=OFS=" "}{if ($1 ~ /^[0-9][0-9]:[0-9][0-9]:[0-9][0-9]\.[0-9][0-9][0-9]/) {$2=gps" "$2;print $0} else {exit 0}}')
	
	#debug output
	#echo "@=$newpipereadline"
	#echo "#=$pipereadline"
	#echo " "
	#sleep 1
	if [[ ! -z "$newpipereadline" ]]; then #we have a newline with datestamp
		##output built send alteredpipereadline to file after checking for good content and reset its new value for next new line
		finalstr=''
		#this filters out the crap we dont need		
		finalstr=$(echo "$alteredpipereadline"|grep -E "mac:|INFO com.rajant.bcc.app.BCCApp|macs:|gpsTime")
		if [ "$finalstr" != '' ] ; then
			#if not null then output the line to file
			printf "%s\n" "$alteredpipereadline" >> "$projname"/"$LOGNAME"
		fi
		alteredpipereadline=$newpipereadline
	else
		#remove newlines due to stupid layout of bccommander
		alteredpipereadline="$alteredpipereadline"$(echo "$pipereadline"|tr '\n' '^')
	fi
	


	#line below worked but on every line ie CR and LF
	#pipereadline=$(echo "$pipereadline"|stdbuf -o0 awk -W interactive -v dt="$tmp" 'BEGIN{FS=OFS=" "}{$2=dt" "$2}1')

	#echo "$alteredpipereadline"
else
	#normal print to file from ping command or other command
	printf "%s\n" "$pipereadline" >> "$projname"/"$LOGNAME"


fi




# if [ $pipefilename == 'gps' ] ; then
#	#"split out data for coords file for insertion into ping etc files"
# fi
if [ $pipefilename == 'gps' ] ; then
	#echo "################# $pipefilename ################3"
	#echo "$pipereadline"
	#echo "$pipereadline"|awk 'BEGIN {FS = ","}; {if ($3 =="A") {print $2","$4","$5","$6","$7} else {print "GPS read ERROR,,,,"}}'
	gps_string=$(echo "$pipereadline"|awk 'BEGIN {FS = ","}; {if ($3 =="A") {print $2","$4","$5","$6","$7} else {print "GPS read ERROR,"$4","$5","$6","$7}}')
	
	#/opt/redis-4.0.6/redis-4.0.6/src/redis-cli set coords.string "$gps_string"| sed -e 's/^/redis is = /'
	result=$(/opt/redis-4.0.6/redis-4.0.6/src/redis-cli set coords.string "$gps_string")
	if [ "$result" != "OK" ] ; then
		echo "Error Redis server is NOT OK result=$result" 
	fi
# what the  ?
#awk 1 ORS=' '
	#echo GPSSTRING="$gps_string"


	#	echo "$(date '+%H:%M:%S.%3N') NOTE... Error invalid GPS coordinates"
fi



 if [ $OLDNAME != $LOGNAME ] ;	then 
	FILESIZE=$(stat -c%s "$projname""/""$OLDNAME")
	FILESIZE=$(($FILESIZE+512))
	FILESIZE=$(($FILESIZE/1024))
	echo bcclp_read now writing to $LOGNAME , last file size was $FILESIZE KB
	OLDNAME=$LOGNAME
 fi

done < $pipefilename

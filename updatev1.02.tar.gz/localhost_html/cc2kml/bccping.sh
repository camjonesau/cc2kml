#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |tr '\n' ' '|sed 's/[0-9][0-9]:[0-9][0-9]:/\'$'\n&/g'|grep -E  'gps|mac'>logwatch1.txt
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |awk '{ printf "%s,",$0 }'
echo ping destination is $1
echo ping pipe file is $2
rm $2
mkfifo $2
#rm ping1tail
#mkfifo ping1tail
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all >"$(date "+%Y%m%d%H%M")_bccl.log"
echo now pinging to $1
#bash readfifo_ping1.sh
while :
do

 tmp=$(/opt/redis-4.0.6/redis-4.0.6/src/redis-cli get coords.string)
# ping -c 1 -t 1 -w 1 $1 2>&1 | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'"$tmp"'! {}'|grep -E 'ms'|tee $2 2>&1 
ping -c 1 -t 255 -w 1 $1 2>&1| xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'"$tmp"'! {}'|grep -E 'ms|unreachable' |tee $2 2>&1 
sleep 0.8
done

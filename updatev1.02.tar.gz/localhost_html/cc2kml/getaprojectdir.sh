#!/bin/bash
#set the script to fail if any errors
`kdialog --title "Select an NEW project directory - Highly recommend the internal harddrive due to buffer overflow of USB flash ...." --getexistingdirectory .`
	

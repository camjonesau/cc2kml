#!/bin/bash
#set the script to fail if any errors

#version Notes
# 1.00 prototype proof of concept
Version="1.00"

#run with the command below via a terminal shell
# >stdbuf -o0 bash bc_controller.sh



#if [ yes != "$STDBUF" ]; then
#    STDBUF=yes /usr/bin/stdbuf -i0 -o0 -e0 "$0"
#    exit $?
#fi

echo $PWD>workingdir
workingdir=$PWD
echo $workingdir

#Dthis example strips one directory back for project master file
#export DIR=${workingdir%/*}
#echo "${DIR}"
#sleep 5

checkpgrep(){
if ! pgrep -x "$1" >>tmp.txt # /dev/null 
then
 echo "Script $1 is NOT running">>tmp.txt
else
 echo "Script $1 is running">>tmp.txt
fi

}

startrediscli(){
(/opt/redis-4.0.6/redis-4.0.6/src/redis-server | sed -e 's/^/[RedisSrv] /'| grep -E 'Running|Ready|Error|ERROR|refused' &)
sleep 1
checkpgrep redis-server

(/opt/redis-4.0.6/redis-4.0.6/src/redis-cli "ping" | sed -e 's/^/[RedisPng] /' &)
sleep 1
checkpgrep redis-cli
}



startbccapps(){
(./bccl.sh "$projname" | sed -e 's/^/[BCCommdr] /' &)
checkpgrep bccl.sh
(./bccpipe_read.sh "$projname" bcclp| sed -e 's/^/[BCCPRead] /' &)
checkpgrep bccpip_read.sh
}
# note & at the end make the process run and continue with more commands


startping1apps(){
(./bccping.sh "$pingip1" ping1 | sed -e 's/^/[PngPrime] /'| grep -E '100%|unreachable|:05\.|:15\.|:25\.|:35\.|:45\.|:55\.' &)
checkpgrep bccping.sh
(./bccpipe_read.sh "$projname" ping1| sed -e 's/^/[PPriRead] /' &)
checkpgrep bccpipe_read.sh
}

startping2apps(){
(./bccping.sh "$pingip2" ping2 | sed -e 's/^/[PngSecon] /'| grep -E '100%|unreachable|:10\.|:20\.|:30\.|:40\.|:50\.|:00\.' &)
checkpgrep bccping.sh
(./bccpipe_read.sh "$projname" ping2| sed -e 's/^/[PSecRead] /' &)
checkpgrep bccpipe_read.sh
}
startgpsapps(){
(./bccgps.sh "$tty" gps | sed -e 's/^/[GPSMontr] /'| grep -E 'error|ERROR' &)
#(stdbuf -o0 ./bccgps.sh "$tty" gps | sed -e 's/^/[GPSMontr  all data] /')

checkpgrep bccgps.sh
(./bccpipe_read.sh "$projname" gps| sed -e 's/^/[GPSPRead] /' &)
checkpgrep bccpipe_read.sh
}
finaliseproject(){
(./bcc_sort_pack_move.sh "$projname" &)
}


valid_ip()
{
# Check if IP format is num.num.num.num / num between 0..255
if [ "$(sipcalc $1 | grep ERR)" != "" ]; then
 #echo "ip incorrect"
 ping -q -c5 $1 > /dev/null
 if [ $? -eq 0 ]
 then
	echo "ok host is up ping successful"
 else
	echo "ok host is DOWNl"
 fi
ping -c 3 $1
return 1
fi
#echo "ip correct"
return 0
}


test_ip()
{
#./ping.sh $1
echo ""
echo -e "${GREEN}"
echo "quick test of $1"
echo " " 
ping -c 3 $1
echo " "
echo -e "${NC}"
#bccping.sh $1
}
#green
#echo -e "\e[32m"
#backtowhite
#echo -e "\e[0m"

checksettingsfile()
{
settingsfile="$projname/settings.txt"

clear
echo "#######################################"
echo
echo "Project name is '$projname'"
echo
while IFS= read -r line
do
#if $line of text from file contains a '=' then it is a set command and not a comment
if grep -q = <<<$line; then
	#if line contains our info string we want, set the appropriate value
	#split the string ito 2 vars via '=' character [second = is the character]
	IFS== read var1 var2 <<< $line
	#if var1 contains then echo to trim leading space into variable for checking Set? later
	if [ "$var1" = "Breadcrumb collection " ] ;then  Setbc=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "Breadcrumb IP " ] ;then  Setbcip=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "Ping primary device is " ] ;then  Setp1=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "Ping primary device description " ] ;then  Setpd=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "Primary device IP is " ] ;then  Setip1=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "Ping secondary device is " ] ;then  Setp2=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "Ping secondary device description " ] ;then  Setsd=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "Secondary device IP is " ] ;then  Setip2=$(echo $var2) ;echo $line; fi
	if [ "$var1" = "USB GPS collection is " ] ;then  Setgps=$(echo $var2) ;echo $line; fi
#	if [ "$var1" = "USB GPS collection is " ] ;then  Setgps=$(echo $var2) ;echo "setgps=$Setgps" echo $line; fi
#commented out line above used to show how to troubleshoot var via echo


fi

done < "$settingsfile"
echo " "
echo "#######################################"
}



echo starting cc2kmlcollector.sh
./runonce.sh
clear


#color for errors in red ,  normal = no color
RED='\033[0;31m'
YELLOW='\033[0;33m'
GREEN='\033[0;32m'
BLUE='\033[1;34m'
GREY='\033[0;37m'
NC='\033[0m' # No Color

#kill all other processes containing name with 'bcc'
pkill -f -c bcc

#setup trap to close subshells containing pings etc
trap 'kill %1; kill %2' SIGINT
#clear screen
clear

PS3="Please enter your choice using the numbers above: `echo $'\n> '`"
options=("Start New Project" "Add to Existing Project" "Quit")

#exit on any error :O)
#set -e


select opt in "${options[@]}"
do
    case $opt in
        "Start New Project")
		###########################
		#cd $projname for easy dir selection
		#projname=cat lastproject
		projname="$(<lastproject)"
		#cd $(echo "$projname" | tr -d '\r')
		#cd "$(echo "$projname")"
		export DIR="${projname%/*}"
		#echo "${DIR}"
		#sleep 5
		cd "$(echo "$DIR")"

		

		echo " "
		echo "Selected -New Project-"
		echo
             	echo "Enter new project directory" 

projname=`kdialog --title "Select an NEW project directory - Highly recommend the internal harddrive due to buffer overflow of USB flash ...." --getexistingdirectory .`
#hashed out next line tempry to test Kdialog
		
		#echo project is "$projname"
		#echo $?
		#sleep 5
		# if Projname= null empty 		
		if [ -z "$projname" ]; then 
			echo "No folder selected , exiting script"
			sleep 5			
			exit
		fi
		if [ ! -d "$projname" ] ; then
			mkdir "$projname"
			histtxt="$histtxt \nNew project created '$projname'"
			histtxt="$histtxt \nProject Name = '$projname'"
 		else
			clear
			echo " "
			
			echo -e "${GREEN}"
			echo directory is [ "$projname" ]
			echo " "
			ls "$projname" >projdirtxt
			lsdir=$(cat projdirtxt)
			echo " "
			if [ -z "$lsdir" ]
			then
				echo "cool directory is empty"				
				echo -e "${NC}"
				clear

			else

				echo -e "${YELLOW}"
				echo "dir contents ="
				echo "$lsdir"
				echo " "
				echo "Selected folder is $projname"
				echo "WARNING .... Directory contents is NOT empty, use this directory anyway   [y/n]  !"
				echo -e "${NC}"
	 			read deletedir 
				case $deletedir in
					[yY])
						#echo "User said yes."
						#rm -rf "$projname"
						histtxt="\nExisting Project directory with files used as a new project '$projname'"
						#mkdir "$projname"
						#echo $projname>lastproject
						#histtxt="$histtxt \nNew project created is '$projname'"
						#histtxt="$histtxt \nProject Name = '$projname'"
						#sleep 2
	    				;;
					*)
						#echo "User said no."
						echo "exiting script"
						sleep 3
						exit
	    				;;
				esac
			fi
			

			#if [ $deletedir == 'y' ] ; then
			#	rm -rf "$projname"
			#	histtxt="\nProject directory removed was '$projname'"
#
#			#else
#			#	clear
#			#fi
	 		#mkdir "$projname"
			#echo $projname>lastproject
			#histtxt="$histtxt \nNew project created is '$projname'"
			#histtxt="$histtxt \nProject Name = '$projname'"
		fi
		# change back to working dir
		#tempvaldir=$(<workingdir)
		#cd $(echo $tempvaldir | tr -d '\r')
		cd "$workingdir"

		echo $projname>lastproject

		#echo -e $projecttxt
		break
            ;;
        "Add to Existing Project")
		echo " "
		echo "Selected -Adding to Existing Project-"
		echo
		  # test for any directories first to capture scinario of no projects yet
		  #list directories and send all info errors to null [was 2> /dev/null for errors only]
		(ls -d */) > /dev/null 2> /dev/null
		 #if last command failed $? not equal to 0  then 
		if [[ $? != 0 ]]; then
    			echo "No existing projects."
		else
		
		printf "Please select an EXISTING project folder :\n"
		#select a folder form the current directory into $projname , if invalid break anyhow and test later

		#changing dir to keep project folders together and faster selection
		export DIR="${projname%/*}"
		#echo "${DIR}"
		#sleep 5
		cd "$(echo "$DIR")"
		projname=`kdialog --title "Select an EXISTING project directory - needs to contain a settings.txt file ...." --getexistingdirectory .`
		cd "$workingdir"
		settingsfile="$projname/settings.txt"
		if [ -f "$settingsfile" ]; then
			echo good project name "$projname"
			histtxt="$histtxt \nExisting project selected was'$projname'"
			checksettingsfile
				echo -e "${blue}$restoredsettings${NC}"
				echo " "
				echo "Do you want to 'quick load' last collection settings above from this project? [y/n] \?"
				read qyn
 				qyn=${qyn,,}    # tolower
				if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
				#if [ $qyn == 'y' ] ; then
					echo -e "settings recovered $settingsfile"
					restoresettings="y"
				else
					restoresettings="n"

					echo " "
					echo "Do you want to reset the collection settings for this project? [y/n] \? "
					read qyn
 					qyn=${qyn,,}    # tolower
					if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
						#if [ $qyn == 'y' ] ; then
						echo -e "please reconfigure settings ... "
						restoresettings="reset"
						echo " "

						Setbc=""
						Setbcip=""
						Setp1=""
						Setpd=""
						Setip1=""
						Setp2=""
						Setsd=""
						Setip2=""
						Setgps=""

					else
						restoresettings="n"
						echo " "
						echo "Quitting now ..."
						sleep 5
						exit
					fi



				fi
			break
		else
			#should get here with invalid entry on existing project choice 2 or/too change user mind of existing project
				if [ -z "$projname" ]
				then
					echo " "
					echo "cancelled/nothing selected, quitting script now . . ."
					sleep 10
					exit
				else
					echo " "
					echo "$projname"
					echo -e "${YELLOW}WARNING No settings.txt file found , directory possibly NOT a project folder. Quitting now ${NC}"
					echo " "
					sleep 6
					exit
				fi
		fi
		fi
		

            ;;
        "Select Master Storage Directory")
            	finaliseproject
            ;;
        "Quit")
            exit
            ;;
        *) echo "invalid option , use keys 1-3";;
    esac
done

#if restoring a settings file from a directory and selecting n then redo the settings AND do it if new directory 

if [ "$restoresettings" != "y" ];then
if [ "$Setbc" == "" ];then
 echo " "
 echo Did you want to collect breadcrumb data [y/n] \?
 read qyn
 qyn=${qyn,,}    # tolower
 if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
# if [ $qyn == 'y' ] ; then
	crumbyn='y'
	echo " "
	tmp=$(<BreadcrumbIP.txt)
 	read -e -p "Enter Breadcrumb IP address to track as shown in BCCommander: " -i $tmp BreadcrumbIP
	if valid_ip $BreadcrumbIP; then 
	 echo " "
	 echo $BreadcrumbIP>BreadcrumbIP.txt
	 projecttxt="$projecttxt \nBreadcrumb collection = ON"
	 projecttxt="$projecttxt \nBreadcrumb IP = $BreadcrumbIP"
	else
	 echo bad ip
	 tmp=$(<BreadcrumbIP.txt)
 	 read -e -p "2nd attempt.. Enter Breadcrumb IP address to track as shown in BCCommander: " -i $tmp BreadcrumbIP
	 if valid_ip $BreadcrumbIP; then 
	  echo " "
	  echo $BreadcrumbIP>BreadcrumbIP.txt
	  projecttxt="$projecttxt \nBreadcrumb collection = ON"
	  projecttxt="$projecttxt \nBreadcrumb IP = $BreadcrumbIP"
	 else
	  echo bad ip
	  tmp=$(<BreadcrumbIP.txt)
 	  read -e -p "Last attempt... Enter Breadcrumb IP address to track as shown in BCCommander: " -i $tmp BreadcrumbIP
	  if valid_ip $BreadcrumbIP; then 
	   echo " "
	   echo $BreadcrumbIP>BreadcrumbIP.txt
	   projecttxt="$projecttxt \nBreadcrumb collection = ON"
	   projecttxt="$projecttxt \nBreadcrumb IP = $BreadcrumbIP"
	  else
	   echo bad ip
	   exit
	  fi
         fi
	fi


 else
	crumbyn='n'
	projecttxt="$projecttxt \nBreadcrumb collection = OFF"
 fi
fi

if [ "$Setp1" == "" ];then
 echo " "
 echo Did you want to ping to a primary ip [y/n] \?
 read qyn
 qyn=${qyn,,}    # tolower
 if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
# if [ $qyn == 'y' ] ; then
	ping1yn='y'
	echo " "
 	echo Description of the target device  eg. Server via ethernet.
 	read ping1desc
	tmp=$(<pingip1.txt)
	echo " "
 	read -e -p "Enter the IP address of primary device:  `echo $'\n> '`" -i $tmp pingip1
	test_ip $pingip1
	if valid_ip $pingip1; then 
	 echo " "
	 echo $pingip1>pingip1.txt
	projecttxt="$projecttxt \nPing primary device is = ON"
	projecttxt="$projecttxt \nPing primary device description = $ping1desc"
	projecttxt="$projecttxt \nPrimary device IP is = $pingip1"
	else
	 echo bad ip
	 tmp=$(<pingip1.txt)
 	 read -e -p "2nd attempt.. Enter the IP address of primary device: " -i $tmp pingip1
	 if valid_ip $pingip1; then 
	  echo " "
	  echo $pingip1>pingip1.txt
	projecttxt="$projecttxt \nPing primary device is = ON"
	projecttxt="$projecttxt \nPing primary device description = $ping1desc"
	projecttxt="$projecttxt \nPrimary device IP is = $pingip1"
	 else
	  echo bad ip
	  tmp=$(<pingip1.txt)
 	  read -e -p "Last attempt... Enter the IP address of primary device: " -i $tmp pingip1
	  if valid_ip $pingip1; then 
	   echo " "
	   echo $pingip1>pingip1.txt
	projecttxt="$projecttxt \nPing primary device is = ON"
	projecttxt="$projecttxt \nPing primary device description = $ping1desc"
	projecttxt="$projecttxt \nPrimary device IP is = $pingip1"
	  else
	   echo bad ip
	   exit
	  fi
         fi
	fi

 else
	ping1yn='n'
	projecttxt="$projecttxt \nPing primary device is = OFF"
 fi
fi

if [ "$Setp2" == "" ];then
 echo " "
 echo "Did you want to ping secondary device ip [y/n] \?"
 read qyn
 qyn=${qyn,,}    # tolower
 if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
# if [ $qyn == 'y' ] ; then
	ping2yn='y'
	echo " "
 	echo "Description of the target device and path i.e. 'Legacy network server'."
 	read ping2desc
	tmp=$(<pingip2.txt)
	echo " "
 	read -e -p "Enter the IP address of secondary device:  `echo $'\n> '`" -i $tmp pingip2
	if valid_ip $pingip2; then 
	 echo " "
	 echo $pingip2>pingip2.txt
	projecttxt="$projecttxt \nPing secondary device is = ON"
	projecttxt="$projecttxt \nPing secondary device description = $ping2desc"
	projecttxt="$projecttxt \nSecondary device IP is = $pingip2"

	else
	 echo bad ip
	 tmp=$(<pingip2.txt)
 	 read -e -p "2nd attempt.. Enter the IP address of secondary device: " -i $tmp pingip2
	 if valid_ip $pingip2; then 
	  echo " "
	  echo $pingip2>pingip2.txt
	projecttxt="$projecttxt \nPing secondary device is = ON"
	projecttxt="$projecttxt \nPing secondary device description = $ping2desc"
	projecttxt="$projecttxt \nSecondary device IP is = $pingip2"
	 else
	  echo bad ip
	  tmp=$(<pingip2.txt)
 	  read -e -p "Last attempt... Enter the IP address of secondary device: " -i $tmp pingip2
	  if valid_ip $pingip2; then 
	   echo " "
	   echo $pingip2>pingip2.txt
	projecttxt="$projecttxt \nPing secondary device is = ON"
	projecttxt="$projecttxt \nPing secondary device description = $ping2desc"
	projecttxt="$projecttxt \nSecondary device IP is = $pingip2"
	  else
	   echo "bad ip"
	   exit
	  fi
         fi
	fi
 else
	ping2yn='n'
	projecttxt="$projecttxt \nPing secondary device is = OFF"
 fi
fi

if [ "$Setgps" == "" ];then
 echo " "
 echo "Is USB gps plugged in [y/n] \?"
 read qyn
 

 #echo "Another terminal window will open if detected, shut down the other terminal when happy with output"
 qyn=${qyn,,}    # tolower
 if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
	gpsyn='y'
	tty=''
	echo " "
	echo "Attempting auto-detection for 60 secs "
	echo " "
	for i in {1..60}; do
	echo "$i [ 60 ]"
	ls  /dev|grep USB>ttyUSB 2>/dev/null
	tty=$(<ttyUSB)
 	if [ $tty != '' ] 2>/dev/null ;then
		clear
		echo "FOUND a device... checking GPS with 'gpsmon'"
		echo " "
		echo "Starting GPSMonitor in another terminal window, shut down when happy with output [or leave open if you want]"
		sleep 5
		#(./bccl.sh "$projname" | sed -e 's/^/[bccl .    ] /' &)
		(gnome-terminal --window-with-profile=gpsmon -e gpsmon /dev/"$tty")		
		break
	fi
	sleep 1
	done 
 	if [ $tty != '' ] ;then
	echo  "GPS detected at $tty"
	projecttxt="$projecttxt \nUSB GPS collection is = ON"
	projecttxt="$projecttxt \nGPS detected was detected on $tty"
	else
	echo "no GPS detected"
	sleep 5
	projecttxt="$projecttxt \nUSB GPS collection is = ON"
	projecttxt="$projecttxt \nGPS ERROR not detected"
	projecttxt="$projecttxt \nWARNING no GPS , means no kml output for ping data , and means gps must be installed on breadcrumb"
	exit
	fi


 else
	gpsyn='n'
	echo " "
	echo -e "${RED}WARNING no GPS , this means Ping wont work. Also means GPS must be installed on breadcrumb for breadcrumb collection${NC}"
	echo " "
	projecttxt="$projecttxt \nUSB GPS collection is = OFF"
	projecttxt="$projecttxt \nWARNING no local GPS"

 fi
else

 if [ "$Setgps" == "SKIPTHISSECTION?" ];then
  echo "Is USB gps plugged in [y/n] \?2"
  read qyn
  echo "Attempting auto-detection for 60 secs "
  echo ""
  qyn=${qyn,,}    # tolower
  if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
   	#  if [ $qyn == 'y' ] ; then
	gpsyn='y'
	tty=''

	for i in {1..60}; do

	echo "."
	ls  /dev|grep USB>ttyUSB 2>/dev/null
	tty=$(<ttyUSB)
 	if [ $tty != '' ] 2>/dev/null ;then
		echo "FOUND a device Remember... 'q' then [Enter] to quit the GPS checking app 'gpsmon'"
		echo " "
		echo "Starting GPSMonitor in another terminal window, shut down when happy with output"
		sleep 5
		#(./bccl.sh "$projname" | sed -e 's/^/[bccl .    ] /' &)
		#(gpsmon /dev/"$tty")
		(gnome-terminal --window-with-profile=gpsmon -e gpsmon /dev/"$tty")
		break
	fi
	sleep 1
	done 
 	if [ $tty != '' ] ;then
		echo  "gps detected at $tty"
		projecttxt="$projecttxt \nUSB GPS collection is = ON"
		projecttxt="$projecttxt \nGPS detected was detected on $tty"
	else
		echo "no gps detected"
		sleep 3
		projecttxt="$projecttxt \nUSB GPS collection is = ON"
		projecttxt="$projecttxt \nGPS ERROR not detected"
		projecttxt="$projecttxt \nWARNING no local GPS"
		exit
	fi
  fi
 fi
fi


#end if if no redoing the settings setup ie recalled from settings file
fi



if [ "$Setbc" == "" ];then
 echo " "
 echo -e "${BLUE}#######################################"
 echo -e $projecttxt
 echo " "
 echo -e "#######################################${NC}"
 echo " "
 echo Do you want to commit to the survey project with the settings above [y/n] \?
 read qyn
 qyn=${qyn,,}    # tolower
 if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
 # if [ $qyn == 'y' ] ; then
	commityn='y'
	
	echo -e $projecttxt>"$projname/settings.txt"
	date '+%Y%m%d %H:%M:%S'>>"$projname/history.txt"
	echo "Committed and started">>"$projname/history.txt"
	histtxt="$histtxt\nVersion $Version"
	histtxt="$histtxt\nUser is '$USER'"
	histtxt="$histtxt\nPWD is $PWD"
	echo -e $histtxt>>"$projname/history.txt"
	echo -e $projecttxt>>"$projname/history.txt"
	echo "Collecting data check window for errors often"
	sleep 3
 else
	commityn='n'
	projecttxt=""
 fi
else

 #else we have retrieved the original settings from file

 echo " "
 echo -e "${BLUE}#######################################"
 tmp=$(<"$projname/settings.txt")
 printf "$tmp"
 echo " "
 echo -e "#######################################${NC}"
 echo " "
 echo Do you want to commit to the survey project with the settings above [y/n] \?
 #temp change
 #read qyn
 qyn="y"
 qyn=${qyn,,}    # tolower
 if [[ "$qyn" =~ ^(yes|y)$ ]] ; then
 # if [ $qyn == 'y' ] ; then
	commityn='y'
	#projecttxt="$projecttxt \nCommitted and started"
	#echo -e $projecttxt>"$projname/settings.txt"
	date '+%Y%m%d %H:%M:%S'>>"$projname/history.txt"
	echo -e "Committed and started">>"$projname/history.txt"
	histtxt="$histtxt\nVersion $Version"
	histtxt="$histtxt\nUser is '$USER'"
	histtxt="$histtxt\nPWD is $PWD"
	echo -e $histtxt>>"$projname/history.txt"
	echo -e $projecttxt>>"$projname/history.txt"
	echo -e "NOTE Recovered settings file used\n##########################################">>"$projname/history.txt"
	echo -e $tmp>>"$projname/history.txt"
	echo $ADDprojecttxt>>"$projname/history.txt"
	echo -e "##########################################\n\n\n">>"$projname/history.txt"
	echo "Collecting data check window for errors often"
	sleep 3
	#set the vars for the settings file that was read , leave settings file as is just assign the vars needed
	if [ $Setbc == "ON" ];then crumbyn="y";fi
	if [ $Setp1 == "ON" ];then ping1yn="y";fi
	if [ $Setp2 == "ON" ];then ping2yn="y";fi
	if [ $Setbcip != "" ];then BreadcrumbIP="$Setbcip";fi
	if [ "$Setppd" != "" ];then ping1desc="$Setpd";fi
	if [ $Setip1 != "" ];then pingip1="$Setip1";fi
	if [ "$Setpsd" != "" ];then ping2desc="$Setsd";fi
	if [ $Setip2 != "" ];then pingip2="$Setip2";fi
	#leave usb off soa s to recheck the usb port no
	if [ $Setusb == "ON" ];then gpsyn="y";fi
		gpsyn="y"
#up2here
	
 else
	commityn='n'
	projecttxt=""
 fi

fi

if [ "$commityn" == "y" ] ; then
startrediscli

if [ "$crumbyn" == "y" ] ; then
	startbccapps
fi

if [ "$ping1yn" == "y" ] ; then
startping1apps
fi

if [ "$ping2yn" == "y" ] ; then
startping2apps
fi

if [ "$gpsyn" == "y" ] ; then
startgpsapps
fi



echo "Restart app if errors are suspected" 

tmp="initilised"

lastusedspace=""
while true; do
sleep 5

echo -e "[Controll] "$(date '+%H:%M:%S.%3N ')"${GREEN}Number of BCC processes = "$(ps -ef |grep -c bcc)"${NC}"
echo -e "[Controll] "$(date '+%H:%M:%S.%3N ')"${GREEN}Number of Ping Processes = "$(ps -ef |grep -c ping)"${NC}"
#df diskfreespace|print 5th field|delete newlines with tr | cut the return val delimited with space|sed replace % with nuthin
dusedspace=$(df -H . |awk  '{print $5}'|tr '\n' ' '|cut -d' ' -f2|sed -e 's/\%//')
echo -e "[Controll] "$(date '+%H:%M:%S.%3N ')"${GREEN}Diskspace Used = $dusedspace%${NC}"

if [ $dusedspace -gt 78 ] ; then
echo -e "[Controll] "$(date '+%H:%M:%S.%3N ')"${RED}Diskspace Alert $dusedspace% of diskspace used${NC}"
fi

 

oldgps=$tmp
tmp=$(/opt/redis-4.0.6/redis-4.0.6/src/redis-cli get coords.string)

if [ "$oldgps" == "$tmp" ] ; then
	#yellow
	echo -e "[Controll] "$(date '+%H:%M:%S.%3N ')"${RED}GPS Warning - values unchanged last 5 secs - GPS unplugged? -${NC} $tmp"
	gps_string="ERROR No FRESH GPS DATA,,,,"
	#temp isolated for testing
	#comment out the next line if you want to collect all datapoints at a single location.
	#/opt/redis-4.0.6/redis-4.0.6/src/redis-cli set coords.string "$gps_string"| sed -e 's/^/redis write to coords.string $gps_string is = /'
fi 


done 

fi

trap - SIGINT
echo end of bc_controller.shf

#!/bin/bash
stdbuf -o0 bash /home/mst/localhost_html/cc2kml/cc2kmlcollector.sh




#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |tr '\n' ' '|sed 's/[0-9][0-9]:[0-9][0-9]:/\'$'\n&/g'|grep -E  'gps|mac'>logwatch1.txt
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |awk '{ printf "%s,",$0 }'
echo "bccgps.sh started"
echo "GPS destination is $1"
echo "GPS pipe file is $2"
rm $2
mkfifo $2
tty=ls
#rm ping1tail
#mkfifo ping1tail
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all >"$(date "+%Y%m%d%H%M")_bccl.log"
echo checking ttyUSB
ls  /dev|grep USB>ttyUSB
tty=$(<ttyUSB)
echo "gps collecting on $tty"
#stdbuf -oL gpsmon -a /dev/ttyUSB3 |grep --line-buffered "GPRM"
# line above is the test line in the terminal ... display without buffering due to tty and binary or sumthin stupid
# added the stdbuf -oL as a work around to stop line buffering
#stdbuf -oL gpsmon -a /dev/$tty | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '"$tty"' {}'|grep -E 'GPRM'|tee $2

#added stdbuf to call bash script as child processes take up stdbuf command
gpsmon -a /dev/$tty | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '"$tty"' {}'|grep -E 'GPRM'|tee $2
while :
do
 #ping -c 1 -t 1 -w 1 $1 | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'$tmp'! {}'|grep -E 'ms'|tee $2 
sleep 2
ls  /dev|grep USB>ttyUSB
ttynew=$(<ttyUSB)
if [ $ttynew != $tty ] ; then
sleep 5
tty=$ttynew
#stdbuf -oL gpsmon -a /dev/$tty | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '"$tty"' {}'|grep -E 'GPRM'|tee $2
gpsmon -a /dev/$tty | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '"$tty"' {}'|grep -E 'GPRM'|tee $2

fi
done

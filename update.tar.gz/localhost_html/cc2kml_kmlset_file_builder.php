#!/usr/bin/php
<?php
// denotes that this is a comment for maintaining the script it maybe at the end of lines to explain what the line does
# denotes a temporary debugging or testing of certain function used during the debuggine proccess this chracter skips the line
/*
Characters above and below denote the blocking out sections of code that are obselete or otherwise for massive ammounts of comments
'remember' highlights any tricks traps or known bugs 
*/ 
// ======================================================================
// (C) Copyright 2015 Mine Site Technologies.  All rights reserved.
// Unauthorised use or copying or any parts of this code prohibited.
// Written by Cameron Jones c.jones@mstglobal.com
// ======================================================================
/*
*DESCRIPTION* - this script tracks and stores data about the breadcrumb mesh network for immediate and past reference of the performance and members of the mesh.




*DEPENDENCIES* - This script requires the following
Opensuse - 'bcctl2' is a rajant binary compiled for opensuse and requires this OS to run
Webserver - to serve the web pages that make this eas to use and navigate the databases within. [appachee recommended]
Mysql/Marion DB- to hold the data for future reference in the database called MST_BC_TRACKER
bcaudit.ini - a configuation file that holds the information required for the script to run
[optional] bcaudit.sql - a script that deletes all databases and rebuilds them for a fresh installation

*INI FIle meanings and options

$debuglevel 0 = none
$debuglevel 1 = G only  "general"
$debuglevel 2 = B only	"breadcrumb"
$debuglevel 3 = C only	"changes"
$debuglevel 4 = D only	"database"
$debuglevel 5 = E only	"errors"
$debuglevel 6 = F only	"files"
$debuglevel 7 = k only	"kml generation"
$debuglevel 8 = all		
$debuglevel none = all







*SECTIONS* - The following sections contain the block code or functional bits that make this script work. Search for the keywords that are in capitals to take you direct to that section.
//START - well you know this one
//LOAD IP's [section] checks the ip address are reachable before proccessing the breadcrumb. It also instructs the updating of the ip address table.
//END - and you know this one
//POLL BC's [ main function] - retrieves the information required from the breadcrumb
//CHECK 0  [section] - checks for change in serial no for monitoring change 
//CHECK 1  [section] - checks for change in ip address on the crumbs for monitoring change 
//CHECK 2  [section] - checks for change in GPS Mode for monitoring change 
//CHECK 3  [section] - checks for change in notes section for monitoring change 
//CHECK 4  [section] - checks for change in firmware version no for monitoring change 
//CHECK 5  [section] - checks for change in wire0 state for monitoring change 
//CHECK 6  [section] - checks for change in wire1 state for monitoring change
//CHECK 7  [section] - checks for change in radio0 channel for monitoring change
//CHECK 8  [section] - checks for change in radio1 channel for monitoring change
//CHECK 9  [section] - checks for change in radio2 channel for monitoring change
//CHECK 10  [section] - checks for change in radio3 channel for monitoring change 
//CHECK 11  [section] - checks for change in GPS Location for monitoring change 
//UPDATE DB's  [section] - finishes updating various databases after checks 0-6 above
//PINGADDRESS [minor function]  - pings ip adresses funtion
//UPDATEIPSTATUS 		[database function] -updates the ipstatus table
//UPDATEBCLASTSTATUS	[database function] -updates the bclaststatus table
//UPDATEADMIN			[database function] -updates the admintable
//UPDATEPEERS			[database function] -updates the peers table
//UPDATEBCHISTORY		[database function] -updates the bchistory table
//GETDBVALUE			[handy database function] -retreieves a value from any database table
//QRYOK					[handy database function] -retreieves a value from the last database job to test for successfull job entry
//FILLNAMEIPa		[function] -fills an array to save time on db lookups when mtching peer ipaddresses with names
//DATADUMPER and DUMPDATA				:database function :dumps data to a folder for extraction to help desk pcs @ mst
//ACTIVEKML
//ARCHIVEKML
//TIDYFILES				function to clean up files and databases

 
 
 
phpinfo() //check installed componeents and ver
ie . PHP Version => 5.6.1

//handy to remeber
find / -type f -name "*.conf"

grep -r "string to be searched"  /path/to/dir

*/


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//START
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#echo phpinfo(); 
#sleep(100); 

$debuglevel="";
$IP_1_start="";
$IP_1_end="";
$IPlist="";
$sitename="";
$debuglevel="";
$crumb_gps_info=ARRAY(); //EMPTY ARRAY TO STORE CRUMB AND GPS INFO 

$crumb_plotted_kml_info=ARRAY(); //EMPTY ARRAY TO STORE CRUMB INFO as it was plotted to speed up lookup in peers link function
global $crumb_plotted_kml_info;



//read the ini file for the ipaddress to scan for
//.... ini file contents...........
//IP_1_start=10.36.61.1
//IP_1_end=10.36.62.254
//IPlist=("10.36.61.1" "10.36.61.2")
//etc
//////////////////////////////////////////////////////////////////////////////

$lines = file('bcaudit.ini'); //file location read into $lines array
#dbg("f","line[0]=".trim($lines[0]));
#dbg("f","line[1]=".trim($lines[1]));
#dbg("f","line[2]=".trim($lines[2]));
#dbg("f","line[3]=".trim($lines[3]));
#dbg("f","line[4]=".trim($lines[4]));
#dbg("f","line[5]=".trim($lines[5]));

foreach ($lines as $line_num => $line){ //read variables from the $lines array
$line = explode("=",$line);
$varname = trim($line[0]);   //IP_1_start=
#echo $varname.chr(10); //varname
global $varname;
if (! $line[1]=="") $$varname =trim( $line[1]); 
#echo $$varname.chr(10); //var val

##sleep(1);
} //end for each

date_default_timezone_set($GLOBALS["timezone"]);
echo 'Current time: ' . date('Y-m-d H:i:s') . "\n";
sleep (1);

dbg("g","mainfunc Script start time ");
dbg("g","mainfunc Version 1.0.1");

global $mywdir;
$GLOBALS["mywdir"]=getcwd();
dbg("f","mainfunc working directory =".$GLOBALS["mywdir"]);



if (checkfilefirst("logs","bcaudit.ini",get_current_user()) != "OK"){
	dbg("e","log dir Error - cannot read ini file in logs directory  - check directory exists and permissions for ".get_current_user());
}else{
	copy($GLOBALS["mywdir"].'/bcaudit.ini',$GLOBALS["mywdir"].'/logs/bcaudit.ini'); //copy the ini for debugging , ends up in the kmz and can be unpacked
}	

if (checkfilefirst("datadump","admin.txt",get_current_user()) != "OK"){
	dbg("e","datadump dir Error - cannot read  file in datadump directory  - check directory exists and permissions for ".get_current_user());
}else{
	##copy($GLOBALS["mywdir"].'/bcaudit.ini',$GLOBALS["mywdir"].'/logs/bcaudit.ini'); //copy the ini for debugging , ends up in the kmz and can be unpacked
}	



##copy($GLOBALS["mywdir"].'/bcaudit.ini',$GLOBALS["mywdir"].'/logs/bcaudit.ini'); //copy the ini for debugging , ends up in the kmz and can be unpacked



//check for username  matching to help mitigate permission errors later
if ($GLOBALS["linuxsytemfileusername"] != get_current_user()) {
	dbg("e","mainfunc FATAL ERROR  - user name [".$GLOBALS["linuxsytemfileusername"]."] does not match logged in user [".get_current_user()."]. This may affect file name permissions set resulting in potiential failure of FTP , pls correct in INI file or change logged in user [".get_current_user()."] to match INI file");
	
	exit;
	}else{
	dbg("g","mainfunc  - INI user name [".$GLOBALS["linuxsytemfileusername"]."] OK matches with logged in user [".get_current_user()."].");
		
	
	}








##sleep(10);
//#cs# This is our ip address variables from the ini file below echoed to the screen for debugging
dbg("g","mainfunc IP_1_start=$IP_1_start");
dbg("g","mainfunc IP_1_end=$IP_1_end");
dbg("g","mainfunc IPlist=$IPlist");
dbg("g","mainfunc Sitename=$sitename");


//##############
//setup the dtatbase connection
//##############
databaseset();




//#ce#
//##############
//get the last runseq number from the database and update time so we can trigger a nightly archive and new daily maps
//##############
$getvalue=getdbvalue("runseq","seq","LIMIT","1"); //get seq
dbg("d","mainfunc getvalue of result array= $getvalue ");
if ($getvalue=="") {
	dbg("e","mainfunc seq=$getvalue");
	dbg("e","mainfunc error returned so this is first entry of 1");
	$seq="0";
}else{			// we have a a valid seq no`
	dbg("d","mainfunc oldseq=$getvalue");
	$seq=$getvalue;
}

$oldseq=$seq;	
dbg("d","mainfunc seq = $seq , old is $oldseq");
$seq=(int)$seq+1;
dbg("d","mainfunc seq after + 1 $seq , old is $oldseq");

$polltime = date("Y-m-d H:i:s");     // create a datetime stamp
$entrydate=$polltime;                 //entrydate is polltime






$getvalue=getdbvalue("entrydate","seq","LIMIT","1");  //get time
dbg("d","mainfunc getvalue of result array= $getvalue ");
if ($getvalue=="") {
	dbg("e","mainfunc lastrun=$getvalue");
	dbg("e","mainfunc error returned so this is first entry of time");
	$lastrun=$entrydate;
}else{			// we have a valid time stamp
	dbg("d","mainfunc lastrun=$getvalue");
	$lastrun=$getvalue;
}
dbg("d","mainfunc entrydate=$entrydate");
dbg("d","mainfunc lastrun=$lastrun");
//2015-11-06 22:42:07

$temparrayED=split(" ",$entrydate);  //split the old poll time / this date to seperate the date
$temparrayLR=split(" ",$lastrun);  //split the old datetime to seperate the date




if ($temparrayLR==$temparrayLR){ //if the dates match dont activate the variable that will do the maintenance routines at the end of the script
$domaintYN="no";
}else{
$domaintYN="yes";
}
dbg("g","mainfunc domaintYN=$domaintYN");
dbg("d","mainfunc update seq to $seq , old is $oldseq");
updateseq($seq,$entrydate,$oldseq);

#zipkmz($sitename);
#ftp($sitename,"");
#ftp($sitename,"archiveflag");

#sleep(2000);


//we fill an aaray here with NAMES to ippaddress to save time later on db lookups
//this gets retriggered when a new entry is made in the bchistory table later in this script
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOAD IP's range 1st
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
echo "start block1".chr(10);
for ($IP=1;$IP<=20;$IP++){ //autoincrement through from 1 to 20 possible IP address ranges stored inside the ini file
	echo $IP." ";
	#sleep  (3);
	$IP_x_start="IP_".$IP."_start";
	$IP_x_end="IP_".$IP."_end";
	echo "start=".$$IP_x_start.chr(10);
	#sleep(5);
	if (($$IP_x_start != "") and ($$IP_x_end != "")) { //if the globals array value for the next server ip or host name exists else skip , this ceates UNDEFINED VARIABLE AS IT DOESNT EXIST IF NOT IN THE INI WHICH WE CAN LIVE WITH FOR NOW


		dbg("g","mainfunc Debug-IP_x_start=$IP_x_start is OK"); //ippadress found 
		dbg("g","mainfunc Debug-IP_x_end=$IP_x_end is OK"); //ippadress found 
		##loop to find number of ip addresses to scan - this is stupidly confusing
		$count=0;
		$x = 1;
		//Trim any noise off the variables
		#sleep  (3);



		$tempstr=trim($$IP_x_start);
		$IP_x_end=trim($$IP_x_end);  //weired i know thw $$ double dolar references the variable name in side the variable that is a  string of the real variable
		//start main loop
		while($x > 0){
			$IPmaster[$count]=$tempstr;
			$tempdis=ip2long($tempstr);
			#Echo "Debug-$tempdis";
			#Echo "<";
			$tempdis=ip2long($IP_x_end);
			#Echo "$tempdis";
			if (ip2long($tempstr)<=ip2long($IP_x_end)){  //This IP address is tested to see if it is the last one to test

				$polltime =date("Y-m-d H:i:s");     // create a datetime stamp for database
				$entrydate=$polltime;                 //entrydate is polltime
				$Pingreturn=pingAddress($tempstr);   //ping the device
				#echo chr(10);
				#echo "$Pingreturn";
				if ($Pingreturn<>"up"){  //device is down
					//runseq,entrydate,status,basemodel,bcname,serialno,bcstatus,sysip
					updateipstatus("$seq","$polltime","$Pingreturn","","","","","$tempstr","$sitename");
				} else {
					dbg("g","mainfunc device is up,poll the device for information`");
					pollbc("$seq","$polltime","$Pingreturn","$tempstr",$sitename,$nameipA);
				}
				$tempstr=ip2long($tempstr)+1;
				$tempstr=long2ip($tempstr)	;
				#echo chr(10);
				#echo "###sleep10";
				####sleep(10);
			}else{
				$x = 0;
				#echo chr(10);
				dbg("g","mainfunc Finished Processing IP Adress and BreadCrumbs");
			}  //end if
		} //end while$x
	}  //end if
} //end for IP


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOAD IP's colon seperated list with descriptors and possible gps data if time permits to do it - these are not crumbs so we check the ip and maybe port? , if gps settings we plot otherwise text descriptor
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//from the ini file
//IPlist=10.36.61.1,Gateway:127.0.0.1:192.168.3.251
global $additionIPhistory;

$IPColonA= explode(":",$IPlist); //split the line at the : into array $IPcolonA
#print_r($IPColonA);
#echo chr(10).chr(10)." size=".sizeof($IPColonA).chr(10);
#sleep(5);
for ($x=0;$x<sizeof($IPColonA);$x++){ //autoincrement through $IPColonA array  to the maximimnumber of elements counter 
	$IPiA=explode(",",$IPColonA[$x]); //split the line at the = into second array $IPiA
	#echo "x=".$x." ".$IPiA[1].chr(10);
	#print_r($IPiA);
	#sleep(5);
	if (($IPiA[0] =="") and ((strpos($IPColonA[$x],'.') == true))) $IPiA[0] = $IPColonA[$x]; //if when spilt no ip but the original contains text , then it is probably a single entry , no : delimter   
	if (($IPiA[0] !="" ) and (strpos($IPiA[0],'.') !== false)) { // ok we have an ip to test or we have only one to checked by searching for .
		$polltime =date("Y-m-d H:i:s");     // create a datetime stamp for database
		$entrydate=$polltime;                 //entrydate is polltime
		#echo $IPiA[0].chr(10);
		#sleep(10);
		$Pingreturn=pingAddress($IPiA[0]);   //ping the device
			#echo chr(10);
			#echo "ping = ".$Pingreturn;
			#sleep(10);
		if ($Pingreturn<>"up"){  //device is down
			$Pingreturn=pingAddress($IPiA[0]);   //ping the device
			if ($Pingreturn<>"up"){  //device is down
				$Pingreturn=pingAddress($IPiA[0]);   //ping the device
				if ($Pingreturn<>"up"){  //device is down
					//runseq,entrydate,status,basemodel,bcname,serialno,bcstatus,sysip
					updateipstatus("$seq","$polltime","$Pingreturn","","","","",$IPiA[1],"$sitename");
					if ($IPiA[2]!= "") $additionIPhistory=$additionIPhistory."Device ".$IPiA[1]." is down, ip =".$IPiA[0].chr(10);
					echo "ping = ".$additionIPhistory;
					sleep(5);
				} //pinged 3 times
			} //ping twice
		}	//ping once
		if ($Pingreturn=="up") {
			dbg("g","mainfunc device is up,poll the device for information`");
			pollbc("$seq","$polltime","$Pingreturn",$IPiA[1],$sitename,$nameipA);
			if ($IPiA[2]!= "") $additionIPhistory=$additionIPhistory."Device ".$IPiA[1]." is up, ip =".$IPiA[0].chr(10);
			echo "ping = ".$additionIPhistory;
			sleep(5);
		}
	}else{
			//finished no ip in this field , maybe error in ini file or extra colon at the end
		#		echo "not good =".$IPiA[0].chr(10);
		#sleep(10);		
	} //endif

} //end for x



##sleep(1);
while($x > 0){
	$IPmaster[$count]=$tempstr;
	$tempdis=ip2long($tempstr);
	#Echo "Debug-$tempdis";
	#Echo "<";
	$tempdis=ip2long($IP_1_end);
	#Echo "$tempdis";
	if (ip2long($tempstr)<=ip2long($IP_1_end)){  //This IP address is tested to see if it is the last one to test

		$tempstr=ip2long($tempstr)+1;
		$tempstr=long2ip($tempstr)	;
		#echo chr(10);
		#echo "###sleep10";
		####sleep(10);
	}else{
		$x = 0;
		#echo chr(10);
		dbg("g","mainfunc Finished Processing IP Adress and BreadCrumbs");
	}  //end if
} //end while$x





if (count($crumb_gps_info) > 0){ //if we have gps info sowe can plot crumbs with cost
//Process ActivecostKML() for ceating the most recent kml file for costs
ActivecostKML();	
} ;

zipkmz($sitename);  //make kmz files

datadumper();
tidyfiles();


if ($domaintYN=="yes"){ //past midnight archive and tidy the file [email and ftp not possible]
	//Process archiveKML() archive the dailyarchive directory for historical purposes
##	databasetransfer();
##	ftp($sitename,"archiveflag"); //archive rename event sent whilst ftp files on remote server send same file twice but renames the first at the far end 
	archiveKML();
	tidyfiles();//Process tidyfiles() to enable smaller databses and clean up any loose ends 
}else{  //do normal ftp file transfers if enabled in ini
##	ftp($sitename,""); //archive IS NUL SO IT WILL NOT ARCHIVE . ARCHIVE IS  rename event sent whilst ftp files on remote server send same file twice but renames the first at the far end 	
}// end if

//end of main loop and exescution
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//END
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DATABASESET
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function databaseset(){
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DATABASECLOSE
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function databaseclose(){
mysql_close($DBconn);
};



#exec("/home/c.jones/bin/bcctl2 -h 192.168.3.231:2300 -u co -P breadcrumb-co -t 5000 get", $out, $ret);
#exec("/home/c.jones/bin/bcctl2 -h 192.168.3.231:2300 -u co -P breadcrumb-co -t 5000 get > dump.txt", $out, $ret);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//POLL BC's
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//pollbc("$seq","$polltime","$Pingreturn","$tempstr",$sitename);
function pollbc($seq,$polltime,$Pingreturn,$bcIP,$sitename,$nameipA){

			global $acceptablecostcount;
			global $aptpriority;
			global $basemodel;
			global $bcname;
			global $bcstatus;
			global $bestcost;
			global $belongstogroup;
			global $bootcounter;
			global $entrydate;
			global $goodcostcount;
			global $gpsalt;
			global $gpslat;
			global $gpslon;
			global $gpsmode;
			global $gpsspeed;
			global $gpsswitchenabled;
			global $gpstime;
			global $gpsquality;
			global $gpssatsinview;
			global $gpsgeoid;
			global $groupinterator;
			global $groupinteratorcount;
			global $model;
			global $monsterpeerarray;
			global $networkname;
			global $notes;
			global $radio0active;
			global $radio0bandwidth;
			global $radio0channel;
			global $radio0mac;
			global $radio0meshenabled;
			global $radio0name;
			global $radio0noofaps;
			global $radio0noofpeers;
			global $radio0peerlist;
			global $radio1active;
			global $radio1bandwidth;
			global $radio1channel;
			global $radio1mac;
			global $radio1meshenabled;
			global $radio1name;
			global $radio1noofaps;
			global $radio1noofpeers;
			global $radio1peerlist;
			global $radio2active;
			global $radio2bandwidth;
			global $radio2channel;
			global $radio2mac;
			global $radio2meshenabled;
			global $radio2name;
			global $radio2noofaps;
			global $radio2noofpeers;
			global $radio2peerlist;
			global $radio3active;
			global $radio3bandwidth;
			global $radio3channel;
			global $radio3mac;
			global $radio3meshenabled;
			global $radio3name;
			global $radio3noofaps;
			global $radio3noofpeers;
			global $radio3peerlist;
			global $serialno;
			global $status;
			global $sysip;
			global $totalnoofpeers;
			global $uptime;
			global $version;
			global $wire0mac;
			global $wire0name;
			global $wire0state;
			global $wire1mac;
			global $wire1name;
			global $wire1state;
			global $openadminsessionstot;			
			global $Acounter;

			global $useragent;
			global $remoteusername;
			global $remoteos;
			global $role;
			global $address;
			global $sitename;
			global $stringtext;

			global $radio0freq;
			global $radio1freq;
			global $radio2freq;
			global $radio3freq;
			global $crumb_gps_info;
			
exec($GLOBALS["mywdir"]."/bcctl2 -h $bcIP:2300 -u ".$GLOBALS["bcuser"]." -P ".$GLOBALS["bcpassword"]." -t 5000 get >dump.txt", $out, $ret); //used this line `to get the contents to dumpt.txt for debugging
unset($out);  //clear the array for our results and make empty
exec($GLOBALS["mywdir"]."/bcctl2 -h $bcIP:2300 -u ".$GLOBALS["bcuser"]." -P ".$GLOBALS["bcpassword"]." -t 5000 get", $out, $ret);
dbg("b",$GLOBALS["mywdir"]."/bcctl2 -h $bcIP:2300 -u ".$GLOBALS["bcuser"]." -P ".$GLOBALS["bcpassword"]." -t 5000 get");
sleep (2);

#dbg("o","$return value from bc command to connect=".trim($ret));
#echo $ret;
###sleep(5);
//assign some fixed basepoint variables before entering looop
$serialno="";
$bestcost=9999999999;  //set best cost to rediculous ammount first
$goodcostcount=0;
$acceptablecostcount=0;
$arraycounter=0;
$monsterpeerarray = array();  //empty the array if already made
$Acounter=0;
$adminarray=array();
$basemodel="";
$bcname="";
$gpsmode=0;
$belongstogroup="";// reset the groups
$totalnoofpeers="";//reset $totalnoofpeers
$t=""; //flag to check for data in the array`
if (is_array($out)){
if (! empty($out)){
	#echo "check it is an array";
	$t=stripos($out[0],"=");  //look for a = in the output from a crumb
	#dbg("o","out=");
	#dbg("b","".print_r($out));
}
}
#echo chr(10)."t".$t;
###sleep(10);
if  ($t<>""){ //meaning there is data found from the $t flag
foreach ($out as $line){  //now read each line of data from he breadcrumb
	$tempA=explode("=",$line); //split the line at the = into array $tempA
	$TA=$tempA[0];
	$tempA[1]=trim($tempA[1],chr(34)); // trim here the "" first to simplify things later
	$tempA[1]=trim($tempA[1]);  // trim here the whitespaces and crlf to simplify things later
	switch ($TA){   
//GET the Basics		
		case "_hardware_serial":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$serialno=$get;
			break;
		case "_system_platform":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$basemodel=$get;
			break;
		case "_model_description":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$model=$get;
			break;
		case "_system_uptime":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$uptime=$get;
			break;
		case "_system_running":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$bcstatus=$get;
			break;
		case "_system_bootCounter":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$bootcounter=$get;
			break;			
		case "_configuration_active_general_name":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$bcname=$get;
			break;
		case "_configuration_active_general_notes":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$notes=$get;
			break;
		case "_configuration_active_instamesh_networkName":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$networkname=$get;
			break;
		case "_system_ipv4_address":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$sysip=$get;
			break;
		case "_configuration_active_instamesh_aptPriority":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$aptpriority=$get;
			break;
		case "_configuration_active_general_groups_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$groupinterator=$get;
			$tempC=explode(" ",$groupinterator);
			$groupinteratorcount=count($tempC);   //count them to make a count total of interator groups
			break;
		case "_system_version":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$version=$get;
			break;


//gps section
//		look for auto or manual long and lat and other gps info if required
		case "_gps_gpsSwitch_enabled":  ///doubled up value below for '$gpsswitchenabled' approx 30 lines
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpsmode=$get;
			break;
		case "_configuration_saved_manualLocation_latitude":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpslat=$get;
			break;
		case "_configuration_saved_manualLocation_longitude":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpslon=$get;
			break;
		case "_configuration_saved_manualLocation_altitude":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpsalt=$get;
			break;
		case "_gps_gpsPos_gpsLat":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpslat=$get;
			break;
		case "_gps_gpsPos_gpsLong":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpslon=$get;
			break;
		case "_gps_gpsPos_gpsPrecisionH":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpsalt=$get;
			break;
		case "_gps_gpsSwitch_enabled": ///doubled up value above for '$gpsmode' approx 30 lines
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpsswitchenabled=$get;
			break;
		case "_gps_gpsPos_gpsTime":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpstime=$get;
			break;
		case "_gps_gpsPos_gpsQuality":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpsquality=$get;
			break;
		case "_gps_gpsPos_gpsSatsInView":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpssatsinview=$get;
			break;
		case "_gps_gpsPos_gpsGeoidalSep":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$gpsgeoid=$get;
			break;

			
//wired port section			
			
		//_wired_0_mac="00d0124beea5"
		//_wired_0_masterMac="00d012d1f09e"
		//_wired_0_name="eth0"
		case "_wired_0_name":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wire0name=$get;
			break;
		case "_wired_0_mac":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wire0mac=$get;
			break;
		case "_wired_0_aptState":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wire0state=$get;
			break;
		case "_wired_0_peer_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wired0peerlist=$get;
			$tempC=explode(" ",$get);
			$wired0noofpeers=count($tempC);  //count the no of peers
			$totalnoofpeers=$totalnoofpeers+$wired0noofpeers;
			break;
		case "_wired_1_name":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wire1name=$get;
			break;
		case "_wired_1_mac":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wire1mac=$get;
			break;
		case "_wired_1_aptState":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wire1state=$get;
			break;
		case "_wired_1_peer_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$wired1peerlist=$get;
			$tempC=explode(" ",$get);
			$wired1noofpeers=count($tempC);  //count the no of peers
			$totalnoofpeers=$totalnoofpeers+$wired1noofpeers;
			break;

			
//wireless ports section			


		case "_wireless_0_mac":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0mac=$get;
			break;
		case "_wireless_0_name":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0name=$get;
			break;
		case "_wireless_0_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0channel=$get;
			break;
		case "_wireless_0_ap_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0noofaps=$get;
			$tempC=explode(" ",$get);
			$radio0noofaps=count($tempC);  //count the no of peers
			break;
		case "_configuration_active_wireless_0_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0active=$get;
			break;
		case "_configuration_active_wireless_0_enableMesh":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0meshenabled=$get;
			break;
		case "_configuration_active_wireless_0_bandwidth":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0bandwidth=$get;
			break;
		case "_wireless_0_peer_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0peerlist=$get;
			$tempC=explode(" ",$get);
			$radio0noofpeers=count($tempC);  //count the no of peers
			$totalnoofpeers=$totalnoofpeers+$radio0noofpeers;
			break;
	
		case "_wireless_1_mac":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1mac=$get;
			break;
		case "_wireless_1_name":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1name=$get;
			break;
		case "_wireless_1_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1channel=$get;
			break;
		case "_wireless_1_ap_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1noofaps=$get;
			break;
		case "_configuration_active_wireless_1_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1active=$get;
			break;
		case "_configuration_active_wireless_1_enableMesh":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1meshenabled=$get;
			break;
		case "_configuration_active_wireless_1_bandwidth":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1bandwidth=$get;
			break;
		case "_wireless_1_peer_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1peerlist=$get;
			$tempC=explode(" ",$get);
			$radio1noofpeers=count($tempC);   //count them to make a count total
			$totalnoofpeers=$totalnoofpeers+$radio1noofpeers;
			break;


		case "_wireless_2_mac":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2mac=$get;
			break;
		case "_wireless_2_name":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2name=$get;
			break;
		case "_wireless_2_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2channel=$get;
			break;
		case "_wireless_2_ap_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2noofaps=$get;
			break;
		case "_configuration_active_wireless_2_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2active=$get;
			break;
		case "_configuration_active_wireless_2_enableMesh":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2meshenabled=$get;
			break;
		case "_configuration_active_wireless_2_bandwidth":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2bandwidth=$get;
			break;
		case "_wireless_2_peer_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2peerlist=$get;
			$tempC=explode(" ",$get);
			$radio2noofpeers=count($tempC);  //count the no of peers
			$totalnoofpeers=$totalnoofpeers+$radio2noofpeers;
			break;
				
		case "_wireless_3_mac":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3mac=$get;
			break;
		case "_wireless_3_name":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3name=$get;
			break;
		case "_wireless_3_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3channel=$get;
			break;
		case "_wireless_3_ap_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3noofaps=$get;
			break;
		case "_configuration_active_wireless_3_channel":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3active=$get;
			break;
		case "_configuration_active_wireless_3_enableMesh":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3meshenabled=$get;
			break;
		case "_configuration_active_wireless_3_bandwidth":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3bandwidth=$get;
			break;
		case "_wireless_3_peer_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3peerlist=$get;
			$tempC=explode(" ",$get);
			$radio3noofpeers=count($tempC);  //count the no of peers
			$totalnoofpeers=$totalnoofpeers+$radio3noofpeers;
			dbg("b","totalnoofpeers=$totalnoofpeers");
			dbg("b","$radio3noofpeers=$radio3noofpeers");
			break;
		case "_adminSessions_iterator":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$tempC=explode(" ",$get);
			$openadminsessionstot=count($tempC);  //count the no of peers
			dbg("b","openadminsessionstot=$openadminsessionstot");
			break;
		case "_model_wireless_0_model":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$tempC=explode(" ",$get);
			$radio0model=$get;  //count the no of peers
			dbg("b","radio0model=$radio0model");
		break;
		case "_model_wireless_1_model":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$tempC=explode(" ",$get);
			$radio1model=$get;  //count the no of peers
			dbg("b","radio1model=$radio1model");
		break;
		case "_model_wireless_2_model":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$tempC=explode(" ",$get);
			$radio2model=$get;  //count the no of peers
			dbg("b","radio2model=$radio2model");
		break;


		case "_model_wireless_3_model":
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$tempC=explode(" ",$get);
			$radio3model=$get;  //count the no of peers
			dbg("b","radio3model=$radio3model");
		break;

			

		}//end switch
//misc functions nnot based on switch functionality
/*
--_model_radiodb_585235_model="XR5"
--_model_radiodb_585235_band="5 GHz"
--_model_radiodb_585235_channel_36_frequency=5180
--_model_radiodb_585235_channel_36_name="36: 5180 Mhz 11a"
 _model_wireless_0_model="XR2"  
			dbg("b","radio0freq=$radio0freq");
			dbg("b","radio1freq=$radio1freq");
			dbg("b","radio2freq=$radio2freq");
			dbg("b","radio3freq=$radio3freq");
*/

//model to freq data matching array capture
		if  (strrpos($tempA[0],"model")>strlen($tempA[0])-6){  //Simplify matching first by capturing all '_model=' characteristics
			$modelA[]=$line; //insert in modelA array
			dbg("b","found _model $tempA[0]=$tempA[1] where _model= was found");
			##sleep(1);
		}	//end if strpos
		if  (strrpos($tempA[0],"band")>strlen($tempA[0])-5){  //Simplify matching first by capturing all '_model=' characteristics
			$modelA[]=$line; //insert in modelA array
			dbg("b","found _band $tempA[0]=$tempA[1] where _band= was found");
			##sleep(1);
		}	//end if strpos
		if  (strrpos($tempA[1],"Mhz")>0) {  //Simplify matching first by capturing all 'MHZ' characteristics
			$modelA[]=$line; //insert in modelA array
			dbg("b","found Mhz $tempA[0]=$tempA[1] where Mhz was found");	
			##sleep(1);
		}	//end if strpos












//costs
	if  (strrpos($tempA[0],"_cost")>strlen($tempA[0])-5){  //Simplify costs for counting good costs notice gets pos from rear due to _cost , the _ doesnt work in search strings WATCHOUT sometimes returns nuthin
			$t=strpos($tempA[0],"_cost");
			$z=strlen($tempA[0]);
			dbg("b","found _cost $tempA[0]=$tempA[1] where strpos(TA,'_cost')$t and length=$z");

		if ($tempA[1]<5000){
			$goodcostcount=$goodcostcount+1;
			dbg("b","goodcostcount=$goodcostcount");
		}
		if ($tempA[1]<10000){
			$acceptablecostcount=$acceptablecostcount+1;
			dbg("b","acceptablecostcount=$acceptablecostcount");
		}
		if ($tempA[1]<$bestcost){
			$bestcost=$tempA[1];
			dbg("b","found better cost =$bestcost");
		}
	}	//end if strpos
//peers
$found="";
$found=strpos($tempA[0],"wireless_0_peer_0");
	if  ($found<>""){  // find cost line for saving
	        $t=strpos($tempA[0],"_wireless_0_peer_0");
			dbg("b","found _wireless_0_peer_0 $tempA[0]=$tempA[1] where strpoz = $t");
			$monsterpeerarray[$arraycounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$arraycounter=$arraycounter+1;
	}	//end if strpos
$found="";
$found=strpos($tempA[0],"wireless_1_peer_0");
	if  ($found<>""){  // find cost line for saving
	        $t=strpos($tempA[0],"_wireless_1_peer_0");
			dbg("b","found _wireless_1_peer_0 $tempA[0]=$tempA[1] where strpoz = $t");
			$monsterpeerarray[$arraycounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$arraycounter=$arraycounter+1;
	}	//end if strpos

$found="";
$found=strpos($tempA[0],"wireless_2_peer_0");
	if  ($found<>""){  // find cost line for saving
	        $t=strpos($tempA[0],"_wireless_2_peer_0");
			dbg("b","found _wireless_2_peer_0 $tempA[0]=$tempA[1] where strpoz = $t");
			$monsterpeerarray[$arraycounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$arraycounter=$arraycounter+1;
	}	//end if strpos

$found="";
$found=strpos($tempA[0],"wireless_3_peer_0");
	if  ($found<>""){  // find cost line for saving
	        $t=strpos($tempA[0],"_wireless_3_peer_0");
			dbg("b","found _wireless_3_peer_0 $tempA[0]=$tempA[1] where strpoz = $t");
			$monsterpeerarray[$arraycounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$arraycounter=$arraycounter+1;
	}	//end if strpos

$found="";
$found=strpos($tempA[0],"wired_0_peer_0");
	if  ($found<>""){  // find cost line for saving
	        $t=strpos($tempA[0],"_wired_0_peer_0");
			dbg("b","found _wired_0_peer_0 $tempA[0]=$tempA[1] where strpoz = $t");
			$monsterpeerarray[$arraycounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$arraycounter=$arraycounter+1;
	}	//end if strpos

$found="";
$found=strpos($tempA[0],"wired_1_peer_0");
	if  ($found<>""){  // find cost line for saving
	        $t=strpos($tempA[0],"_wired_1_peer_0");
			dbg("b","found _wired_1_peer_0 $tempA[0]=$tempA[1] where strpoz = $t");
			$monsterpeerarray[$arraycounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$arraycounter=$arraycounter+1;
	}	//end if strpos

	
	
	
//group info section
$found="";
$found=strpos($tempA[0],"configuration_active_general_groups");
if ($found <> ""){  // found group 
		$found="";
		$found=strpos($tempA[0],"name");
	if  ($found <> ""){  // found group name
			dbg("b","found _group name $tempA[0]=$tempA[1]");
			if  ($belongstogroup<>""){  // if not empty add a space is the fron of the existing characters
				$belongstogroup=$belongstogroup." ".$tempA[1];
			}else{
				$belongstogroup=$tempA[1];
			} //if belongstogroup
	}	//end if found
}	//end if found
	

//admin users section
$found="";
$found=strpos($tempA[0],"adminSessions");
if ($found <> ""){  // found adminSessions 
	$found="";
	$found=strpos($tempA[0],"remoteUsername");
	if  ($found <> ""){  // found remoteUsername
			dbg("b","found remoteUsername $tempA[0]=$tempA[1]");
			$adminarray[$Acounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$Acounter=$Acounter+1;
			}//if
	$found="";
	$found=strpos($tempA[0],"userAgent");		
	if  ($found <> ""){  // found userAgent
			dbg("b","found userAgent $tempA[0]=$tempA[1]");
			$adminarray[$Acounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$Acounter=$Acounter+1;
			}//if
	$found="";
	$found=strpos($tempA[0],"remoteOS");
	if  ($found <> ""){  // found remoteOS
			dbg("b","found remoteOS $tempA[0]=$tempA[1]");
			$adminarray[$Acounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$Acounter=$Acounter+1;
			} //if 
	$found="";
	$found=strpos($tempA[0],"role");
	if  ($found <> ""){  // found role
			dbg("b","found role $tempA[0]=$tempA[1]");
			$adminarray[$Acounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$Acounter=$Acounter+1;
			} //if 
	$found="";
	$found=strpos($tempA[0],"address");
	if  ($found <> ""){  // found address
			dbg("b","found address $tempA[0]=$tempA[1]");
			$adminarray[$Acounter]=str_replace(chr(34),"",$line);   //replace chr=" with nothing
			$Acounter=$Acounter+1;
			} //if 
}	//end if found
} //end foreach loop1

if ($bestcost=9999999999){  //RESET BESTCOST IF NOT FOUND this could happen if  single crumb etc
	$bestcost="NA";
		dbg("b","bestcost=$bestcost");
}


/*
--_model_radiodb_585235_model="XR5"
--_model_radiodb_585235_band="5 GHz"
--_model_radiodb_585235_channel_36_frequency=5180
--_model_radiodb_585235_channel_36_name="36: 5180 Mhz 11a"
 _model_wireless_0_model="XR2"  

	 _model_radiodb_585235_model="XR5"
    [23] => _model_radiodb_585235_band="5 GHz"
    [62] => _model_radiodb_585235_channel_160_name="160: 5800 Mhz 11a"
    [63] => _model_radiodb_585235_channel_161_name="161: 5805 Mhz 11a"
    [64] => _model_radiodb_585235_channel_162_name="162: 5810 Mhz 11a"
    [65] => _model_radiodb_585235_channel_163_name="163: 5815 Mhz 11a"
    [66] => _model_radiodb_585235_channel_164_name="164: 5820 Mhz 11a"
    [67] => _model_radiodb_585235_channel_165_name="165: 5825 Mhz 11a"
    [68] => _model_wireless_0_model="XR2"
    [69] => _model_wireless_1_model="XR5"
    [70] => _model_wireless_2_model="DLM108"
    [71] => _model_wireless_3_model="XR2"
		
			
			*/

//model to freq data matching array capture to sort our freq out of type of radio


//radio model names
#echo("step check1");
foreach ($modelA as $line){  //now read each line of data from he breadcrumb
	$tempXA=explode("_",$line); //split the line at the = into array $tempA
	$tempYA=explode("=",$line); //split the line at the = into array $tempA
	$SlotID=$tempXA[3];  //slot id to find our channel characteristics
	switch ($SlotID){   
		case "0":
			$get=trim($tempYA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio0model=$get;
			break;
		case "1":
			$get=trim($tempYA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio1model=$get;
			break;
		case "2":
			$get=trim($tempYA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio2model=$get;
			break;
		case "3":
			$get=trim($tempYA[1],chr(34));  //remove the " from the required returned text"
			dbg("b","found search string".$get);
			$radio3model=$get;
			break;
	}//end switch
}//end for	we now have our radio models , now find our channel details
#			echo chr(10);
#			echo $radio0model.chr(10);
#			echo $radio1model.chr(10);
#			echo $radio2model.chr(10);
#			echo $radio3model.chr(10);

			
//get our channel identifier per radio id type
foreach ($modelA as $line){  //now read each line of data from he breadcrumb
	$tempXA=explode("_",$line); //split the line at the = into array $tempA
	$tempYA=explode("=",$line); //split the line at the = into array $tempA
	$SlotID=$tempXA[3];  //slot id to find our channel characteristics
	if ((trim($tempYA[1],chr(34))==$radio0model) AND ($tempXA[2]=="radiodb")) $ID0=$SlotID;
	if ((trim($tempYA[1],chr(34))==$radio1model) AND ($tempXA[2]=="radiodb")) $ID1=$SlotID;
	if ((trim($tempYA[1],chr(34))==$radio2model) AND ($tempXA[2]=="radiodb")) $ID2=$SlotID;
	if ((trim($tempYA[1],chr(34))==$radio3model) AND ($tempXA[2]=="radiodb")) $ID3=$SlotID;
} // end foreach

#	echo $radio0freq.chr(10)." copy that".chr(10);

//finally get our freq info matched from slotid and type
foreach ($modelA as $line){  //now read each line of data from he breadcrumb
	$tempYA=explode("=",$line); //split the line at the = into array $tempA
	$tempXA=explode("_",$tempYA[0]); //split the line at the = into array $tempA
	$SlotID=$tempXA[3];  //slot id to find our channel characteristics
	if (($SlotID==$ID0) AND ($tempXA[4]=="band")) $radio0freq=trim($tempYA[1],chr(34)).":";  //radiofreq will be like this 5 GHz:
	if (($SlotID==$ID1) AND ($tempXA[4]=="band")) $radio1freq=trim($tempYA[1],chr(34)).":";  //radiofreq will be like this 5 GHz:
	if (($SlotID==$ID2) AND ($tempXA[4]=="band")) $radio2freq=trim($tempYA[1],chr(34)).":";  //radiofreq will be like this 5 GHz:
	if (($SlotID==$ID3) AND ($tempXA[4]=="band")) $radio3freq=trim($tempYA[1],chr(34)).":";  //radiofreq will be like this 5 GHz:
	//quick n dirty way to add a new cariable for the peers 'moredetail field to add freq to the channel number later via new variable $radio3freqDesc ie RF0=2.4 Ghz
	if (($SlotID==$ID0) AND ($tempXA[4]=="band")) $radio0freqDesc=trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:
	if (($SlotID==$ID1) AND ($tempXA[4]=="band")) $radio1freqDesc=trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:
	if (($SlotID==$ID2) AND ($tempXA[4]=="band")) $radio2freqDesc=trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:
	if (($SlotID==$ID3) AND ($tempXA[4]=="band")) $radio3freqDesc=trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:
	#echo $radio0freq.chr(10)." copy that".chr(10);

	if (sizeof($tempXA) >5){ //stops errors pumping out due to array member not existing in other line of the array
	if (($SlotID==$ID0) AND ($tempXA[5]==$radio0channel)) $radio0freq=$radio0freq.trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:160: 5800 Mhz 11a:
	if (($SlotID==$ID1) AND ($tempXA[5]==$radio1channel)) $radio1freq=$radio1freq.trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:160: 5800 Mhz 11a:
	if (($SlotID==$ID2) AND ($tempXA[5]==$radio2channel)) $radio2freq=$radio2freq.trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:160: 5800 Mhz 11a:
	if (($SlotID==$ID3) AND ($tempXA[5]==$radio3channel)) $radio3freq=$radio3freq.trim($tempYA[1],chr(34));  //radiofreq will be like this 5 GHz:160: 5800 Mhz 11a:
	#echo $radio0freq.chr(10)." copy that".chr(10);
	
	} //end if
	} // end foreach

$radio0freq=str_replace(" ","",$radio0freq); //trim the empty spaces out`
$radio1freq=str_replace(" ","",$radio1freq); //trim the empty spaces out`
$radio2freq=str_replace(" ","",$radio2freq); //trim the empty spaces out`
$radio3freq=str_replace(" ","",$radio3freq); //trim the empty spaces out`

	#echo $radio0freq.chr(10)." copy that".chr(10);
##sleep(10);	
	
///display all out good stuff
			dbg("b","#######################################");
			dbg("b","polltime=$polltime");
			dbg("b","entrydate=$entrydate");			
			dbg("b","sitename=$sitename");		
			dbg("b","serialno=$serialno");
			dbg("b","basemodel=$basemodel");
			dbg("b","totalnoofpeers=$totalnoofpeers");
			dbg("b","model=$model");
			dbg("b","uptime=$uptime");
			dbg("b","bcstatus=$bcstatus");
			dbg("b","bootcounter=$bootcounter");
			dbg("b","bcname=$bcname");
			dbg("b","notes=$notes");
			dbg("b","networkname=$networkname");
			dbg("b","sysip=$sysip");
			dbg("b","aptpriority=$aptpriority");
			dbg("b","belongstogroup=$belongstogroup");
			dbg("b","groupinteratorcount=$groupinteratorcount");
			dbg("b","version=$version");
			dbg("b","gpsmode=$gpsmode");
			dbg("b","gpslat=$gpslat");
			dbg("b","gpslon=$gpslon");
			dbg("b","gpsalt=$gpsalt");
			dbg("b","gpsswitchenabled=$gpsswitchenabled");
			dbg("b","gpstime=$gpstime");
			dbg("b","gpsquality=$gpsquality");
			dbg("b","gpssatsinview=$gpssatsinview");
			dbg("b","gpsgeoid=$gpsgeoid");
			dbg("b","#######################################");
			dbg("b","wire0name=$wire0name");
			dbg("b","wire0mac=$wire0mac");
			dbg("b","wire0state=$wire0state");
			dbg("b","wire1name=$wire1name");
			dbg("b","wire1mac=$wire1mac");
			dbg("b","wire1state=$wire1state");
			dbg("b","#######################################");
			dbg("b","radio0mac=$radio0mac");
			dbg("b","radio0name=$radio0name");
			dbg("b","radio0channel=$radio0channel");
			dbg("b","radio0noofaps=$radio0noofaps");
			dbg("b","radio0active=$radio0active");
			dbg("b","radio0meshenabled=$radio0meshenabled");
			dbg("b","radio0bandwidth=$radio0bandwidth");
			dbg("b","radio0peerlist=$radio0peerlist");
			dbg("b","radio0noofpeers=$radio0noofpeers");
			dbg("b","#######################################");
			dbg("b","radio1mac=$radio1mac");
			dbg("b","radio1name=$radio1name");
			dbg("b","radio1channel=$radio1channel");
			dbg("b","radio1noofaps=$radio1noofaps");
			dbg("b","radio1active=$radio1active");
			dbg("b","radio1meshenabled=$radio1meshenabled");
			dbg("b","radio1bandwidth=$radio1bandwidth");
			dbg("b","radio1peerlist=$radio1peerlist");
			dbg("b","radio1noofpeers=$radio1noofpeers");
			dbg("b","#######################################");
			dbg("b","radio2mac=$radio2mac");
			dbg("b","radio2name=$radio2name");
			dbg("b","radio2channel=$radio2channel");
			dbg("b","radio2noofaps=$radio2noofaps");
			dbg("b","radio2active=$radio2active");
			dbg("b","radio2meshenabled=$radio2meshenabled");
			dbg("b","radio2bandwidth=$radio2bandwidth");
			dbg("b","radio2peerlist=$radio2peerlist");
			dbg("b","radio2noofpeers=$radio2noofpeers");
			dbg("b","#######################################");
			dbg("b","radio3mac=$radio3mac");
			dbg("b","radio3name=$radio3name");
			dbg("b","radio3channel=$radio3channel");
			dbg("b","radio3noofaps=$radio3noofaps");
			dbg("b","radio3active=$radio3active");
			dbg("b","radio3meshenabled=$radio3meshenabled");
			dbg("b","radio3bandwidth=$radio3bandwidth");
			dbg("b","radio3peerlist=$radio3peerlist");
			dbg("b","radio3noofpeers=$radio3noofpeers");
			dbg("b","#######################################");
			dbg("b","goodcostcount=$goodcostcount");
			dbg("b","acceptablecostcount=$acceptablecostcount");
			dbg("b","bestcost=$bestcost");
			dbg("b","#######################################");
			dbg("b","openadminsessionstot=$openadminsessionstot");
			dbg("b","#######################################");
			dbg("b","sitename=$sitename");
			dbg("b","radio0model=$radio0model");
			dbg("b","radio1model=$radio1model");
			dbg("b","radio2model=$radio2model");
			dbg("b","radio3model=$radio3model");
			dbg("b","radio0freq=$radio0freq");
			dbg("b","radio1freq=$radio1freq");
			dbg("b","radio2freq=$radio2freq");
			dbg("b","radio3freq=$radio3freq");
			dbg("b","radio0freqDesc=$radio0freqDesc");
			dbg("b","radio1freqDesc=$radio1freqDesc");
			dbg("b","radio2freqDesc=$radio2freqDesc");
			dbg("b","radio3freqDesc=$radio3freqDesc");
			
			dbg("b","#######################################");

			#dbg("o","monsterpeerarray=");
			#dbg("o","".print_r($monsterpeerarray));
			#dbg("o","adminarray=");
			#dbg("b","".print_r($adminarray));
			#dbg("b","".print_r($modelA));
##sleep(100);
//push values into an array $crumb_gps_info to quickly look uo gps positions for crumb-lat and long for peers path info in kml's section after gathering data
//array_push values for crumb_gps_info = bcname,$gpsmode,$gpslat,$gpslong,$gpsalt  meaning values inside the 1 dimensional array but split with commas
$tempstring=$bcname.",".$gpsmode.",".$gpslat.",".$gpslon.",".$gpsalt;  //make a nice gps string of csv values
#echo $tempstring.chr(10);
array_push ($crumb_gps_info,$tempstring);  //add the gps coordinates to an array to spped things up later and to twest to see if we need to do the kml section
#echo "check=".$bcname.chr(44).$gpsmode.chr(44).$gpslat.chr(44).$gpslon.chr(44).$gpsalt.chr(10);
dbg("o","".print_r($crumb_gps_info));  //temp printout for debugging
#sleep(3);
##sleep(100);
//update the database tables with all the info collected



updateipstatus("$seq","$entrydate","$Pingreturn","$basemodel","$bcname","$serialno","$bcstatus","$bcIP","$sitename");
updatebcdata("$seq","$entrydate","$aptpriority","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$groupinteratorcount","$model","$networkname","$notes","$radio0active","$radio0bandwidth","$radio0channel","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofaps","$radio0noofpeers","$radio1active","$radio1bandwidth","$radio1channel","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofaps","$radio1noofpeers","$radio2active","$radio2bandwidth","$radio2channel","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofaps","$radio2noofpeers","$radio3active","$radio3bandwidth","$radio3channel","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofaps","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$uptime","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$openadminsessionstot","$sitename","$radio0model","$radio1model","$radio2model","$radio3model","$radio0freq","$radio1freq","$radio2freq","$radio3freq");

//before updating laststatus we check for changes so we can also update the bcchanges database


//####################
//CHECK 0 First check for new serial number on the mesh , this gets complicated
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("serialno","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , serialno  = $serialno");
if ($serialno==$getvalue) {
	dbg("c","serialno of $serialno=$getvalue");
	dbg("c","do nothing serialno match");
}else{			// we have a new crumb /serial no on this location
	$changenotes="new serial no=$serialno on the mesh crumb name=$bcname ";
	updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
	$reasonforentry="first time this crumb was seen at this location $sitename"; //reason for entry into the bchistory database
	updatebchistory("$entrydate","$basemodel","$bcname","$belongstogroup","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio1mac","$radio2mac","$radio3mac","$serialno","$sysip","$version","$wire0mac","$wire1mac","$sitename","$reasonforentry");
	$reasonforentry="last time this crumb was seen at this location $sitename"; //reason for entry into the bchistory database
	updatebchistory("$entrydate","$basemodel","$bcname","$belongstogroup","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio1mac","$radio2mac","$radio3mac","$serialno","$sysip","$version","$wire0mac","$wire1mac","$sitename","$reasonforentry");
	$getvalue=getdbvalue("bcname","laststatus","bcname",$bcname);  //check to seee if the name of this new crumb already exists on the database
	dbg("c","getvalue of result array= $getvalue , bcname  = $bcname");
	$tempvalBC=$getvalue;
	if ($bcname==$getvalue) {  //if name of the new breadcrumb exists in the database already then this new crumb serial no has the same name of an existing crumb so we are assuming it is replacing it
		$getvalue=getdbvalue("serialno","laststatus","bcname",$bcname);
		dbg("c","getvalue of result array= $getvalue , looking for old serial no for name = $bcname");
		dbg("c","new crumb serial no=$serialno replacing crumb $tempvalBC serial no $getvalue ");
		$changenotes="new crumb serial no=$serialno replacing crumb $tempvalBC serial no $getvalue";
		updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
		$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables


	} //end if ($bcname==$getvalue)
	//update status now due to this is a new device on the network
	updatebclaststatus("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
}  //end if ($serialno==$getvalue) 
//end of *Check 0


//####################
//*CHECK 1 Check for change of ipaddresss on bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("sysip","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , bcIP  = $bcIP");
if ($bcIP==$getvalue) {
dbg("c","bcIP of $bcIP=$getvalue");
dbg("c","do nothing ips match");
}else{			
$changenotes="ipaddress changed on crumb $bcname serial no $serialno new=$bcIP old=$getvalue";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables

}//end of *Check 1

//####################
//CHECK 2 Check for change of gpsmode AKA gps recognised via bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("gpsmode","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , gpsmode  = $gpsmode");
if ($gpsmode==$getvalue) {
dbg("c","gpsmode of $gpsmode=$getvalue");
dbg("c","do nothing gpsmode match");
}else{			
$changenotes="GPS mode has changed on crumb $bcname serial no $serialno , gps status changed to $gpsmode from $getvalue!";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables

}//end of *Check 2
	
//####################
//CHECK 3 Check for change of notes via bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("notes","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , new notes  = $notes");
if ($notes==$getvalue) {
dbg("c","new notes of $notes=$getvalue");
dbg("c","do nothing notes match");
}else{			
$changenotes="notes information has changed on crumb $bcname serial no $serialno new=$notes old=$getvalue";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 3


//####################
//CHECK 4 Check for change of version via bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("version","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , version  = $version");
if ($version==$getvalue) {
dbg("c","version $version=$getvalue");
dbg("c","do nothing version match");
}else{			
$changenotes="version information has changed on crumb $bcname  new=$version old =$getvalue";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 4



//####################
//CHECK 5` First check for change of state of wired connection 0 on bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("wire0state","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , wire0state  = $wire0state");
if ($wire0state==$getvalue) {
dbg("c","wire0state of $wire0state=$getvalue");
dbg("c","do nothing wire0state match");
}else{			
$changenotes="wire0state changed from $getvalue to $wire0state on crumb $bcname serial no $serialno";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 5



//####################
//CHECK 6` First check for change of state of wired connection 1 on bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("wire1state","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , wire1state  = $wire1state");
if ($wire1state==$getvalue) {
dbg("c","wire0state of $wire1state=$getvalue");
dbg("c","do nothing wire1state match");
}else{			
$changenotes="wire1state changed from $getvalue to $wire1state on crumb $bcname serial no $serialno";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 6



//####################
//CHECK 7` First check for change of channel of radio 0 channels on bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("radio0channel","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , radio0channel  = $radio0channel");
if ($radio0channel==$getvalue) {
dbg("c","radio0channel of $radio0channel=$getvalue");
dbg("c","do nothing radio0channel match");
}else{			
$changenotes="radio0channel changed from $getvalue to $radio0channel on crumb $bcname serial no $serialno";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 7



//####################
//CHECK 8` First check for change of channel of radio 1 channels on bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("radio1channel","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , radio1channel  = $radio1channel");
if ($radio1channel==$getvalue) {
dbg("c","radio1channel of $radio1channel=$getvalue");
dbg("c","do nothing radio1channel match");
}else{			
$changenotes="radio1channel changed from $getvalue to $radio1channel on crumb $bcname serial no $serialno";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 8




//####################
//CHECK 9` First check for change of channel of radio 2 channels on bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("radio2channel","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , radio2channel  = $radio2channel");
if ($radio2channel==$getvalue) {
dbg("c","radio2channel of $radio2channel=$getvalue");
dbg("c","do nothing radio2channel match");
}else{			
$changenotes="radio2channel changed from $getvalue to $radio2channel on crumb $bcname serial no $serialno";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 9



//####################
//CHECK 10` First check for change of channel of radio 3 channels on bc serial number
//####################
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvalue=getdbvalue("radio3channel","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvalue , radio3channel  = $radio3channel");
if ($radio3channel==$getvalue) {
dbg("c","radio3channel of $radio3channel=$getvalue");
dbg("c","do nothing radio3channel match");
}else{			
$changenotes="radio3channel changed from $getvalue to $radio3channel on crumb $bcname serial no $serialno";
dbg("c","changenotes=$changenotes");
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	
}//end of *Check 10



//####################
//CHECK 11 Check for change of gps location via bc serial number
//#################### 
//getdbvalue('selectcoumnvalue','table','columname','testvalue')
$getvaluelat=getdbvalue("gpslat","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvaluelat , gpslat  = $gpslat");

$getvaluelon=getdbvalue("gpslon","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvaluelon , gpslon  = $gpslon");

$getvaluebootcounter=getdbvalue("bootcounter","laststatus","serialno",$serialno);
dbg("c","getvalue of result array= $getvaluebootcounter , bootcounter  = $bootcounter");


$templat1=FixPosForGoogleEarth($gpslat);
$templon1=FixPosForGoogleEarth($gpslon);
$templat2=FixPosForGoogleEarth($getvaluelat);
$templon2=FixPosForGoogleEarth($getvaluelon);

$GPSdifference=distance($templat1, $templon1, $templat2, $templon2, "K");
$GPSdifference=round(abs($GPSdifference*1000));


if (($gpslat==$getvaluelat) and ($gpslon==$getvaluelon)){
	dbg("c","gpslat of $gpslat=$getvaluelat");
	dbg("c","gpslon of $gpslon=$getvaluelon");
	dbg("c","do nothing lat and lon match");
}else{			
	if (($GPSdifference>=$GLOBALS[MinDistanceGPSMovementTrigger]) and ($gpssatsinview>=$GLOBALS[MinNoOfGPSSats])){
		if ($getvaluebootcounter == $bootcounter) $changenotes="GPS co-ords have changed on crumb $bcname serial no $serialno , gps was ".$getvaluelat."/".$getvaluelon." now ".$gpslat."/".$gpslon." by ".$GPSdifference."m !";
		if ($getvaluebootcounter != $bootcounter) $changenotes="GPS co-ords have changed on crumb $bcname serial no $serialno , gps was ".$getvaluelat."/".$getvaluelon." now ".$gpslat."/".$gpslon." by ".$GPSdifference."m Reboot Detected !";
		dbg("c","changenotes=$changenotes");
		updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
		$nameipA=fillnameipA("bcchanges");  //refresh the namipA array for crossreferencing bcname and details in peers tables
	}
}//end of *Check 11

#$getvalue="\t\t<td class='pad' bgcolor=$bg align='center'><nobr><a href=\"https://www.google.com.au/maps/dir/-30.027687,153.19754/-30.0278261,153.197843/@-30.0281605,153.1963597,18z\">[Gmap]</a></nobr></td>\n";
#$changenotes="#F=> GPS co-ords have changed on crumb $bcname serial no $serialno , gps was ".$getvaluelat."/".$getvaluelon." now ".$gpslat."/".$gpslon." by ".$GPSdifference."m !";
#$changenotes=$getvalue;
#dbg("c","changenotes=$changenotes");
#updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");


  
	
	

//####################
//UPDATE DB's  section that finishes updating various databases
//####################
updatebclaststatus("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
$reasonforentry="last seen this crumb st this location $sitename"; //reason for entry into the bchistory database THIS TEXT 'last seen this crumb st this location' TRIGGERS AN UPDATE OF THE OLD RECORD` , NOT A NEW ENTRY
updatebchistory("$entrydate","$basemodel","$bcname","$belongstogroup","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio1mac","$radio2mac","$radio3mac","$serialno","$sysip","$version","$wire0mac","$wire1mac","$sitename","$reasonforentry");
//peers section for updating the peers database
/* peers array looks like this
    [0] => _wireless_0_peer_00156d6ad7e1_mac=00156d6ad7e1
    [1] => _wireless_0_peer_00156d6ad7e1_action=ADD
    [2] => _wireless_0_peer_00156d6ad7e1_enabled=1
    [3] => _wireless_0_peer_00156d6ad7e1_cost=3287
    [4] => _wireless_0_peer_00156d6ad7e1_rate=540
    [5] => _wireless_0_peer_00156d6ad7e1_rssi=61
    [6] => _wireless_0_peer_00156d6ad7e1_signal=-35
    [7] => _wireless_0_peer_00156d6ad7e1_encapId=21839
    [8] => _wireless_0_peer_00156d6ad7e1_ipv4Address=0.0.0.0
	
	 [0] => _wireless_0_peer_00156d6ad849_mac=00156d6ad849
    [1] => _wireless_0_peer_00156d6ad849_action=ADD
    [2] => _wireless_0_peer_00156d6ad849_enabled=1
    [3] => _wireless_0_peer_00156d6ad849_cost=4328
    [4] => _wireless_0_peer_00156d6ad849_rate=540
    [5] => _wireless_0_peer_00156d6ad849_rssi=54
    [6] => _wireless_0_peer_00156d6ad849_signal=-41
    [7] => _wireless_0_peer_00156d6ad849_encapId=21839
    [8] => _wireless_0_peer_00156d6ad849_ipv4Address=192.168.3.230
    [9] => _wired_0_peer_00d012d9ee43_mac=00d012d9ee43
    [10] => _wired_0_peer_00d012d9ee43_action=ADD
    [11] => _wired_0_peer_00d012d9ee43_enabled=1
    [12] => _wired_0_peer_00d012d9ee43_cost=217
    [13] => _wired_0_peer_00d012d9ee43_encapId=21839
    [14] => _wired_0_peer_00d012d9ee43_ipv4Address=192.168.3.230
)

*/
	
$uniqueid="";   //macadress unique identifier
$uniquecount=0;	 //count the no of records for this mac address
foreach ($monsterpeerarray as $line){  //now read each line of data from the monster peer array
	$tempA=explode("=",$line); //split each entry at the = into array $tempA
	//find our uniqueid no to ensure records are not mixed up where uniqueid="00156d6ad7e1" from >  _wireless_0_peer_00156d6ad7e1_mac=00156d6ad7e1
	$tempQ=explode(chr(95),$tempA[0]);  //split the first element of the array into arrayQ split via _
	if ($uniqueid=="") {
		$uniquecount=0;  //reset counter to 0
		$uniqueid=$tempQ[4];  //mac address in the first element
		$moredetail=$tempQ[1].$tempQ[2]; //returns 'wireless0' as our moredetail name
		$tempn=$moredetail."name";
		if ($tempn=="wireless0name") $tempn=$radio0name;
		if ($tempn=="wireless1name") $tempn=$radio1name;
		if ($tempn=="wireless2name") $tempn=$radio2name;
		if ($tempn=="wireless3name") $tempn=$radio3name;
		if ($tempn=="wired0name") $tempn=$wire0name;  //yet2do check this
		if ($tempn=="wired1name") $tempn=$wire1name;
		$moredetail=$moredetail.",".$tempn; //returns 'wireless0,wlan0' as our moredetail name
		dbg("d","".$moredetail);
		dbg("d","id1");
		###sleep (1);
		$tempn=$tempQ[1].$tempQ[2]."channel";
		if ($tempn=="wireless0channel") $tempn=$radio0channel." [".$radio0freqDesc."]";
		if ($tempn=="wireless1channel") $tempn=$radio1channel." [".$radio1freqDesc."]";
		if ($tempn=="wireless2channel") $tempn=$radio2channel." [".$radio2freqDesc."]";
		if ($tempn=="wireless3channel") $tempn=$radio3channel." [".$radio3freqDesc."]";
		if ($tempn=="wired0channel") $tempn=$wire0state;//yet2do check this
		if ($tempn=="wired1channel") $tempn=$wire1state;
		$moredetail=$moredetail.",".$tempn; //returns 'wireless0,wlan0,11[2.4ghz]' as our moredetail name
		dbg("d","".$moredetail);
		dbg("d","id1");
		#sleep (11);
	} //end of 'if uniqueid'
	$TA=substr($tempA[0],strlen($tempA[0])-4);  //return last 4 characters in the earray "_wireless_0_peer_00156d6ad7e1_mac" becomes "_mac"
	#dbg("d","last for characters in string =".$TA);
	$tempA[1]=trim($tempA[1],chr(34)); // trim here the "" first to simplify things later
	$tempA[1]=trim($tempA[1]);  // trim here the whitespaces and crlf to simplify things later
	switch ($TA){
//find our variables from the admin array		
		case "_mac":   //_wireless_0_peer_00156d6ad7e1_mac
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$mac=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "tion":   //_wireless_0_peer_00156d6ad7e1_action
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$action=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "bled":   //_wireless_0_peer_00156d6ad7e1_enabled
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$enabled=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "cost":   //_wireless_0_peer_00156d6ad7e1_cost
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$cost=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "rate":   //_wireless_0_peer_00156d6ad7e1_rate
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$rate=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "rssi":   //_wireless_0_peer_00156d6ad7e1_rssi
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$rssi=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "gnal":   //_wireless_0_peer_00156d6ad7e1_signal
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$ssignal=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "apId":   //_wireless_0_peer_00156d6ad7e1_encapId
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			#we dont need this one $???=$get;
			break;
		case "ress":   //_wireless_0_peer_00156d6ad7e1_ipv4Address
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$address=$get;
			$uniquecount=$uniquecount+1;
			break;
		}   //end switch
	#$thiscountmax=0;	
	if ($tempQ[1]=="wireless") $thiscountmax=8;  //8 fields are got
	if ($tempQ[1]=="wired") $thiscountmax=5;   //5 fields are got
	
	if ($uniquecount==$thiscountmax) {  //we have got all our record values time to update the database entry *remember == to force type comapare like values
	//find connected breadcrumb name via ip lookup in saved array in memory '$nameipA'
	//	
	#dbg("o","array nameipA below");
	#dbg("o","".print_r($nameipA));
	dbg("d","find our unique mac no to get connected bcname and moredetail from the array nameipA");
	###sleep (2);
	//############
	//find our unique mac no to get $connectedbcname and moredetail from the array preloaded from bcchanges via function ""function fillnameipA($table){"" where table is bcchanges writtento array $nameipA``
	//############
	$connectedbcname="unknown";  //set first incase not found
	$Amaxno=count($nameipA);
	dbg("d","xtot=".$Amaxno);
	for ($x=0;$x<$Amaxno;$x++){ //autoincrement through the array counter 
		dbg("d","x=$x");
		dbg("d","$x=".$nameipA[$x]);
		$tempA=explode(",",$nameipA[$x]); //split each entry at the = into array $tempA
		#dbg("d",$x=".$nameipA[$x]);
		#dbg("d",$tempA[0]."''".$tempA[1]."''".$tempA[2]."''".$tempA[3]."''".$tempA[4]."''".$tempA[5]);
		//output is like this 00156d6ad7e1,192.168.3.230,cams test bc,wlan1,11,2015-11-07 07:44:51
		if ($tempA[0]==$mac){ //if this array record is our mac address then
			$connectedbcname=$tempA[2];
			if ($moredetail == "") $moredetail=",,"; //insert the 3 fields with a commas incase its blank see above at $moredetail=$moredetail.",".$tempn; //returns 'wireless0,wlan0' as our moredetail name
			$moredetail=$moredetail.",".$tempA[3].",".$tempA[4];   //moredetail =""int,int name,int freq/state,otherintname,freq/state"" eg wireless0,Wlan1,11,Wlan3,11
			dbg("d","".$moredetail);
			dbg("d","id2");
			###sleep (10);
			break;
		}else{
			$connectedbcname="unknown";
			if ($moredetail == "") $moredetail=","; //insert the two fields with a comma incase its blank see above at $moredetail=$moredetail.",".$tempn; //returns 'wireless0,wlan0' as our moredetail name
			#$moredetail=$moredetail.",unknown cct";
		} //end if tempA


    ###sleep (1);
	} //end foreach nameip
	dbg("d","connectedbcname=$connectedbcname");
	dbg("d","moredetail=$moredetail");
	###sleep(5);
		updatepeers("$seq","$serialno","$bcname","$entrydate","$address","$connectedbcname","$mac","$action","$enabled","$cost","$rate","$rssi","$ssignal","$sitename","$moredetail");
		$uniquecount=0; //reset counter to ensure we build the next number of correct table entries`
		$uniqueid="";  //reset this variable to build the next record for insertion
	} //id 'if uniqueid=7'
}  //end foreach			


//update the admin databse section
/*			$adminarray example is below
	[0] => _adminSessions_24761520_userAgent=bcctl2
    [1] => _adminSessions_24761520_remoteUsername=
    [2] => _adminSessions_24761520_remoteOS=
    [3] => _adminSessions_24761520_role=CO
    [4] => _adminSessions_24761520_address=[::FFFF:192.168.3.16]:54800
*/

$uniqueid="";   //record entry unique identifier 24761520
$uniquecount=0;	 //count the no of records for this mac address
foreach ($adminarray as $line){  //now read each line of data from the admin array
	$tempA=explode("=",$line); //split each entry at the = into array $tempA
	//find our uniqueid no to ensure records are not mixed up where uniqueid="00156d6ad7e1" from >  _wireless_0_peer_00156d6ad7e1_mac=00156d6ad7e1
	$tempQ=explode(chr(95),$tempA[0]);  //split the first element of the array into arrayQ split via _
	#dbg("d",$tempQ[0]-$tempQ[1]-$tempQ[2]");
	
	if ($uniqueid=="") {
		$uniquecount=0;  //reset counter to 0
		$uniqueid=$tempQ[2];  //record id in the first element
	} //end of 'if uniqueid'
	$TA=substr($tempA[0],strlen($tempA[0])-4);  //return last 4 characters in the earray "_adminSessions_24761520_userAgent" becomes "gent"
	#dbg("d",$TA");
	####sleep(10);
	$tempA[1]=trim($tempA[1],chr(34)); // trim here the "" first to simplify things later
	$tempA[1]=trim($tempA[1]);  // trim here the whitespaces and crlf to simplify things later


	switch ($TA){
//find our variables from the admin array		
		case "gent":   //_adminSessions_24761520_userAgent
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$useragent=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "name":   //_adminSessions_24761520_remoteUsername
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$remoteusername=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "teOS":   //_adminSessions_24761520_remoteOS
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$remoteos=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "role":   //_adminSessions_24761520_role
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$role=$get;
			$uniquecount=$uniquecount+1;
			break;
		case "ress":   //_adminSessions_24761520_address
			$get=trim($tempA[1],chr(34));  //remove the " from the required returned text"
			dbg("d","".$get);
			$address=$get;
			$uniquecount=$uniquecount+1;
			break;
		}   //end switch

	if ($uniquecount==5) {  //we have got all our record values time to update the database entry *remember use == not just = as it failed everytime and i wasted 2 hours faultfinding 
		updateadmin("$seq","$entrydate","$useragent","$remoteusername","$remoteos","$role","$address","$sitename");
		$uniquecount=0; //reset counter to ensure we build the next number of correct table entries`
		$uniqueid="";  //reset this variable to build the next record for insertion
	} //id 'if uniqueid=7'
}  //end foreach			


}else{ //else if Connection refused meaning device is NOT a breadcrumb
//runseq,entrydate,status,basemodel,bcname,serialno,bcstatus,sysip
updateipstatus("$seq","$polltime","$Pingreturn","unknown device","NA","NA","","$bcIP","$sitename");
	
}


} //end function pollbc
/////////////////////////////////////////////////////////////////////////////////////////////////////////




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//PINGADDRESS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function pingAddress($ip) {
	dbg("g","Attempting ping for 1 second to $ip");
	#sleep (10);
    $pingresult = exec("ping -c1 -w1 $ip", $outcome, $status); 
	
    if ($status==0) {
    $status = "up";
    } else {
    $status = "down";
    }
	dbg("o","$outcome[1]");
	dbg("o","$outcome[2]");
	dbg("o","$outcome[3]");
	dbg("o","$outcome[4]");
	dbg("o","PingStstus $ip $status");


	#    $message .= '<div id="dialog-block-left">';
#    $message .= '<div id="ip-status">The IP address, '.$ip.', is  '.$status.'</div><div style="clear:both"></div>';    
    return $status;
}






///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//updateipstatus
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateipstatus($d1="",$d2="",$d3="",$d4="",$d5="",$d6="",$d7="",$d8="",$d9=""){
/*
CREATE TABLE IF NOT EXISTS ipstatus (
   runseq INT(12) NOT NULL,
   entrydate DATE DEFAULT NULL,
   status VARCHAR(4) DEFAULT NULL,
   basemodel VARCHAR(20) DEFAULT NULL,
   bcname VARCHAR(40) DEFAULT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,
   bcstatus INT(1)  DEFAULT NULL,
   sysip VARCHAR(16)  DEFAULT NULL,
   sitename varchar(40) DEFAULT NULL,
  PRIMARY KEY (sysip)
);
runseq,entrydate,status,basemodel,bcname,serialno,bcstatus,sysip
*/
$d1=(int)$d1;
$d2=$d2;
$d3=(string)$d3;
$d4=(string)$d4;
$d5=(string)$d5;
$d6=(string)$d6;
$d7=(int)$d7;
$d8=(string)$d8;
$d9=(string)$d9;

/*	
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

$query = "INSERT INTO ipstatus (runseq,entrydate,status,basemodel,bcname,serialno,bcstatus,sysip,sitename)" .
		" VALUES ('$d1', '$d2', '$d3', '$d4', '$d5', '$d6', '$d7', '$d8', '$d9')";
$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");
###sleep(3);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//UPDATEBCDATA
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updatebcdata($d1="",$d2="",$d3="",$d4="",$d5="",$d6="",$d7="",$d8="",$d9="",$d10="",$d11="",$d12="",$d13="",$d14="",$d15="",$d16="",$d17="",$d18="",$d19="",$d20="",$d21="",$d22="",$d23="",$d24="",$d25="",$d26="",$d27="",$d28="",$d29="",$d30="",$d31="",$d32="",$d33="",$d34="",$d35="",$d36="",$d37="",$d38="",$d39="",$d40="",$d41="",$d42="",$d43="",$d44="",$d45="",$d46="",$d47="",$d48="",$d49="",$d50="",$d51="",$d52="",$d53="",$d54="",$d55="",$d56="",$d57="",$d58="",$d59="",$d60="",$d61="",$d62="",$d63="",$d64="",$d65="",$d66="",$d67="",$d68="",$d69="",$d70="",$d71="",$d72="",$d73="",$d74="",$d75="",$d76=""){
//68 entries to insert
/*

CREATE TABLE IF NOT EXISTS bcdata (
   runseq INT(12) NOT NULL,
   entrydate DATE DEFAULT NULL,
   aptpriority VARCHAR(3) DEFAULT NULL,
   basemodel VARCHAR(20) DEFAULT NULL,
   bcname VARCHAR(40) DEFAULT NULL,
   bcstatus INT(1)  DEFAULT NULL,
   bestcost VARCHAR(8) DEFAULT NULL,
   belongstogroup VARCHAR(80) DEFAULT NULL,
   bootcounter INT(12)  DEFAULT NULL,
   goodcostcount INT(2) DEFAULT NULL,
   gpsalt VARCHAR(12)  DEFAULT NULL,
   gpslat VARCHAR(12)  DEFAULT NULL,
   gpslon VARCHAR(12)  DEFAULT NULL,
   gpsmode INT(1)  DEFAULT NULL,
   gpsswitchenabled INT(1)  DEFAULT NULL,
   gpstime INT(12)  DEFAULT NULL,
   gpsquality INT(12)  DEFAULT NULL,
   gpssatsinview INT(2)  DEFAULT NULL,
   gpsgeoid VARCHAR(100) DEFAULT NULL,
   groupinteratorcount INT(2)  DEFAULT NULL,
   model VARCHAR(80) DEFAULT NULL,
   networkname VARCHAR(40) DEFAULT NULL,
   notes VARCHAR(200) DEFAULT NULL,
   radio0active INT(1)  DEFAULT NULL,
   radio0bandwidth INT(2)  DEFAULT NULL,
   radio0channel INT(3)  DEFAULT NULL,
   radio0mac VARCHAR(12)  DEFAULT NULL,
   radio0meshenabled INT(1)  DEFAULT NULL,
   radio0name VARCHAR(5) DEFAULT NULL,
   radio0noofaps INT(1)  DEFAULT NULL,
   radio0noofpeers INT(3)  DEFAULT NULL,
   radio1active INT(1)  DEFAULT NULL,
   radio1bandwidth INT(2)  DEFAULT NULL,
   radio1channel INT(3)  DEFAULT NULL,
   radio1mac VARCHAR(12)  DEFAULT NULL,
   radio1meshenabled INT(1)  DEFAULT NULL,
   radio1name VARCHAR(5) DEFAULT NULL,
   radio1noofaps INT(1)  DEFAULT NULL,
   radio1noofpeers INT(3)  DEFAULT NULL,
   radio2active INT(1)  DEFAULT NULL,
   radio2bandwidth INT(2)  DEFAULT NULL,
   radio2channel INT(3)  DEFAULT NULL,
   radio2mac VARCHAR(12)  DEFAULT NULL,
   radio2meshenabled INT(1)  DEFAULT NULL,
   radio2name VARCHAR(5) DEFAULT NULL,
   radio2noofaps INT(1)  DEFAULT NULL,
   radio2noofpeers INT(3)  DEFAULT NULL,
   radio3active INT(1)  DEFAULT NULL,
   radio3bandwidth INT(2)  DEFAULT NULL,
   radio3channel INT(3)  DEFAULT NULL,
   radio3mac VARCHAR(12)  DEFAULT NULL,
   radio3meshenabled INT(1)  DEFAULT NULL,
   radio3name VARCHAR(5) DEFAULT NULL,
   radio3noofaps INT(1)  DEFAULT NULL,
   radio3noofpeers INT(3)  DEFAULT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,
   sysip VARCHAR(16)  DEFAULT NULL,
   totalnoofpeers INT(3)  DEFAULT NULL,
   uptime INT(12)  DEFAULT NULL,
   version VARCHAR(12)  DEFAULT NULL,
   wire0mac VARCHAR(12)  DEFAULT NULL,
   wire0name VARCHAR(5) DEFAULT NULL,
   wire0state VARCHAR(20)  DEFAULT NULL,
   wire1mac VARCHAR(12)  DEFAULT NULL,
   wire1name VARCHAR(5) DEFAULT NULL,
   wire1state VARCHAR(20)  DEFAULT NULL,
   openadminsessionstot INT(2)  DEFAULT NULL,   
   sitename VARCHAR(40) DEFAULT NULL,
   radio0model VARCHAR(8) DEFAULT NULL,
   radio1model VARCHAR(8) DEFAULT NULL,
   radio2model VARCHAR(8) DEFAULT NULL,
   radio3model VARCHAR(8) DEFAULT NULL,
   radio0freq VARCHAR(25) DEFAULT NULL,
   radio1freq VARCHAR(25) DEFAULT NULL,
   radio2freq VARCHAR(25) DEFAULT NULL,
   radio3freq VARCHAR(25) DEFAULT NULL
);

);
runseq,entrydate,aptpriority,basemodel,bcname,bcstatus,bestcost,belongstogroup,bootcounter,goodcostcount,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,groupinteratorcount,model,networkname,notes,radio0active,radio0bandwidth,radio0channel,radio0mac,radio0meshenabled,radio0name,radio0noofaps,radio0noofpeers,radio1active,radio1bandwidth,radio1channel,radio1mac,radio1meshenabled,radio1name,radio1noofaps,radio1noofpeers,radio2active,radio2bandwidth,radio2channel,radio2mac,radio2meshenabled,radio2name,radio2noofaps,radio2noofpeers,radio3active,radio3bandwidth,radio3channel,radio3mac,radio3meshenabled,radio3name,radio3noofaps,radio3noofpeers,serialno,sysip,totalnoofpeers,uptime,version,wire0mac,wire0name,wire0state,wire1mac,wire1name,wire1state,openadminsessionstot,radio0model,radio1model,radio2model,radio3model,radio0freq,radio1freq,radio2freq,radio3freq



   */

$d1=(int)$d1; //   runseq INT(12) NOT NULL,
$d2=$d2; //   entrydate DATE DEFAULT NULL,
$d3=(string)$d3; //   aptpriority VARCHAR(3) DEFAULT NULL,
$d4=(string)$d4; //   basemodel VARCHAR(20) DEFAULT NULL,
$d5=(string)$d5; //   bcname VARCHAR(40) DEFAULT NULL,
$d6=(int)$d6; //   bcstatus INT(1)  DEFAULT NULL,
$d7=(string)$d7; //   bestcost VARCHAR(8) DEFAULT NULL,
$d8=(string)$d8; //   belongstogroup VARCHAR(80) DEFAULT NULL,
$d9=(int)$d9; //   bootcounter INT(12)  DEFAULT NULL,
$d10=(int)$d10; //   goodcostcount INT(2) DEFAULT NULL,
$d11=(string)$d11; //   gpsalt VARCHAR(12)  DEFAULT NULL,
$d12=(string)$d12; //   gpslat VARCHAR(12)  DEFAULT NULL,
$d13=(string)$d13; //   gpslon VARCHAR(12)  DEFAULT NULL,
$d14=(int)$d14; //   gpsmode INT(1)  DEFAULT NULL,
$d15=(int)$d15; //   gpsswitchenabled INT(1)  DEFAULT NULL,
$d16=(int)$d16; //   gpstime INT(12)  DEFAULT NULL,
$d17=(int)$d17; //   gpsquality INT(12)  DEFAULT NULL,
$d18=(int)$d18; //   gpssatsinview INT(2)  DEFAULT NULL,
$d19=(string)$d19; //   gpsgeoid VARCHAR(100) DEFAULT NULL,
$d20=(int)$d20; //   groupinteratorcount INT(2)  DEFAULT NULL,
$d21=(string)$d21; //   model VARCHAR(80) DEFAULT NULL,
$d22=(string)$d22; //   networkname VARCHAR(40) DEFAULT NULL,
$d23=(string)$d23; //   notes VARCHAR(200) DEFAULT NULL,
$d24=(int)$d24; //   radio0active INT(1)  DEFAULT NULL,
$d25=(int)$d25; //   radio0bandwidth INT(2)  DEFAULT NULL,
$d26=(int)$d26; //   radio0channel INT(3)  DEFAULT NULL,
$d27=(string)$d27; //   radio0mac VARCHAR(12)  DEFAULT NULL,
$d28=(int)$d28; //   radio0meshenabled INT(1)  DEFAULT NULL,
$d29=(string)$d29; //   radio0name VARCHAR(5) DEFAULT NULL,
$d30=(int)$d30; //   radio0noofaps INT(1)  DEFAULT NULL,
$d31=(int)$d31; //   radio0noofpeers INT(3)  DEFAULT NULL,
$d32=(int)$d32; //   radio1active INT(1)  DEFAULT NULL,
$d33=(int)$d33; //   radio1bandwidth INT(2)  DEFAULT NULL,
$d34=(int)$d34; //   radio1channel INT(3)  DEFAULT NULL,
$d35=(string)$d35; //   radio1mac VARCHAR(12)  DEFAULT NULL,
$d36=(int)$d36; //   radio1meshenabled INT(1)  DEFAULT NULL,
$d37=(string)$d37; //   radio1name VARCHAR(5) DEFAULT NULL,
$d38=(int)$d38; //   radio1noofaps INT(1)  DEFAULT NULL,
$d39=(int)$d39; //   radio1noofpeers INT(3)  DEFAULT NULL,
$d40=(int)$d40; //   radio2active INT(1)  DEFAULT NULL,
$d41=(int)$d41; //   radio2bandwidth INT(2)  DEFAULT NULL,
$d42=(int)$d42; //   radio2channel INT(3)  DEFAULT NULL,
$d43=(string)$d43; //   radio2mac VARCHAR(12)  DEFAULT NULL,
$d44=(int)$d44; //   radio2meshenabled INT(1)  DEFAULT NULL,
$d45=(string)$d45; //   radio2name VARCHAR(5) DEFAULT NULL,
$d46=(int)$d46; //   radio2noofaps INT(1)  DEFAULT NULL,
$d47=(int)$d47; //   radio2noofpeers INT(3)  DEFAULT NULL,
$d48=(int)$d48; //   radio3active INT(1)  DEFAULT NULL,
$d49=(int)$d49; //   radio3bandwidth INT(2)  DEFAULT NULL,
$d50=(int)$d50; //   radio3channel INT(3)  DEFAULT NULL,
$d51=(string)$d51; //   radio3mac VARCHAR(12)  DEFAULT NULL,
$d52=(int)$d52; //   radio3meshenabled INT(1)  DEFAULT NULL,
$d53=(string)$d53; //   radio3name VARCHAR(5) DEFAULT NULL,
$d54=(int)$d54; //   radio3noofaps INT(1)  DEFAULT NULL,
$d55=(int)$d55; //   radio3noofpeers INT(3)  DEFAULT NULL,
$d56=(string)$d56; //   serialno VARCHAR(20)  DEFAULT NULL,
$d57=(string)$d57; //   sysip VARCHAR(16)  DEFAULT NULL,
$d58=(int)$d58; //   totalnoofpeers INT(3)  DEFAULT NULL,
$d59=(int)$d59; //   uptime INT(12)  DEFAULT NULL,
$d60=(string)$d60; //   version VARCHAR(12)  DEFAULT NULL,
$d61=(string)$d61; //   wire0mac VARCHAR(12)  DEFAULT NULL,
$d62=(string)$d62; //   wire0name VARCHAR(5) DEFAULT NULL,
$d63=(string)$d63; //   wire0state VARCHAR(20)  DEFAULT NULL,
$d64=(string)$d64; //   wire1mac VARCHAR(12)  DEFAULT NULL,
$d65=(string)$d65; //   wire1name VARCHAR(5) DEFAULT NULL,
$d66=(string)$d66; //   wire1state VARCHAR(20)  DEFAULT NULL,
$d67=(int)$d67; //   openadminsessionstot INT(2)  DEFAULT NULL,   
$d68=(string)$d68; //   sitename VARCHAR(40) DEFAULT NULL,
$d69=(string)$d69; //  radio0model VARCHAR(8) DEFAULT NULL,
$d70=(string)$d70; //   radio1model VARCHAR(8) DEFAULT NULL,
$d71=(string)$d71; //   radio2model VARCHAR(8) DEFAULT NULL,
$d72=(string)$d72; //   radio3model VARCHAR(8) DEFAULT NULL,
$d73=(string)$d73; //   radio0freq VARCHAR(25) DEFAULT NULL,
$d74=(string)$d74; //   radio1freq VARCHAR(25) DEFAULT NULL,
$d75=(string)$d75; //   radio2freq VARCHAR(25) DEFAULT NULL,
$d76=(string)$d76; //   radio3freq VARCHAR(25) DEFAULT NULL
/*
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

$query = "INSERT INTO bcdata (runseq,entrydate,aptpriority,basemodel,bcname,bcstatus,bestcost,belongstogroup,bootcounter,goodcostcount,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,groupinteratorcount,model,networkname,notes,radio0active,radio0bandwidth,radio0channel,radio0mac,radio0meshenabled,radio0name,radio0noofaps,radio0noofpeers,radio1active,radio1bandwidth,radio1channel,radio1mac,radio1meshenabled,radio1name,radio1noofaps,radio1noofpeers,radio2active,radio2bandwidth,radio2channel,radio2mac,radio2meshenabled,radio2name,radio2noofaps,radio2noofpeers,radio3active,radio3bandwidth,radio3channel,radio3mac,radio3meshenabled,radio3name,radio3noofaps,radio3noofpeers,serialno,sysip,totalnoofpeers,uptime,version,wire0mac,wire0name,wire0state,wire1mac,wire1name,wire1state,openadminsessionstot,sitename,radio0model,radio1model,radio2model,radio3model,radio0freq,radio1freq,radio2freq,radio3freq)" .
		" VALUES ('$d1','$d2','$d3','$d4','$d5','$d6','$d7','$d8','$d9','$d10','$d11','$d12','$d13','$d14','$d15','$d16','$d17','$d18','$d19','$d20','$d21','$d22','$d23','$d24','$d25','$d26','$d27','$d28','$d29','$d30','$d31','$d32','$d33','$d34','$d35','$d36','$d37','$d38','$d39','$d40','$d41','$d42','$d43','$d44','$d45','$d46','$d47','$d48','$d49','$d50','$d51','$d52','$d53','$d54','$d55','$d56','$d57','$d58','$d59','$d60','$d61','$d62','$d63','$d64','$d65','$d66','$d67','$d68','$d69','$d70','$d71','$d72','$d73','$d74','$d75','$d76')";
dbg("d","$query INSERT INTO bcdata=".chr(10).$query.chr(10));
$msqlr=mysql_query($query);
dbg("d","$msqlr");
#sleep(5);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//UPDATEBCLASTSTATUS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updatebclaststatus($d1="",$d2="",$d3="",$d4="",$d5="",$d6="",$d7="",$d8="",$d9="",$d10="",$d11="",$d12="",$d13="",$d14="",$d15="",$d16="",$d17="",$d18="",$d19="",$d20="",$d21="",$d22="",$d23="",$d24="",$d25="",$d26="",$d27="",$d28="",$d29="",$d30="",$d31="",$d32="",$d33="",$d34="",$d35="",$d36="",$d37="",$d38="",$d39="",$d40="",$d41="",$d42="",$d43="",$d44="",$d45="",$d46="",$d47="",$d48="",$d49="",$d50="",$d51=""){
// entries to insert
/*



CREATE TABLE IF NOT EXISTS laststatus (
   runseq INT(12) NOT NULL,
   entrydate DATE DEFAULT NULL,
   basemodel VARCHAR(20) DEFAULT NULL,
   bcname VARCHAR(40) DEFAULT NULL,
   bcstatus INT(1)  DEFAULT NULL,
   bestcost VARCHAR(8) DEFAULT NULL,
   belongstogroup VARCHAR(80) DEFAULT NULL,
   bootcounter INT(12)  DEFAULT NULL,
   goodcostcount VARCHAR(2) DEFAULT NULL,
   gpsalt VARCHAR(12)  DEFAULT NULL,
   gpslat VARCHAR(12)  DEFAULT NULL,
   gpslon VARCHAR(12)  DEFAULT NULL,
   gpsmode INT(1)  DEFAULT NULL,
   gpsswitchenabled INT(1)  DEFAULT NULL,
   gpstime INT(12)  DEFAULT NULL,
   gpsquality INT(12)  DEFAULT NULL,
   gpssatsinview INT(2)  DEFAULT NULL,
   gpsgeoid VARCHAR(100) DEFAULT NULL,
   networkname VARCHAR(40) DEFAULT NULL,
   notes VARCHAR(200) DEFAULT NULL,
   radio0mac VARCHAR(12)  DEFAULT NULL,
   radio0meshenabled INT(1)  DEFAULT NULL,
   radio0name VARCHAR(5) DEFAULT NULL,
   radio0noofpeers INT(3)  DEFAULT NULL,
   radio1mac VARCHAR(12)  DEFAULT NULL,
   radio1meshenabled INT(1)  DEFAULT NULL,
   radio1name VARCHAR(5) DEFAULT NULL,
   radio1noofpeers INT(3)  DEFAULT NULL,
   radio2mac VARCHAR(12)  DEFAULT NULL,
   radio2meshenabled INT(1)  DEFAULT NULL,
   radio2name VARCHAR(5) DEFAULT NULL,
   radio2noofpeers INT(3)  DEFAULT NULL,
   radio3mac VARCHAR(12)  DEFAULT NULL,
   radio3meshenabled INT(1)  DEFAULT NULL,
   radio3name VARCHAR(5) DEFAULT NULL,
   radio3noofpeers INT(3)  DEFAULT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,
   sysip VARCHAR(16)  DEFAULT NULL,
   totalnoofpeers INT(3)  DEFAULT NULL,
   version VARCHAR(12)  DEFAULT NULL,
   wire0mac VARCHAR(12)  DEFAULT NULL,
   wire0name VARCHAR(5) DEFAULT NULL,
   wire0state VARCHAR(20)  DEFAULT NULL,
   wire1mac VARCHAR(12)  DEFAULT NULL,
   wire1name VARCHAR(5) DEFAULT NULL,
   wire1state VARCHAR(20)  DEFAULT NULL,
   sitename VARCHAR(40) DEFAULT NULL,
   radio0channel INT(3)  DEFAULT NULL,
   radio1channel INT(3)  DEFAULT NULL,
   radio2channel INT(3)  DEFAULT NULL,
   radio3channel INT(3)  DEFAULT NULL
  PRIMARY KEY (serialno)
);

runseq,entrydate,basemodel,bcname,bcstatus,bestcost,belongstogroup,bootcounter,goodcostcount,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,networkname,notes,radio0mac,radio0meshenabled,radio0name,radio0noofpeers,radio1mac,radio1meshenabled,radio1name,radio1noofpeers,radio2mac,radio2meshenabled,radio2name,radio2noofpeers,radio3mac,radio3meshenabled,radio3name,radio3noofpeers,serialno,sysip,totalnoofpeers,version,wire0mac,wire0name,wire0state,wire1mac,wire1name,wire1state,sitename




*/


$d1=(int)$d1;   //   runseq INT(12) NOT NULL,
$d2=$d2;   //   entrydate DATE DEFAULT NULL,
$d3=(string)$d3;   //   basemodel VARCHAR(20) DEFAULT NULL,
$d4=(string)$d4;   //   bcname VARCHAR(40) DEFAULT NULL,
$d5=(int)$d5;   //   bcstatus INT(1)  DEFAULT NULL,
$d6=(string)$d6;   //   bestcost VARCHAR(8) DEFAULT NULL,
$d7=(string)$d7;   //   belongstogroup VARCHAR(80) DEFAULT NULL,
$d8=(int)$d8;   //   bootcounter INT(12)  DEFAULT NULL,
$d9=(string)$d9;   //   goodcostcount VARCHAR(2) DEFAULT NULL,
$d10=(string)$d10;   //   gpsalt VARCHAR(12)  DEFAULT NULL,
$d11=(string)$d11;   //   gpslat VARCHAR(12)  DEFAULT NULL,
$d12=(string)$d12;   //   gpslon VARCHAR(12)  DEFAULT NULL,
$d13=(int)$d13;   //   gpsmode INT(1)  DEFAULT NULL,
$d14=(int)$d14;   //   gpsswitchenabled INT(1)  DEFAULT NULL,
$d15=(int)$d15;   //   gpstime INT(12)  DEFAULT NULL,
$d16=(int)$d16;   //   gpsquality INT(12)  DEFAULT NULL,
$d17=(int)$d17;   //   gpssatsinview INT(2)  DEFAULT NULL,
$d18=(string)$d18;   //   gpsgeoid VARCHAR(100) DEFAULT NULL,
$d19=(string)$d19;   //   networkname VARCHAR(40) DEFAULT NULL,
$d20=(string)$d20;   //   notes VARCHAR(200) DEFAULT NULL,
$d21=(int)$d21;   //   radio0mac VARCHAR(12)  DEFAULT NULL,
$d22=(int)$d22;   //   radio0meshenabled INT(1)  DEFAULT NULL,
$d23=(string)$d23;   //   radio0name VARCHAR(5) DEFAULT NULL,
$d24=(int)$d24;   //   radio0noofpeers INT(3)  DEFAULT NULL,
$d25=(int)$d25;   //   radio1mac VARCHAR(12)  DEFAULT NULL,
$d26=(int)$d26;   //   radio1meshenabled INT(1)  DEFAULT NULL,
$d27=(string)$d27;   //   radio1name VARCHAR(5) DEFAULT NULL,
$d28=(int)$d28;   //   radio1noofpeers INT(3)  DEFAULT NULL,
$d29=(int)$d29;   //   radio2mac VARCHAR(12)  DEFAULT NULL,
$d30=(int)$d30;   //   radio2meshenabled INT(1)  DEFAULT NULL,
$d31=(string)$d31;   //   radio2name VARCHAR(5) DEFAULT NULL,
$d32=(int)$d32;   //   radio2noofpeers INT(3)  DEFAULT NULL,
$d33=(int)$d33;   //   radio3mac VARCHAR(12)  DEFAULT NULL,
$d34=(int)$d34;   //   radio3meshenabled INT(1)  DEFAULT NULL,
$d35=(string)$d35;   //   radio3name VARCHAR(5) DEFAULT NULL,
$d36=(int)$d36;   //   radio3noofpeers INT(3)  DEFAULT NULL,
$d37=(string)$d37;   //   serialno VARCHAR(20)  DEFAULT NULL,
$d38=(string)$d38;   //   sysip VARCHAR(16)  DEFAULT NULL,
$d39=(int)$d39;   //   totalnoofpeers INT(3)  DEFAULT NULL,
$d40=(string)$d40;   //   version VARCHAR(12)  DEFAULT NULL,
$d41=(int)$d41;   //   wire0mac VARCHAR(12)  DEFAULT NULL,
$d42=(string)$d42;   //   wire0name VARCHAR(5) DEFAULT NULL,
$d43=(string)$d43;   //   wire0state VARCHAR(20)  DEFAULT NULL,
$d44=(int)$d44;   //   wire1mac VARCHAR(12)  DEFAULT NULL,
$d45=(string)$d45;   //   wire1name VARCHAR(5) DEFAULT NULL,
$d46=(string)$d46;   //   wire1state VARCHAR(20)  DEFAULT NULL,
$d47=(string)$d47;   //   sitename VARCHAR(40) DEFAULT NULL,
$d48=(int)$d48;   //   radio0channel INT(3)  DEFAULT NULL,
$d49=(int)$d49;   //   radio1channel INT(3)  DEFAULT NULL,
$d50=(int)$d50;   //   radio2channel INT(3)  DEFAULT NULL,
$d51=(int)$d51;   //   radio3channel INT(3)  DEFAULT NULL,


/*
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

//1st attempt insert
$query = "INSERT INTO laststatus (runseq,entrydate,basemodel,bcname,bcstatus,bestcost,belongstogroup,bootcounter,goodcostcount,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,networkname,notes,radio0mac,radio0meshenabled,radio0name,radio0noofpeers,radio1mac,radio1meshenabled,radio1name,radio1noofpeers,radio2mac,radio2meshenabled,radio2name,radio2noofpeers,radio3mac,radio3meshenabled,radio3name,radio3noofpeers,serialno,sysip,totalnoofpeers,version,wire0mac,wire0name,wire0state,wire1mac,wire1name,wire1state,sitename,radio0channel,radio1channel,radio2channel,radio3channel)" .
		" VALUES ('$d1','$d2','$d3','$d4','$d5','$d6','$d7','$d8','$d9','$d10','$d11','$d12','$d13','$d14','$d15','$d16','$d17','$d18','$d19','$d20','$d21','$d22','$d23','$d24','$d25','$d26','$d27','$d28','$d29','$d30','$d31','$d32','$d33','$d34','$d35','$d36','$d37','$d38','$d39','$d40','$d41','$d42','$d43','$d44','$d45','$d46','$d47','$d48','$d49','$d50','$d51')";
$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");

//2nd aattempt update if exists
$query = "UPDATE laststatus SET 
   runseq = '$d1',
   entrydate = '$d2',
   basemodel = '$d3',
   bcname = '$d4',
   bcstatus = '$d5',
   bestcost = '$d6',
   belongstogroup = '$d7',
   bootcounter = '$d8',
   goodcostcount = '$d9',
   gpsalt = '$d10',
   gpslat  = '$d11',
   gpslon  = '$d12',
   gpsmode  = '$d13',
   gpsswitchenabled  = '$d14',
   gpstime  = '$d15',
   gpsquality  = '$d16',
   gpssatsinview  = '$d17',
   gpsgeoid  = '$d18',
   networkname  = '$d19',
   notes  = '$d20',
   radio0mac  = '$d21',
   radio0meshenabled  = '$d22',
   radio0name  = '$d23',
   radio0noofpeers  = '$d24',
   radio1mac  = '$d25',
   radio1meshenabled  = '$d26',
   radio1name  = '$d27',
   radio1noofpeers  = '$d28',
   radio2mac  = '$d29',
   radio2meshenabled  = '$d30',
   radio2name  = '$d31',
   radio2noofpeers  = '$d32',
   radio3mac  = '$d33',
   radio3meshenabled  = '$d34',
   radio3name  = '$d35',
   radio3noofpeers  = '$d36',
   serialno  = '$d37',
   sysip  = '$d38',
   totalnoofpeers  = '$d39',
   version  = '$d40',
   wire0mac  = '$d41',
   wire0name  = '$d42',
   wire0state  = '$d43',
   wire1mac  = '$d44',
   wire1name  = '$d45',
   wire1state  = '$d46',
   sitename  = '$d47',
   radio0channel  = '$d48',
   radio1channel  = '$d49',
   radio2channel  = '$d50',
   radio3channel  = '$d51'
   where serialno = '$d37'";


$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");



###sleep(3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//UPDATEADMIN
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateadmin($d1="",$d2="",$d3="",$d4="",$d5="",$d6="",$d7="",$d8=""){
//8 entries to insert
/*



CREATE TABLE IF NOT EXISTS admin (
   runseq INT(12) NOT NULL,
   entrydate DATE DEFAULT NULL,
   useragent VARCHAR(80) DEFAULT NULL,
   remoteusername   VARCHAR(40) DEFAULT NULL,
   remoteos VARCHAR(20) DEFAULT NULL,
   role  VARCHAR(12) DEFAULT NULL,
   address VARCHAR(40) DEFAULT NULL,
   PRIMARY KEY (remoteusername)
);
  runseq,entrydate,useragent,remoteusername,remoteos,role,address
);
*/


$d1=(int)$d1;   //   runseq INT(12) NOT NULL,
$d2=$d2;   //   entrydate DATE DEFAULT NULL,
$d3=(string)$d3;   //   useragent VARCHAR(80) DEFAULT NULL,
$d4=(string)$d4;   //   remoteusername   VARCHAR(40) DEFAULT NULL,
$d5=(string)$d5;   //   remoteos VARCHAR(20) DEFAULT NULL,
$d6=(string)$d6;   //   role  VARCHAR(12) DEFAULT NULL,
$d7=(string)$d7;   //   address VARCHAR(40) DEFAULT NULL,
$d8=(string)$d8;   //   sitename VARCHAR(40) DEFAULT NULL,

/*
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/


$query = "INSERT INTO admin (runseq,entrydate,useragent,remoteusername,remoteos,role,address,sitename)" .
		" VALUES ('$d1','$d2','$d3','$d4','$d5','$d6','$d7','$d8')";
$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");
###sleep(3);
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//UPDATEPEERS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function updatepeers($d1="",$d2="",$d3="",$d4="",$d5="",$d6="",$d7="",$d8="",$d9="",$d10="",$d11="",$d12="",$d13="",$d14="",$d15=""){
// entries to insert
/*


CREATE TABLE IF NOT EXISTS peers (
   runseq INT(12) NOT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,  --origin serial no
   bcname VARCHAR(40) DEFAULT NULL,  --origin crumb name
   entrydate DATETIME DEFAULT NULL,   
   address VARCHAR(16)  DEFAULT NULL,  --destination connected ip address
   connectedbcname VARCHAR(40) DEFAULT NULL,  --destination connected crumb
   mac VARCHAR(12) DEFAULT NULL,  --destination/connected mac address
   action VARCHAR(12) DEFAULT NULL,
   enabled INT(1) DEFAULT NULL,
   cost INT(6) DEFAULT NULL,
   rate INT(4) DEFAULT NULL,
   rssi INT(4) DEFAULT NULL,
   ssignal INT(4) DEFAULT NULL,
   sitename VARCHAR(40) DEFAULT NULL,
   moredetail VARCHAR(80) DEFAULT NULL  --our cct,cct name,channel or state,destination cct name,destination channel or state

   --MariaDB [MST_BC_TRACKER]> SELECT * FROM peers ;
--+--------+----------------+------------+---------------------+---------------+-----------------+--------------+--------+---------+-------+------+------+---------+-------------+---------------------------------------------------+
--| runseq | serialno       | bcname     | entrydate           | address       | connectedbcname | mac          | action | enabled | cost  | rate | rssi | ssignal | sitename    | moredetail                                        |
--+--------+----------------+------------+---------------------+---------------+-----------------+--------------+--------+---------+-------+------+------+---------+-------------+---------------------------------------------------+
--|      2 | LX 2424-7808   | MST17      | 2015-11-11 00:28:39 | 192.168.3.231 | MST WAP BC      | 00156d6a1f0b | ADD    |       1 | 17760 |  360 |   62 |     -37 | DevPlatform | wireless0,wlan1,11,wlan2,11                       |
--|      2 | LX 2424-7808   | MST17      | 2015-11-11 00:28:39 | 192.168.3.231 | MST WAP BC      | 00156d6a1fad | ADD    |       1 | 19825 |  360 |   57 |     -41 | DevPlatform | wireless1,wlan0,1,wlan1,1                         |
--|      2 | LX 2424-7808   | MST17      | 2015-11-11 00:28:39 | 192.168.3.231 | MST WAP BC      | 00d012e7ed99 | ADD    |       1 |   295 |  360 |   57 |     -41 | DevPlatform | wired0,eth0,APT_STATE_SLAVE,eth0,APT_STATE_MASTER |


runseq,serialno,bcname,entrydate,address,connectedbcname,mac,action,enabled,cost,rate,rssi,ssignal,sitename,moredetail
   
   
   ););
*/


$d1=(int)$d1 ;  //   runseq INT(12) NOT NULL,
$d2=(string)$d2 ;  //   serialno VARCHAR(20)  DEFAULT NULL,
$d3=(string)$d3 ;  //   bcname VARCHAR(40) DEFAULT NULL,
$d4=$d4 ;  //   entrydate DATE DEFAULT NULL,   
$d5=(string)$d5;   //   address VARCHAR(16)  DEFAULT NULL,
$d6=(string)$d6;   //   connectedbcname VARCHAR(40) DEFAULT NULL,
$d7=(string)$d7;   //   mac VARCHAR(12) DEFAULT NULL,
$d8=(string)$d8;   //   action VARCHAR(12) DEFAULT NULL,
$d9=(int)$d9;   //   enabled INT(1) DEFAULT NULL,
$d10=(int)$d10;   //   cost INT(6) DEFAULT NULL,
$d11=(int)$d11;   //   rate INT(4) DEFAULT NULL,
$d12=(int)$d12;   //   rssi INT(4) DEFAULT NULL,
$d13=(int)$d13;   //   ssignal INT(4) DEFAULT NULL,
$d14=(string)$d14;   //  sitename VARCHAR(40) DEFAULT NULL,
$d15=(string)$d15;   //   moredetail VARCHAR(80) DEFAULT NULL,
   
 /*   
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

$query = "INSERT INTO peers (runseq,serialno,bcname,entrydate,address,connectedbcname,mac,action,enabled,cost,rate,rssi,ssignal,sitename,moredetail)" .
		" VALUES ('$d1','$d2','$d3','$d4','$d5','$d6','$d7','$d8','$d9','$d10','$d11','$d12','$d13','$d14','$d15')";
$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");
###sleep(3);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
function updatebcchanges($d1="",$d2="",$d3="",$d4="",$d5="",$d6="",$d7="",$d8="",$d9="",$d10="",$d11="",$d12="",$d13="",$d14="",$d15="",$d16="",$d17="",$d18="",$d19="",$d20="",$d21="",$d22="",$d23="",$d24="",$d25="",$d26="",$d27="",$d28="",$d29="",$d30="",$d31="",$d32="",$d33="",$d34="",$d35="",$d36="",$d37="",$d38="",$d39="",$d40="",$d41="",$d42="",$d43="",$d44="",$d45="",$d46="",$d47="",$d48="",$d49="",$d50="",$d51="",$d52=""){
// entries to insert
/*
CREATE TABLE IF NOT EXISTS bcchanges (
   runseq INT(12) NOT NULL,
   entrydate DATETIME DEFAULT NULL,
   basemodel VARCHAR(20) DEFAULT NULL,
   bcname VARCHAR(40) DEFAULT NULL,
   bcstatus INT(1)  DEFAULT NULL,
   bestcost VARCHAR(8) DEFAULT NULL,
   belongstogroup VARCHAR(80) DEFAULT NULL,
   bootcounter INT(12)  DEFAULT NULL,
   goodcostcount VARCHAR(2) DEFAULT NULL,
   gpsalt VARCHAR(12)  DEFAULT NULL,
   gpslat VARCHAR(12)  DEFAULT NULL,
   gpslon VARCHAR(12)  DEFAULT NULL,
   gpsmode INT(1)  DEFAULT NULL,
   gpsswitchenabled INT(1)  DEFAULT NULL,
   gpstime INT(12)  DEFAULT NULL,
   gpsquality INT(12)  DEFAULT NULL,
   gpssatsinview INT(2)  DEFAULT NULL,
   gpsgeoid VARCHAR(100) DEFAULT NULL,
   networkname VARCHAR(40) DEFAULT NULL,
   notes VARCHAR(200) DEFAULT NULL,
   radio0mac VARCHAR(12)  DEFAULT NULL,
   radio0meshenabled INT(1)  DEFAULT NULL,
   radio0name VARCHAR(5) DEFAULT NULL,
   radio0noofpeers INT(3)  DEFAULT NULL,
   radio1mac VARCHAR(12)  DEFAULT NULL,
   radio1meshenabled INT(1)  DEFAULT NULL,
   radio1name VARCHAR(5) DEFAULT NULL,
   radio1noofpeers INT(3)  DEFAULT NULL,
   radio2mac VARCHAR(12)  DEFAULT NULL,
   radio2meshenabled INT(1)  DEFAULT NULL,
   radio2name VARCHAR(5) DEFAULT NULL,
   radio2noofpeers INT(3)  DEFAULT NULL,
   radio3mac VARCHAR(12)  DEFAULT NULL,
   radio3meshenabled INT(1)  DEFAULT NULL,
   radio3name VARCHAR(5) DEFAULT NULL,
   radio3noofpeers INT(3)  DEFAULT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,
   sysip VARCHAR(16)  DEFAULT NULL,
   totalnoofpeers INT(3)  DEFAULT NULL,
   version VARCHAR(12)  DEFAULT NULL,
   wire0mac VARCHAR(12)  DEFAULT NULL,
   wire0name VARCHAR(5) DEFAULT NULL,
   wire0state VARCHAR(20)  DEFAULT NULL,
   wire1mac VARCHAR(12)  DEFAULT NULL,
   wire1name VARCHAR(5) DEFAULT NULL,
   wire1state VARCHAR(20)  DEFAULT NULL,
   sitename VARCHAR(40) DEFAULT NULL,
   changenotes varchar(150) DEFAULT NULL,
   radio0channel INT(3)  DEFAULT NULL,
   radio1channel INT(3)  DEFAULT NULL,
   radio2channel INT(3)  DEFAULT NULL,
   radio3channel INT(3)  DEFAULT NULL
   );
   );
);

runseq,entrydate,basemodel,bcname,bcstatus,bestcost,belongstogroup,bootcounter,goodcostcount,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,networkname,notes,radio0mac,radio0meshenabled,radio0name,radio0noofpeers,radio1mac,radio1meshenabled,radio1name,radio1noofpeers,radio2mac,radio2meshenabled,radio2name,radio2noofpeers,radio3mac,radio3meshenabled,radio3name,radio3noofpeers,serialno,sysip,totalnoofpeers,version,wire0mac,wire0name,wire0state,wire1mac,wire1name,wire1state,sitename,changenotes,radio0channel,radio1channel,radio2channel,radio3channel




*/


$d1=(int)$d1;   //   runseq INT(12) NOT NULL,
$d2=$d2;   //   entrydate DATE DEFAULT NULL,
$d3=(string)$d3;   //   basemodel VARCHAR(20) DEFAULT NULL,
$d4=(string)$d4;   //   bcname VARCHAR(40) DEFAULT NULL,
$d5=(int)$d5;   //   bcstatus INT(1)  DEFAULT NULL,
$d6=(string)$d6;   //   bestcost VARCHAR(8) DEFAULT NULL,
$d7=(string)$d7;   //   belongstogroup VARCHAR(80) DEFAULT NULL,
$d8=(int)$d8;   //   bootcounter INT(12)  DEFAULT NULL,
$d9=(string)$d9;   //   goodcostcount VARCHAR(2) DEFAULT NULL,
$d10=(string)$d10;   //   gpsalt VARCHAR(12)  DEFAULT NULL,
$d11=(string)$d11;   //   gpslat VARCHAR(12)  DEFAULT NULL,
$d12=(string)$d12;   //   gpslon VARCHAR(12)  DEFAULT NULL,
$d13=(int)$d13;   //   gpsmode INT(1)  DEFAULT NULL,
$d14=(int)$d14;   //   gpsswitchenabled INT(1)  DEFAULT NULL,
$d15=(int)$d15;   //   gpstime INT(12)  DEFAULT NULL,
$d16=(int)$d16;   //   gpsquality INT(12)  DEFAULT NULL,
$d17=(int)$d17;   //   gpssatsinview INT(2)  DEFAULT NULL,
$d18=(string)$d18;   //   gpsgeoid VARCHAR(100) DEFAULT NULL,
$d19=(string)$d19;   //   networkname VARCHAR(40) DEFAULT NULL,
$d20=(string)$d20;   //   notes VARCHAR(200) DEFAULT NULL,
$d21=(string)$d21;   //   radio0mac VARCHAR(12)  DEFAULT NULL,
$d22=(int)$d22;   //   radio0meshenabled INT(1)  DEFAULT NULL,
$d23=(string)$d23;   //   radio0name VARCHAR(5) DEFAULT NULL,
$d24=(int)$d24;   //   radio0noofpeers INT(3)  DEFAULT NULL,
$d25=(string)$d25;   //   radio1mac VARCHAR(12)  DEFAULT NULL,
$d26=(int)$d26;   //   radio1meshenabled INT(1)  DEFAULT NULL,
$d27=(string)$d27;   //   radio1name VARCHAR(5) DEFAULT NULL,
$d28=(int)$d28;   //   radio1noofpeers INT(3)  DEFAULT NULL,
$d29=(string)$d29;   //   radio2mac VARCHAR(12)  DEFAULT NULL,
$d30=(int)$d30;   //   radio2meshenabled INT(1)  DEFAULT NULL,
$d31=(string)$d31;   //   radio2name VARCHAR(5) DEFAULT NULL,
$d32=(int)$d32;   //   radio2noofpeers INT(3)  DEFAULT NULL,
$d33=(string)$d33;   //   radio3mac VARCHAR(12)  DEFAULT NULL,
$d34=(int)$d34;   //   radio3meshenabled INT(1)  DEFAULT NULL,
$d35=(string)$d35;   //   radio3name VARCHAR(5) DEFAULT NULL,
$d36=(int)$d36;   //   radio3noofpeers INT(3)  DEFAULT NULL,
$d37=(string)$d37;   //   serialno VARCHAR(20)  DEFAULT NULL,
$d38=(string)$d38;   //   sysip VARCHAR(16)  DEFAULT NULL,
$d39=(int)$d39;   //   totalnoofpeers INT(3)  DEFAULT NULL,
$d40=(string)$d40;   //   version VARCHAR(12)  DEFAULT NULL,
$d41=(string)$d41;   //   wire0mac VARCHAR(12)  DEFAULT NULL,
$d42=(string)$d42;   //   wire0name VARCHAR(5) DEFAULT NULL,
$d43=(string)$d43;   //   wire0state VARCHAR(20)  DEFAULT NULL,
$d44=(string)$d44;   //   wire1mac VARCHAR(12)  DEFAULT NULL,
$d45=(string)$d45;   //   wire1name VARCHAR(5) DEFAULT NULL,
$d46=(string)$d46;   //   wire1state VARCHAR(20)  DEFAULT NULL,
$d47=(string)$d47;   //   sitename VARCHAR(40) DEFAULT NULL,
$d48=(string)$d48;   //   changenotes varchar(150) DEFAULT NULL
$d49=(int)$d49;   //   radio0channel INT(3)  DEFAULT NULL,
$d50=(int)$d50;   //   radio1channel INT(3)  DEFAULT NULL,
$d51=(int)$d51;   //   radio2channel INT(3)  DEFAULT NULL,
$d52=(int)$d52;   //   radio3channel INT(3)  DEFAULT NULL,

   

/*
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

$query = "INSERT INTO bcchanges (runseq,entrydate,basemodel,bcname,bcstatus,bestcost,belongstogroup,bootcounter,goodcostcount,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,networkname,notes,radio0mac,radio0meshenabled,radio0name,radio0noofpeers,radio1mac,radio1meshenabled,radio1name,radio1noofpeers,radio2mac,radio2meshenabled,radio2name,radio2noofpeers,radio3mac,radio3meshenabled,radio3name,radio3noofpeers,serialno,sysip,totalnoofpeers,version,wire0mac,wire0name,wire0state,wire1mac,wire1name,wire1state,sitename,changenotes,radio0channel,radio1channel,radio2channel,radio3channel)" .
		" VALUES ('$d1','$d2','$d3','$d4','$d5','$d6','$d7','$d8','$d9','$d10','$d11','$d12','$d13','$d14','$d15','$d16','$d17','$d18','$d19','$d20','$d21','$d22','$d23','$d24','$d25','$d26','$d27','$d28','$d29','$d30','$d31','$d32','$d33','$d34','$d35','$d36','$d37','$d38','$d39','$d40','$d41','$d42','$d43','$d44','$d45','$d46','$d47','$d48','$d49','$d50','$d51','$d52')";
$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");
###sleep(3);
}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//UPDATEBCHISTORY
///////////////////////////////////////////////////////////////////////////////////////////////////////////
function updatebchistory($d1="",$d2="",$d3="",$d4="",$d5="",$d6="",$d7="",$d8="",$d9="",$d10="",$d11="",$d12="",$d13="",$d14="",$d15="",$d16="",$d17="",$d18="",$d19="",$d20="",$d21="",$d22="",$d23="",$d24="",$d25="",$d26=""){
// entries to insert
/*


CREATE TABLE IF NOT EXISTS bchistory (
   entrydate DATE DEFAULT NULL,
   basemodel VARCHAR(20) DEFAULT NULL,
   bcname VARCHAR(40) DEFAULT NULL,
   belongstogroup VARCHAR(80) DEFAULT NULL,
   gpsalt VARCHAR(12)  DEFAULT NULL,
   gpslat VARCHAR(12)  DEFAULT NULL,
   gpslon VARCHAR(12)  DEFAULT NULL,
   gpsmode INT(1)  DEFAULT NULL,
   gpsswitchenabled INT(1)  DEFAULT NULL,
   gpstime INT(12)  DEFAULT NULL,
   gpsquality INT(12)  DEFAULT NULL,
   gpssatsinview INT(2)  DEFAULT NULL,
   gpsgeoid VARCHAR(100) DEFAULT NULL,
   networkname VARCHAR(40) DEFAULT NULL,
   notes VARCHAR(200) DEFAULT NULL,
   radio0mac VARCHAR(12)  DEFAULT NULL,
   radio1mac VARCHAR(12)  DEFAULT NULL,
   radio2mac VARCHAR(12)  DEFAULT NULL,
   radio3mac VARCHAR(12)  DEFAULT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,
   sysip VARCHAR(16)  DEFAULT NULL,
   version VARCHAR(12)  DEFAULT NULL,
   wire0mac VARCHAR(12)  DEFAULT NULL,
   wire1mac VARCHAR(12)  DEFAULT NULL,
   sitename VARCHAR(40) DEFAULT NULL,
   reasonforentry varchar(150) DEFAULT NULL
   );

entrydate,basemodel,bcname,belongstogroup,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,networkname,notes,radio0mac,radio1mac,radio2mac,radio3mac,serialno,sysip,version,wire0mac,wire1mac,sitename,reasonforentry
  


*/


$d1=$d1;   //   entrydate DATE DEFAULT NULL,
$d2=(string)$d2;   //   basemodel VARCHAR(20) DEFAULT NULL,
$d3=(string)$d3;   //   bcname VARCHAR(40) DEFAULT NULL,
$d4=(string)$d4;   //   belongstogroup VARCHAR(80) DEFAULT NULL,
$d5=(string)$d5;   //   gpsalt VARCHAR(12)  DEFAULT NULL,
$d6=(string)$d6;   //   gpslat VARCHAR(12)  DEFAULT NULL,
$d7=(string)$d7;   //   gpslon VARCHAR(12)  DEFAULT NULL,
$d8=(int)$d8;   //   gpsmode INT(1)  DEFAULT NULL,
$d9=(int)$d9;   //   gpsswitchenabled INT(1)  DEFAULT NULL,
$d10=(int)$d10;   //   gpstime INT(12)  DEFAULT NULL,
$d11=(int)$d11;   //   gpsquality INT(12)  DEFAULT NULL,
$d12=(int)$d12;   //   gpssatsinview INT(2)  DEFAULT NULL,
$d13=(string)$d13;   //   gpsgeoid VARCHAR(100) DEFAULT NULL,
$d14=(string)$d14;   //   networkname VARCHAR(40) DEFAULT NULL,
$d15=(string)$d15;   //   notes VARCHAR(200) DEFAULT NULL,
$d16=(string)$d16;   //   radio0mac VARCHAR(12)  DEFAULT NULL,
$d17=(string)$d17;   //   radio1mac VARCHAR(12)  DEFAULT NULL,
$d18=(string)$d18;   //   radio2mac VARCHAR(12)  DEFAULT NULL,
$d19=(string)$d19;   //   radio3mac VARCHAR(12)  DEFAULT NULL,
$d20=(string)$d20;   //   serialno VARCHAR(20)  DEFAULT NULL,
$d21=(string)$d21;   //   sysip VARCHAR(16)  DEFAULT NULL,
$d22=(string)$d22;   //   version VARCHAR(12)  DEFAULT NULL,
$d23=(string)$d23;   //   wire0mac VARCHAR(12)  DEFAULT NULL,
$d24=(string)$d24;   //   wire1mac VARCHAR(12)  DEFAULT NULL,
$d25=(string)$d25;   //   sitename VARCHAR(40) DEFAULT NULL,
$d26=(string)$d26;   //   reasonforentry varchar(150) DEFAULT NULL
#dbg("d","check this");
#  dbg("d","$d25"); 
#dbg("d","$d26" );
###sleep (3);

/*
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/


if ($d26=="last seen this crumb st this location $d25"){  //only attempt to update the existing record
	$tempvalueD = getdbvalue("entrydate","bchistory","reasonforentry","last seen this crumb st this location $d25");  //see if the entry exists first or update will result in nothing
	dbg("d","database test before update=$tempvalueD");
	###sleep(5);
	if ($tempvalueD==""){  //if the record does not exist write in in dont update it}
		$query = "INSERT INTO bchistory (entrydate,basemodel,bcname,belongstogroup,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,networkname,notes,radio0mac,radio1mac,radio2mac,radio3mac,serialno,sysip,version,wire0mac,wire1mac,sitename,reasonforentry)" .
		" VALUES ('$d1','$d2','$d3','$d4','$d5','$d6','$d7','$d8','$d9','$d10','$d11','$d12','$d13','$d14','$d15','$d16','$d17','$d18','$d19','$d20','$d21','$d22','$d23','$d24','$d25','$d26')";
		$msqlr=mysql_query($query);
	}else{
	// example for update command=UPDATE sites SET site_name = 'TechOnTheNet.com' WHERE site_name = 'CheckYourMath.com';
		$query=	"UPDATE bchistory SET entrydate = '$d1',basemodel = '$d2',bcname = '$d3',belongstogroup = '$d4',gpsalt = '$d5',gpslat = '$d6',gpslon = '$d7',gpsmode = '$d8',gpsswitchenabled = '$d9',gpstime = '$d10',gpsquality = '$d11',gpssatsinview = '$d12',gpsgeoid = '$d13',networkname = '$d14',notes = '$d15',radio0mac = '$d16',radio1mac = '$d17',radio2mac = '$d18',radio3mac = '$d19',serialno = '$d20',sysip = '$d21',version = '$d22',wire0mac = '$d23',wire1mac = '$d24',sitename = '$d25',reasonforentry = '$d26' " .
		" WHERE serialno = '$d20' AND sitename = '$d25' AND reasonforentry = '$d26'";
		dbg("d","insert query = $query");
		###sleep(3);
		
		$msqlr=mysql_query($query);
		$tempvalss=mysql_info();
         dbg("d","tempvalss=$tempvalss");
		$tempvalC=qryOK("changed",$tempvalss);  //Rows matched: 1  Changed: 0  Warnings: 1
        if ($tempvalC == 0 ){
		dbg("d","assume update NOT successfull into dbhistory with querry returning $tempvalC" );  //yettodo better check of record update
		###sleep (10);
		
		}else{
		dbg("d","assume update successfull into dbhistory with TempvalueD returning $tempvalC" );  //yettodo better check of record update
		###sleep (10);
			
		}		
	} //end of if $tempvalueD

}else{ //new record
	$query = "INSERT INTO bchistory (entrydate,basemodel,bcname,belongstogroup,gpsalt,gpslat,gpslon,gpsmode,gpsswitchenabled,gpstime,gpsquality,gpssatsinview,gpsgeoid,networkname,notes,radio0mac,radio1mac,radio2mac,radio3mac,serialno,sysip,version,wire0mac,wire1mac,sitename,reasonforentry)" .
	" VALUES ('$d1','$d2','$d3','$d4','$d5','$d6','$d7','$d8','$d9','$d10','$d11','$d12','$d13','$d14','$d15','$d16','$d17','$d18','$d19','$d20','$d21','$d22','$d23','$d24','$d25','$d26')";
	$msqlr=mysql_query($query);
}  //end if else $d26
dbg("d","$query");
dbg("d","$msqlr");
###sleep(3);
}  //end function updatebchistory




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//GETDBVALUE
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function  getdbvalue($getvalue,$tablename,$column,$value){


	
#$DBserver	= "localhost";
#$DBname		= "MST_BC_TRACKER";
#$DBuser		= "root";
#$DBpasswd	= "";
#$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
#mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");

/*   
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

dbg("d","columncheck =$column");


if ($column=="LIMIT"){
$query = "SELECT $getvalue FROM $tablename $column $value";
}else{
$query = "SELECT $getvalue FROM $tablename WHERE $column = '$value'";
}

$result = mysql_query($query);

if (! $result){
   dbg("d","Database error: " . mysql_error());
   dbg("d","$query");
   return ("error");
}else{
   while ($row = mysql_fetch_row($result)) { //we have our rows of data , stepping through now
    dbg("d","query is = $query");
	dbg("o","array row from query is below");
	dbg("d","".print_r($row));
   	dbg("d","sizeof results is= ".sizeof($row));
	dbg("d","result is =".$row[sizeof($row)-1]);

	##sleep(5);
	return $row[sizeof($row)-1];
} //end while
}  //end if else
}  //end function	



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//QRYOK
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function qryOK($rtype,$returnedstring){
		dbg("d","rtype=$rtype returnedstring=$returnedstring");
		$tempvalA=split("  ",$returnedstring);
		dbg("d","$tempvalA[0]");
		dbg("d","$tempvalA[1]");
		dbg("d","$tempvalA[2]");
		switch ($rtype){
		case "matched":
		 $tempvalB=split(":",$tempvalA[0]);
		 return trim($tempvalB[1]);
		 break;
		case "changed":
		 $tempvalB=split(":",$tempvalA[1]);
		 return trim($tempvalB[1]);
		 break;
		case "warnings":
		 $tempvalB=split(":",$tempvalA[2]);
		 return trim($tempvalB[1]);
		 break;
		} //end case/switch
} //end of function
		 


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//UPDATESEQ
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateseq($d1="",$d2="",$d3=""){
// entries to insert
/*
CREATE TABLE IF NOT EXISTS seq (
   runseq INT(12) NOT NULL,
   entrydate DATETIME DEFAULT NULL,
   PRIMARY KEY (runseq)
 );  

runseq,entrydate

*/

$d1=(int)$d1 ;  //  new` runseq INT(12) NOT NULL,
$d2=$d2 ;  //   entrydate DATE DEFAULT NULL,   
$d3=(int)$d3 ;  //  old runseq INT(12) NOT NULL,
/*    
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/
#dbg("d","d3=$d3";
#
$query = "TRUNCATE TABLE seq";
$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");


#if($d3==0){
$query = "INSERT into seq (runseq,entrydate) VALUES ('$d1','$d2')";
#}else{
#$query = "UPDATE seq SET runseq = '$d1',entrydate = '$d2' WHERE runseq = '$d3'";
#}
$msqlr=mysql_query($query);
dbg("d","$query");
dbg("d","$msqlr");
##sleep(3);
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FILLNAMEIPa
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fillnameipA($table){
//remember , this array holds the info for the peers connection database by referencing data collected here for bcname and additional info
/*
uses the table below 'bcchanges'

--tracks changes made to the crumbs on the mesh
excerpt from table creation truncated
CREATE TABLE IF NOT EXISTS bcchanges (

   entrydate DATETIME DEFAULT NULL,
<some entries not shown here>
   bcname VARCHAR(40) DEFAULT NULL,
<some entries not shown here>
   radio0mac VARCHAR(12)  DEFAULT NULL,
   radio0meshenabled INT(1)  DEFAULT NULL,
   radio0name VARCHAR(5) DEFAULT NULL,
   radio0noofpeers INT(3)  DEFAULT NULL,
   radio1mac VARCHAR(12)  DEFAULT NULL,
   radio1meshenabled INT(1)  DEFAULT NULL,
   radio1name VARCHAR(5) DEFAULT NULL,
   radio1noofpeers INT(3)  DEFAULT NULL,
   radio2mac VARCHAR(12)  DEFAULT NULL,
   radio2meshenabled INT(1)  DEFAULT NULL,
   radio2name VARCHAR(5) DEFAULT NULL,
   radio2noofpeers INT(3)  DEFAULT NULL,
   radio3mac VARCHAR(12)  DEFAULT NULL,
   radio3meshenabled INT(1)  DEFAULT NULL,
   radio3name VARCHAR(5) DEFAULT NULL,
   radio3noofpeers INT(3)  DEFAULT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,
   sysip VARCHAR(16)  DEFAULT NULL,
<some entries not shown here>
   wire0mac VARCHAR(12)  DEFAULT NULL,
   wire0name VARCHAR(5) DEFAULT NULL,
   wire0state VARCHAR(20)  DEFAULT NULL,
   wire1mac VARCHAR(12)  DEFAULT NULL,
   wire1name VARCHAR(5) DEFAULT NULL,
   wire1state VARCHAR(20)  DEFAULT NULL,
<some entries not shown here>
   changenotes varchar(150) DEFAULT NULL
  radio0channel INT(3)  DEFAULT NULL,
   radio1channel INT(3)  DEFAULT NULL,
   radio2channel INT(3)  DEFAULT NULL,
   radio3channel INT(3)  DEFAULT NULL
updatebcchanges("$seq","$entrydate","$basemodel","$bcname","$bcstatus","$bestcost","$belongstogroup","$bootcounter","$goodcostcount","$gpsalt","$gpslat","$gpslon","$gpsmode","$gpsswitchenabled","$gpstime","$gpsquality","$gpssatsinview","$gpsgeoid","$networkname","$notes","$radio0mac","$radio0meshenabled","$radio0name","$radio0noofpeers","$radio1mac","$radio1meshenabled","$radio1name","$radio1noofpeers","$radio2mac","$radio2meshenabled","$radio2name","$radio2noofpeers","$radio3mac","$radio3meshenabled","$radio3name","$radio3noofpeers","$serialno","$sysip","$totalnoofpeers","$version","$wire0mac","$wire0name","$wire0state","$wire1mac","$wire1name","$wire1state","$sitename","$changenotes","$radio0channel","$radio1channel","$radio2channel","$radio3channel");
	
   );

   
   
*/
#$returnA=[];   

/*
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

//#####################
//do first loop to get disticnt ipaddress so in ournextquery we get the full list of macs
//#####################
$query1 = "SELECT DISTINCT(sysip) FROM $table";  //get our records
#dbg("d","$query1");
###sleep(5);
$result1 = mysql_query($query1);
if (! $result1){
   dbg("d","Database error: " . mysql_error());
   dbg("d","$query1");
   dbg("e","Database error: " . mysql_error());
   dbg("e","$query1");
   return ("error");
}else{
   while ($row1 = mysql_fetch_row($result1)) { //we have our rows of data , stepping through now
   #dbg("d","query1 is = $query1");
   #dbg("d","result is =".$row1[0];
   ###sleep(2);
   #echo chr(10);	
   //we now have a ipaddress , we now step through the databse saveing the latest record o each mac entry for this ip address

//#####################
//do wireless circuits first
//#####################
for ($x=0;$x<4;$x++){ //autoincrement through the array counter due to the next sectioned commented out should have work ed but didnt
$oldestDT=""; //initilise blank datetime
$query = "SELECT radio".$x."mac,sysip,bcname,radio".$x."name,radio".$x."channel,entrydate FROM $table where sysip = '$row1[0]'";  //get our records
#dbg("d","$query");
###sleep(10);
$result = mysql_query($query);
if (! $result){
   dbg("d","Database error: " . mysql_error());
   dbg("d","$query");
   dbg("e","Database error: " . mysql_error());
   dbg("e","$query");
   return ("error");
}else{
   while ($row = mysql_fetch_row($result)) { //we have our rows of data , stepping through now
   #dbg("d","query is = $query");
   #dbg("d","result is =".$row[0]." ".$row[1]." ".$row[2]." ".$row[3]." ".$row[4]." ".$row[5];
   #	if ($row[5] > $oldestDT){ //if its an older record than the last saved one
		#echo $row[5]." > $oldestDT"; 
		$oldestDT=$row[5];  //reset older datetime to new datetime
		$arraystring=$row[0].",".$row[1].",".$row[2].",".$row[3].",".$row[4].",".$row[5]   ;//create a single string for insertion into the array so we can get the info later 
		#echo chr(10).chr(10)."updated ".$arraystring.chr(10));  //print to screen for debugging
		
   }//endwhile
} //end if result
$returnA[]=$arraystring;  //add the latest results to the array as its the oldest and most accurate info
 #  dbg("d","##sleep5");
###sleep (5);

} //nexxt x
#   dbg("d","##sleep60");
###sleep (60);



//#####################
//do wired circuits next
//#####################

for ($x=0;$x<2;$x++){ //autoincrement through the array counter due to the next sectioned commented out should have work ed but didnt
$oldestDT=""; //initilise blank datetime
$query = "SELECT wire".$x."mac,sysip,bcname,wire".$x."name,wire".$x."state,entrydate FROM $table where sysip = '$row1[0]'";  //get our records
#dbg("d","$query");
###sleep(5);
$result = mysql_query($query);
if (! $result){
   dbg("d","Database error: " . mysql_error());
   dbg("d","$query");
   dbg("e","Database error: " . mysql_error());
   dbg("e","$query");
   return ("error");
}else{
   while ($row = mysql_fetch_row($result)) { //we have our rows of data , stepping through now
   #dbg("d","query is = $query");
   #dbg("d","found =".$row[0]." ".$row[1]." ".$row[2]." ".$row[3]." ".$row[4]." ".$row[5];
   #	if ($row[5] > $oldestDT){ //if its an older record than the last saved one
		#echo $row[5]." > $oldestDT"; 
		$oldestDT=$row[5];  //reset older datetime to new datetime
		$arraystring=$row[0].",".$row[1].",".$row[2].",".$row[3].",".$row[4].",".$row[5]   ;//create a single string for insertion into the array so we can get the info later 
		#echo chr(10).chr(10)."updated ".$arraystring.chr(10));  //print to screen for debugging
	}//endwhile
} //end if result
$returnA[]=$arraystring;  //add the latest results to the array as its the oldest and most accurate info
###sleep (5);
} //nexxt x



//#####################
//first finish brackets
//#####################
   }//endwhile 1st loop
} //end if result 1st loop
#dbg("o","array nameipA refreshed - data is below");
#dbg("o","".print_r($returnA));
return $returnA;
}// end of function  fillnameipA


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DBG
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function dbg($type,$d1=""){
/*
valid types=
b = breadcrumb
c = changes
d = database
e = errors
f = files
g = general
k = kmls
o = other

$debuglevel 0 = none
$debuglevel 1 = G only  "general"
$debuglevel 2 = B only	"breadcrumb"
$debuglevel 3 = C only	"changes"
$debuglevel 4 = D only	"database"
$debuglevel 5 = E only	"errors"
$debuglevel 6 = F only	"files"
$debuglevel 7 = k only	"kml"
$debuglevel 8 = all		
$debuglevel none = all


*/
if ( $GLOBALS["debuglevel"]==""){
		#echo date("Ymd_His")."[$type] $d1 ".chr(10);
		#do nuthin
}else{
$type=strtoupper($type);
switch ($type){
	case "G": //general output
	if ($GLOBALS["debuglevel"]=="1") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	break;
	case "B": //Breadcrumb info
	if ($GLOBALS["debuglevel"]=="2") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	break;
	case "C": //Changes to breadcrumbs
	if ($GLOBALS["debuglevel"]=="3") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	break;
	case "D": //databse entries and queries
	if ($GLOBALS["debuglevel"]=="4") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	if ($GLOBALS["debuglevel"]=="9") echo date("Ymd_His")."[$type] $d1 ".chr(10);

	break;
	case "E":  //error 
	echo date("Ymd_His")."[$type] $d1 ".chr(10);
	
	break;
	case "F":  //file work
	if ($GLOBALS["debuglevel"]=="6") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	break;
	case "K": //kml works
	if ($GLOBALS["debuglevel"]=="7") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	break;
	default: // otherwise print/echo everything
	if ($GLOBALS["debuglevel"]=="8") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	if ($GLOBALS["debuglevel"]=="9"){
		echo date("Ymd_His")."[$type] $d1 ".chr(10);
		#sleep(1);
	} 
	break;
	
} //end switch
	if ($GLOBALS["debuglevel"]=="8") echo date("Ymd_His")."[$type] $d1 ".chr(10);

}//end if
}//end function



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ACTIVEKML
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ActivecostKML(){
dbg("k","kml now updating");

/*
The syntax for writing comments in XML is similar to that of HTML.

<!-- This is a comment -->



<message>salary &lt; 1000</message>

There are 5 pre-defined entity references in XML:

&lt; < less than 
&gt; > greater than 
&amp; & ampersand  
&apos; ' apostrophe 
&quot; " quotation mark 

//my old header
<?xml version="1.0" encoding="utf-8"?>
<kml xmlns="http://earth.google.com/kml/2.0">
<Document>
<Style id="redisbadStyle">
<IconStyle>
<scale>.75</scale>
<color>ff000000</color>
<Icon>
<href>http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png</href>
</Icon>
</IconStyle>
<BalloonStyle>
<text>$[description]</text>
</BalloonStyle>
</Style>
<Style id="greenisgoodStyle">
<IconStyle>
<scale>.75</scale>
<color>ff00ff55</color>
<Icon>
<href>http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png</href>
</Icon>
</IconStyle>
<BalloonStyle>
<text>$[description]</text>
</BalloonStyle>
</Style>
<Folder>
<description>Tool developed by Cameron Jones c.jones@mstglobal.com.au</description>
<name>CrumbCollector</name>
<BalloonStyle>
<text>$[description]</text>
</BalloonStyle>
<Folder>
<name> All BreadCrumbs All Frequencies +25</name>
<description>All BreadCrumbs and all frequencies with Best SNR at this location ref value equal or over 25</description>
<Placemark>
<name></name>
<description><![CDATA[<b>Name: </b>BMACVMTR052RBC01<br /><b>MAC: </b>00:15:6d:6a:d8:9c<br /><b>Radio no: </b>wlan1<br /><b>Modulation: </b>1<br /><b>SNR: </b>92<br /><b>Cost: </b>157729<br /><b>Date: </b>25/08/2015<br /><b>Time: </b>1114.4200<br /><b>Longitude: </b>148.060901666667<br /><b>Latitude: </b>-22.1569866666667<br /><b>Altitude: </b>263 m<br /><b>Suplimentry Data: </b>wlan3 5800 MHz 160 33-wlan2 2462 MHz 11 42-wlan1 2412 MHz 1 92-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>
<Point>
<coordinates>148.060901666667,-22.1569866666667,0</coordinates>
</Point>
</Placemark>




//garys header
'<?xml version="1.0" encoding="UTF-8"?>
	<kml xmlns="http://www.opengis.net/kml/2.2">
	<Document>
	<name>Signal Strength Map</name>
	<description>'"$site Absolute Heat Mapping `date +%Y-$b-$d`"'</description>
	<Style id="verylow">
		<LineStyle>
			<color>7f00ffff</color>
			<width>2</width>
		</LineStyle>
		<PolyStyle>
			<color>7f00ff00</color>
		</PolyStyle>
	</Style>
	<Style id="low">
		<LineStyle>
			<color>7ff7ff00</color>
			<width>2</width>
		</LineStyle>
		<PolyStyle>
			<color>7f00ff00</color>
		</PolyStyle>
	</Style>
	<Style id="moderate">
		<LineStyle>
			<color>7f00ffff</color>
			<width>2</width>
		</LineStyle>
		<PolyStyle>
			<color>7f00ff00</color>
		</PolyStyle>
	</Style>
	<Style id="good">
		<LineStyle>
			<color>7f00ff00</color>
			<width>2</width>
		</LineStyle>
		<PolyStyle>
			<color>7f00ff00</color>
		</PolyStyle>
	</Style>
	<Style id="transGreenPoly">
		<LineStyle>
			<width>1.5</width>
		</LineStyle>
		<PolyStyle>
			<color>7d00ff00</color>
		</PolyStyle>
	</Style>'="";

	
	
	
<?xml version="1.0" encoding="utf-8"?>
<kml xmlns="http://earth.google.com/kml/2.0">
<Document>

<Style id="greenisgoodStyle">
<IconStyle>
<scale>.75</scale>
<color>ff00ff55</color>
<Icon>
<href>http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png</href>
</Icon>
</IconStyle>
<BalloonStyle>
<text>$[description]</text>
</BalloonStyle>
</Style>

<Folder>
<description>Tool developed by Cameron Jones c.jones@mstglobal.com.au</description>
<name>CrumbCollector</name>
<BalloonStyle>
<text>$[description]</text>
</BalloonStyle>
<Folder>
<name> All BreadCrumbs All Frequencies +25</name>
<description>All BreadCrumbs and all frequencies with Best SNR at this location ref value equal or over 25</description>
<Placemark>
<name></name>
<description><![CDATA[<b>Name: </b>BMACVMTR052RBC01<br /><b>MAC: </b>00:15:6d:6a:d8:9c<br /><b>Radio no: </b>wlan1<br /><b>Modulation: </b>1<br /><b>SNR: </b>92<br /><b>Cost: </b>157729<br /><b>Date: </b>25/08/2015<br /><b>Time: </b>1114.4200<br /><b>Longitude: </b>148.060901666667<br /><b>Latitude: </b>-22.1569866666667<br /><b>Altitude: </b>263 m<br /><b>Suplimentry Data: </b>wlan3 5800 MHz 160 33-wlan2 2462 MHz 11 42-wlan1 2412 MHz 1 92-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>
<Point>
<coordinates>148.060901666667,-22.1569866666667,0</coordinates>
</Point>
</Placemark>

	
	
	*/
//remeber we replace the ^ later with quotes "	
//remeber "<!-- DocStart_#s -->" is a comment we use this to replace sections inside the kml file #s =start of section#e is end of section

$KMLhead="<?xml version=\"1.0\" encoding=\"utf-8\"?>
<!-- KML header file for BCT -->".chr(10);

$headerDocStart="<!-- DocStart_#s -->".chr(10).
"<kml xmlns=\"http://earth.google.com/kml/2.0\">
<Document>
<!-- DocStart_#e -->
";

//remeber \" inside a  " " inicates to choose the next" as being inside the brackets ie "name = - \"name in brakets\" -" is name = - "name in brackets" -	
$headerStyleidStart="<!-- Styleid_#s -->".chr(10).
"	<Style id=\"gp1_filter_icon_steady\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_steady_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_steady_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_steady_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_master\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_master_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_master_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_master_ref]</href>
		</Icon>
		</IconStyle>
		<LabelStyle>
			<scale>0</scale>
		</LabelStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_slave\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_slave_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_slave_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_slave_ref]</href>
		</Icon>
		</IconStyle>
		<LabelStyle>
			<scale>0</scale>
		</LabelStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_moved\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_moved_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_moved_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_moved_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_lastknown\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_lastknown_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_lastknown_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_lastknown_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_poor\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_poor_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_poor_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_poor_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_average\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_average_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_average_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_average_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_good\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_good_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_good_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_good_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_excellent\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_excellent_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_excellent_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_excellent_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_missing\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_missing_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_missing_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_missing_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_infrastructure\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_infrastructure_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_infrastructure_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_infrastructure_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_trailer\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_trailer_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_trailer_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_trailer_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_emetruck\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_emetruck_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_emetruck_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_emetruck_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_emeother\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_emeother_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_emeother_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_emeother_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_unknown\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_unknown_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_unknown_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_unknown_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_icon_default\">
		<IconStyle>
		<scale>$GLOBALS[gp1_filter_icon_default_scale]</scale>
		<color>$GLOBALS[gp1_filter_icon_default_color]</color>
		<Icon>
			<href>$GLOBALS[gp1_filter_icon_default_ref]</href>
		</Icon>
		</IconStyle>
		<BalloonStyle>
			<text>$[description]</text>
		</BalloonStyle>
	</Style>
	<Style id=\"gp1_filter_path_cost_poor\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_cost_poor_color]</color>
			<width>$GLOBALS[gp1_filter_path_cost_poor_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_cost_poor_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_cost_average\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_cost_average_color]</color>
			<width>$GLOBALS[gp1_filter_path_cost_average_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_cost_average_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_cost_good\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_cost_good_color]</color>
			<width>$GLOBALS[gp1_filter_path_cost_good_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_cost_good_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_cost_excellent\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_cost_excellent_color]</color>
			<width>$GLOBALS[gp1_filter_path_cost_excellent_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_cost_excellent_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_lostAPT\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_lostAPT_color]</color>
			<width>$GLOBALS[gp1_filter_path_lostAPT_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_lostAPT_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_wired\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_wired_color]</color>
			<width>$GLOBALS[gp1_filter_path_wired_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_wired_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_900\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_900_color]</color>
			<width>$GLOBALS[gp1_filter_path_900_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_900_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_2400\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_2400_color]</color>
			<width>$GLOBALS[gp1_filter_path_2400_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_2400_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_5800\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_5800_color]</color>
			<width>$GLOBALS[gp1_filter_path_5800_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_5800_polycolor]</color>
		</PolyStyle>
	</Style>
	<Style id=\"gp1_filter_path_other\">
		<LineStyle>
			<color>$GLOBALS[gp1_filter_path_other_color]</color>
			<width>$GLOBALS[gp1_filter_path_other_width]</width>
		</LineStyle>
		<PolyStyle>
			<color>$GLOBALS[gp1_filter_path_other_polycolor]</color>
		</PolyStyle>
	</Style>".
"<!-- Styleid_#e -->".chr(10);  //#e comment to locate later when processing




$headerFolderCostStart="<!-- FolderCostStart_#s -->".chr(10).		  //#s comment to locate later when processing
"			<Folder>
				<name>$GLOBALS[sitename]_Overview_Cost_$GLOBALS[polltime]</name>
				<description>Overview metrics developed from Cost.
				BCT Ver $GLOBALS[version]
				BreadCrumb Tracker tool developed by Cameron Jones c.jones@mstglobal.com.au
				</description>".chr(10).
"<!-- FolderCostStart_#e -->".chr(10);  //#e comment to locate later when processing


$headerFolderCostEnd="<!-- FolderCostEnd_#s -->".chr(10).		  //#s comment to locate later when processing
"			</Folder>".chr(10).
"<!-- FolderCostEnd_#e -->".chr(10);  //#e comment to locate later when processing


$headerDocEnd="<!-- DocEnd_#s -->".chr(10).
"</Document>
</kml>".chr(10).
"<!-- FolderidEnd_#e -->".chr(10);  //#e comment to locate later when processing



/*
<Placemark>
<name></name>
<description><![CDATA[<b>Name: </b>BMACVMTR052RBC01<br /><b>MAC: </b>00:15:6d:6a:d8:9c<br /><b>Radio no: </b>wlan1<br /><b>Modulation: </b>1<br /><b>SNR: </b>92<br /><b>Cost: </b>157729<br /><b>Date: </b>25/08/2015<br /><b>Time: </b>1114.4200<br /><b>Longitude: </b>148.060901666667<br /><b>Latitude: </b>-22.1569866666667<br /><b>Altitude: </b>263 m<br /><b>Suplimentry Data: </b>wlan3 5800 MHz 160 33-wlan2 2462 MHz 11 42-wlan1 2412 MHz 1 92-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>
<Point>
<coordinates>148.060901666667,-22.1569866666667,0</coordinates>
</Point>
</Placemark>
*/

$megatextStart=$KMLhead.$headerDocStart.$headerStyleidStart.$headerFolderCostStart;  //beggining of the kml file made up of different sections
$megatextEnd=$headerFolderCostEnd.$headerDocEnd; //end of the kml file


echo "$megatextStart";	
echo "$megatextEnd";
$abs_path = $GLOBALS["mywdir"]."/kml/";  //path of file for kml entry
dbg("k","abs_path=$abs_path");
$filename="active.kml";   //kml filename
dbg("k","filename=$filename");


if (file_exists($abs_path . $filename)) {  //does file exist yes
	dbg("k","file exists ".$abs_path . $filename);
    #echo "The file exists. URL:" . $file_url;
	#echo "The file exists. :" . $filename;
	if (! unlink($abs_path.$filename)){
		dbg("k","File exists but can not delete".$abs_path . $filename);
		dbg("e","File exists but can not delete".$abs_path . $filename);

	}else{
		dbg("k","File deleted ".$abs_path . $filename);
	}//end if not deleted
}//end if

#do something here like create the guts of the kml file
$megatextGuts=RetrieveCrumbsPlaceMarks();  //crumb points
$megatextGuts=$megatextGuts.RetrieveCrumbsCostPaths();  //crumb paths
$file= fopen($abs_path.$filename, 'w') or die("Can't create file");
echo fwrite($file,$megatextStart.$megatextGuts.$megatextEnd);
dbg("k","File created ".$abs_path . $filename);
fclose($file);







/*
#$file_url = 'http://www.example.com/images/' . $filename;
if (file_exists($abs_path . $filename)) {  //does file exist yes
	dbg("k","file exists ".$abs_path . $filename);
    #echo "The file exists. URL:" . $file_url;
	#echo "The file exists. :" . $filename;
	$kfile= file($abs_path.$filename); //file location read into $lines array
	 #;strip footer here
} else {  //does file exist no
	dbg("k","file does NOT exist ".$abs_path . $filename);
    #echo "The file does not exist";
	$file= fopen($abs_path.$filename, 'w') or die("Can't create file");
	echo fwrite($file,$megatext);
	fclose($file);
	$kfile= file($abs_path.$filename); //file location read into $lines array
} //end if

*/


	
} //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//RetrieveCrumbsPlaceMarks
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#function RetrieveCrumbsPlaceMarks($tabs){
function RetrieveCrumbsPlaceMarks(){
	global $crumb_plotted_kml_info;//why?
//remember , this array holds the info for the peers connection database by referencing data collected here for bcname and additional info
/*
##########
##KML placemark flowchart
##########
GE AKA google earth
-kmls files-
/latest/Sitename_Date_Costs

Loop1
 Get Crumb info [where name starts with x from ini file] info for desciption when the placemark is selected in GE , see below > into PlaceArray
		-placearray Values-
	BCname
	BCLocation
	BCSstatus
	BCType
	BCInfo
		
 Get icon value from ini file where APT state = APT master of link or slave
 Get Peer values [where name starts and connectedname starts with x from ini file] > into PathArray
		-Path Array Values-
	Origin_name
	Origin_location [in kml format]
	Destination_name
	Destination_location [in kml format]
	Best_Cost_Type
	Best_Cost_Value
	Best_Cost_Freq_1
	Best_Cost_Freq_2
	Best_Cost_Freq_3
	Best_Cost_Freq_4
	Best_Cost_Wire_0
	Best_Cost_Wire_1

	
	
<Placemark>
<name></name>
<description><![CDATA[<b>Name: </b>BMACVMJC290RBC01<br /><b>MAC: </b>00:15:6d:6a:d8:97<br /><b>Radio no: </b>wlan1<br /><b>Modulation: </b>11<br /><b>SNR: </b>42<br /><b>Cost: </b>27599<br /><b>Date: </b>25/08/2015<br /><b>Time: </b>1315.0700<br /><b>Longitude: </b>148.059206666667<br /><b>Latitude: </b>-22.1584733333333<br /><b>Altitude: </b>256 m<br /><b>Suplimentry Data: </b>wlan2 2462 MHz 11 41-wlan1 2412 MHz 1 42-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>
<Point>
<coordinates>148.059206666667,-22.1584733333333,0</coordinates>
</Point>
</Placemark>

CREATE TABLE IF NOT EXISTS bcdata (
   runseq INT(12) NOT NULL,
   entrydate DATETIME DEFAULT NULL,
   aptpriority VARCHAR(3) DEFAULT NULL,
   basemodel VARCHAR(20) DEFAULT NULL,
   bcname VARCHAR(40) DEFAULT NULL,
   bestcost VARCHAR(8) DEFAULT NULL,
   belongstogroup VARCHAR(80) DEFAULT NULL,
   gpsalt VARCHAR(12)  DEFAULT NULL,
   gpslat VARCHAR(12)  DEFAULT NULL,
   gpslon VARCHAR(12)  DEFAULT NULL,
   gpsmode INT(1)  DEFAULT NULL,
   gpsswitchenabled INT(1)  DEFAULT NULL,
   gpstime INT(12)  DEFAULT NULL,
   gpsquality INT(12)  DEFAULT NULL,
   gpssatsinview INT(2)  DEFAULT NULL,
   gpsgeoid VARCHAR(100) DEFAULT NULL,
   notes VARCHAR(200) DEFAULT NULL,
   radio0active INT(1)  DEFAULT NULL,
   radio0bandwidth INT(2)  DEFAULT NULL,
   radio0channel INT(3)  DEFAULT NULL,
   radio0mac VARCHAR(12)  DEFAULT NULL,
   radio0meshenabled INT(1)  DEFAULT NULL,
   radio0name VARCHAR(5) DEFAULT NULL,
   radio0noofaps INT(1)  DEFAULT NULL,
   radio0noofpeers INT(3)  DEFAULT NULL,
   radio1active INT(1)  DEFAULT NULL,
   radio1bandwidth INT(2)  DEFAULT NULL,
   radio1channel INT(3)  DEFAULT NULL,
   radio1mac VARCHAR(12)  DEFAULT NULL,
   radio1meshenabled INT(1)  DEFAULT NULL,
   radio1name VARCHAR(5) DEFAULT NULL,
   radio1noofaps INT(1)  DEFAULT NULL,
   radio1noofpeers INT(3)  DEFAULT NULL,
   radio2active INT(1)  DEFAULT NULL,
   radio2bandwidth INT(2)  DEFAULT NULL,
   radio2channel INT(3)  DEFAULT NULL,
   radio2mac VARCHAR(12)  DEFAULT NULL,
   radio2meshenabled INT(1)  DEFAULT NULL,
   radio2name VARCHAR(5) DEFAULT NULL,
   radio2noofaps INT(1)  DEFAULT NULL,
   radio2noofpeers INT(3)  DEFAULT NULL,
   radio3active INT(1)  DEFAULT NULL,
   radio3bandwidth INT(2)  DEFAULT NULL,
   radio3channel INT(3)  DEFAULT NULL,
   radio3mac VARCHAR(12)  DEFAULT NULL,
   radio3meshenabled INT(1)  DEFAULT NULL,
   radio3name VARCHAR(5) DEFAULT NULL,
   radio3noofaps INT(1)  DEFAULT NULL,
   radio3noofpeers INT(3)  DEFAULT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,
   sysip VARCHAR(16)  DEFAULT NULL,
   totalnoofpeers INT(3)  DEFAULT NULL,
   version VARCHAR(12)  DEFAULT NULL,
   wire0mac VARCHAR(12)  DEFAULT NULL,
   wire0name VARCHAR(5) DEFAULT NULL,
   wire0state VARCHAR(20)  DEFAULT NULL,
   wire1mac VARCHAR(12)  DEFAULT NULL,
   wire1name VARCHAR(5) DEFAULT NULL,
   wire1state VARCHAR(20)  DEFAULT NULL,



*/

//gp1_filter_type=name
//gp1_filter_replace='BMACVMTR','TR'.'Trailers':'MACVMJS','',Infrastructure:

$fullplacemark="";
$searchtable="bc".$GLOBALS[gp1_filter_type]; //our search table to find crumbs of interest only ie trailers or infrastrucure ,type is from ini file
$search4array=explode(",",$GLOBALS[gp1_filter_matches]);  //search for criteria
//loop first through the database to get an array of relevent trailers and infrastructure crumbs  , so we can search through the peers and correlate the best peers to each crumb and build the location ino detail for each coordinate
#############
## loop 1
#############
$WhCondition = "WHERE runseq = '$GLOBALS[seq]' ";
for ($x=0;$x<sizeof($search4array);$x++){ //autoincrement through the array to the maximimnumber of elements counter 
	if ($x==0) $WhCondition = $WhCondition." AND (".$searchtable." LIKE '$search4array[$x]%' ";
	if (! $x==0) $WhCondition = $WhCondition." OR ".$searchtable." LIKE '$search4array[$x]%' ";
}//end for
if (! $x == 0) $WhCondition=$WhCondition.")";  //add a bracket if there are more than 0 search conditions
echo $WhCondition.chr(10);
$query = "SELECT * FROM bcdata ".$WhCondition; 
echo $query.chr(10);
$InfoString="";
$result = mysql_query($query);
while ($row = mysql_fetch_row($result)) { //we have our rows of data , stepping through now to create infostring and peer retrieval/get query 
	dbg("d","result set number of records = ".sizeof($row));
	dbg("d","test set beggining =".$row[0]." ".$row[1]." ".$row[2]." ".$row[3]." ".$row[4]." ".$row[5]);
	$InfoString="- ".$InfoString.$row[4]." -".chr(10).chr(10); //bcname
	$InfoString=$InfoString."DateTime=".$row[1].chr(10); 
	$InfoString=$InfoString."serial no=".$row[55].chr(10); 
	$InfoString=$InfoString."ip=".$row[56].chr(10); 
	$InfoString=$InfoString."uptime=".$row[58].chr(10); 
	$InfoString=$InfoString."belongs to group=".$row[7].chr(10); 
	$InfoString=$InfoString."----------------".chr(10); 
	$InfoString=$InfoString."total no of peers=".$row[57].chr(10); 
	$InfoString=$InfoString."----------------".chr(10); 
	$InfoString=$InfoString."gpslat=".$row[11].chr(10); 
	$InfoString=$InfoString."gpsllong=".$row[12].chr(10); 
	$InfoString=$InfoString."gpslalt=".$row[10].chr(10); 
	$InfoString=$InfoString."gps mode [0=man 1=auto]=".$row[13].chr(10); 
	$InfoString=$InfoString."----------------".chr(10); 
	$InfoString=$InfoString."radio 0 Slot-".$row[27].",".$row[28].",".$row[72].chr(10); 
	$InfoString=$InfoString."radio 1 Slot-".$row[35].",".$row[36].",".$row[73].chr(10); 
	$InfoString=$InfoString."radio 2 Slot-".$row[43].",".$row[44].",".$row[74].chr(10); 
	$InfoString=$InfoString."radio 3 Slot-".$row[51].",".$row[52].",".$row[75].chr(10); 
	$InfoString=$InfoString."----------------".chr(10); 
	$InfoString=$InfoString."APT priority=".$row[2].chr(10); 
	$InfoString=$InfoString."Wire 0 State=".$row[62].chr(10); 
	$InfoString=$InfoString."Wire 1 State=".$row[65].chr(10);
	$InfoString=$InfoString.chr(10);
	$InfoString=$InfoString.$GLOBALS[additionIPhistory].chr(10);
	echo $InfoString.chr(10);
	
	$InfoString="<description><![CDATA[
	<b>Name: </b>$row[4]<br />
	<br />
	<b>DateTime: </b>$row[1]<br />
	<b>Serial No: </b>$row[55]<br />
	<b>IP: </b>$row[56]<br />
	<b>Uptime: </b>$row[58]<br />
	<b>Group: </b>$row[7]<br />
	<b>--------------------------------------------</b><br />
	<b>Total number of peer connections: </b>$row[57]<br />
	<b>--------------------------------------------</b><br />
	<b>Longitude: </b>$row[12]<br />
	<b>Latitude: </b>$row[11]<br />
	<b>Altitude: </b>$row[10]<br />
	<b>GPS mode: </b>$row[13] [0=man 1=gps]<br />
	<b>--------------------------------------------</b><br />
	<b>Radio slot 0: </b>$row[27]  $row[28]  $row[72]<br />
	<b>Radio slot 1: </b>$row[35]  $row[36]  $row[73]<br />
	<b>Radio slot 2: </b>$row[43]  $row[44]  $row[74]<br />
	<b>Radio slot 3: </b>$row[51]  $row[52]  $row[75]<br />
	<b>--------------------------------------------</b><br />
	<b>APT priority: </b>$row[2]<br />
	<b>Wire 0 state: </b>$row[62]<br />
	<b>Wire 1 state: </b>$row[65]<br />
	<b><br />
	<b>$GLOBALS[additionIPhistory] </b><br />
	<br />
	]]></description>
	";
	
	
		// funtion called for gps corrections for kml file input
	$geolat=FixPosForGoogleEarth($row[11]);
	$geolong=FixPosForGoogleEarth($row[12]);
	$geoalt=$row[10];
	
	
	
	##########
	##find the type of icon , if more than one duplicate the placemark to enable transparent backgrounds for highlighting the master and slave connections via APT
	##########
	$PMnametype=placename($row[4]);  //this function returnthe shorcutted name and type as a csv ie BMACVMTR045RBC01 returns TR045,trailer
	                                   // from ini file we get these replacements gp1_filter_replace='BMACVMTR','TR','trailer':'MACVMJS','',infrastructure:'RBC01','','':'RBC02','',''
	                                   // from the returned 'trailer' we use the trailer icon from the inifile
	$tempa=explode(",",$PMnametype);	//find our shortcutnmae and type							   
	if ($tempa[1] <> ""){
		$lastline="<styleUrl>#$tempa[1]</styleUrl>"; //here is our first type $tempa[1]
		$finalString=$InfoString.$lastline;
	}else{
		$lastline="<styleUrl>#default</styleUrl>"; //here is our first type $tempa[1]
		$finalString=$InfoString.$lastline;
	}//end if	
	echo $finalString.chr(10);
	#sleep(5);
/*	
	<b>Radio slot 0: </b>$row[27]  $row[28]  $row[72]<br />
	<b>Radio slot 1: </b>$row[35]  $row[36]  $row[73]<br />
	<b>Radio slot 2: </b>$row[43]  $row[44]  $row[74]<br />
	<b>Radio slot 3: </b>$row[51]  $row[52]  $row[75]<br />
	<b>--------------------------------------------</b><br />
	<b>APT priority: </b>$row[2]<br />
	<b>Wire 0 state: </b>$row[62]<br />
	<b>Wire 1 state: </b>$row[65]<br />
*/	
	
	//save some info into an array to use as first loop in peer paths function
	//tempstring=shortname,bcfullname,.$gpsmode.",".$geolat.",".$geolong.",".$geoalt,Wire0data,Wire1data,radio0data,radio1data,radio2data,radio3data
	//wire0data = statedata ,wire1data = statedata ,radio0data=wlan0 freq details ie. wlan2:2.4GHz:11:2462Mhz11g made by $row[28].":".$row[72]
	$tempstring=$tempa[0].",".$row[4].",".$row[13].",".$geolat.",".$geolong.",".$geoalt.",".$row[62].",".$row[65].",".$row[28].":".$row[72].",".$row[46].":".$row[73].",".$row[44].":".$row[74].",".$row[52].":".$row[75];  //make a nice gps string of csv values
	echo $tempstring.chr(10)."dude1".chr(10);
	##sleep(10);
	array_push ($crumb_plotted_kml_info,$tempstring);  //add the gps coordinates to an array to spped things up later and to twest to see if we need to do the kml section
	#echo "check=".$bcname.chr(44).$gpsmode.chr(44).$gpslat.chr(44).$gpslon.chr(44).$gpsalt.chr(10);
	dbg("o","".print_r($crumb_plotted_kml_info));  //temp printout for debugging
	echo $tempstring.chr(10)."dude2".chr(10);
	##sleep(10);
	
	
	
	
	####
	##main placemark
	####
	$fullplacemark=$fullplacemark."<Placemark>
	<name>$tempa[0]</name>
	$finalString
	<Point>
	<coordinates>$geolong,$geolat,$geoalt</coordinates>
	</Point>
	</Placemark>
	";
	echo chr(10);
	echo chr(10);
	echo chr(10);
	echo $fullplacemark.chr(10);
	echo chr(10);
	echo chr(10);
	echo chr(10);
	#echo "#sleep sect 0".chr(10);
	
	##sleep(5);
	
	/*
	$retval="<Placemark>
	<name>$row[4]</name>
	$InfoString  AKA <description><![CDATA[<b>Name: </b>BMACVMJC290RBC01<br /><b>MAC: </b>00:15:6d:6a:d8:97<br /><b>Radio no: </b>wlan1<br /><b>Modulation: </b>11<br /><b>SNR: </b>42<br /><b>Cost: </b>27599<br /><b>Date: </b>25/08/2015<br /><b>Time: </b>1315.0700<br /><b>Longitude: </b>148.059206666667<br /><b>Latitude: </b>-22.1584733333333<br /><b>Altitude: </b>256 m<br /><b>Suplimentry Data: </b>wlan2 2462 MHz 11 41-wlan1 2412 MHz 1 42-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>
	<Point>
	<coordinates>$geolong,$geolat,$geoalt</coordinates>
	</Point>
	</Placemark>
	*/
	
	####
	##APT status placemark transparent make
	####
	$extrainfoplacemark=0;
	
	if (stripos($row[62],"master",0) ){
		$lastline="<styleUrl>#gp1_filter_icon_master</styleUrl>"; //here is our type master
		$extrainfoplacemark=1;
		$placemarkname="Master";
		echo "checkpoint 1".chr(10);
	}//end if	
	if (stripos($row[65],"master",0) ){
		$lastline="<styleUrl>#gp1_filter_icon_master</styleUrl>"; //here is our type master
		$extrainfoplacemark=1;
		$placemarkname="Master";
		echo "checkpoint 2".chr(10);
	}//end if	
	if (stripos($row[62],"slave",0) ){
		$lastline="<styleUrl>#gp1_filter_icon_slave</styleUrl>"; //here is our type slave
		$extrainfoplacemark=1;
		$placemarkname="Slave";
		echo "checkpoint 3".chr(10);
	}//end if	
	if (stripos($row[65],"slave",0) ){
		$lastline="<styleUrl>#gp1_filter_icon_slave</styleUrl>"; //here is our type slave
		$extrainfoplacemark=1;
		$placemarkname="Slave";
		echo "checkpoint 4".chr(10);
	}//end if	
	
	if ($extrainfoplacemark==1){ //if we are adding an extra placemark to identifiy master and slave
		echo "checkpoint 5  $extrainfoplacemark".chr(10);
		$finalString=$InfoString.$lastline;
		echo $finalString.chr(10);
		####
		##APT status placemark transparent overlay //full place mark
		####
		//we neeed to edit/sript some info out of the $Infostring for the master slave icon so we dont get to much garbage we dont want on the screen especially icon names
		$finalString=str_replace("Name","[".$placemarkname."]  Name",$finalString);
		#$finalString="APT Type = ".$placemarkname.chr(10).chr(10).$finalString;
		
		echo $lastline.chr(10);		
		echo $finalString.chr(10);
		echo fullplacemark.chr(10);
		
		#sleep(15);
		$fullplacemark=$fullplacemark."<Placemark>
		<name>$tempa[0] [$placemarkname] $</name>
		$finalString
		<Point>
		<coordinates>$geolong,$geolat,$geoalt</coordinates>
		</Point>
		</Placemark>
		";
		echo chr(10);
		echo chr(10);
		echo chr(10);
		echo $fullplacemark.chr(10);
		echo chr(10);
		echo chr(10);
		#echo "#sleep sect 1".chr(10);
		
		##sleep(5);
		
	
	}//end if exrtaplacemark
}//endwhile
	
return $fullplacemark;
}// end of function  RetrieveCrumbsPlaceMarks


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ARCHIVEKML
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function archiveKML($days){ //yet2do trim archived files

$path = '/usr/local/bcaudit/archives/';  
$filetypes_to_delete = array("kmz");  
// Open the directory  
if ($handle = opendir($path)){  
    // Loop through the directory  
    while (false !== ($file = readdir($handle)))  
    {  
        // Check the file we're doing is actually a file  
		
        if (is_file($path.$file))  
        {  
            $file_info = pathinfo($path.$file);  
            if (isset($file_info['extension']) && in_array(strtolower($file_info['extension']), $filetypes_to_delete))  
            {  
                // Check if the file is older than X days old  
                if (filemtime($path.$file) < ( time() - ( $days * 24 * 60 * 60 ) ) )  
                {  
                    // Do the deletion  
                    unlink($path.$file);  
                }  
            }  
        }  
    }  
}  
} //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//databasetransfer
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function databasetransfer(){ //yet2do transfer dataabses to backup servers
} //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//TIDYFILES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function tidyfiles(){ //yet2do trim databse and log files
databasetrim("peers","3");#3
databasetrim("bcdata","3");#3
databasetrim("admin","180");#180
databasetrim("bcchanges","60");#60
databasetrim("ipstatus","3");#3
archiveKML("7");#60
} //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//databasetrim
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function databasetrim($tablename,$days){ //yet2do transfer dataabses to backup servers
$query = "DELETE FROM ".$tablename." WHERE DATE(entrydate) < DATE_SUB(NOW(), INTERVAL ".$days." DAY)";
dbg("d","$query =".chr(10).$query.chr(10));
$msqlr=mysql_query($query);
dbg("d","returned no of rows=".mysql_num_rows($msqlr));
} //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DATADUMPER
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function datadumper(){ //dumps data to datadump folder for pickup via winscp
dumpdata("MST_BC_TRACKER","bchistory");
dumpdata("MST_BC_TRACKER","admin");
dumpdata("MST_BC_TRACKER","bcchanges");
#dumpdata("MST_BC_TRACKER","ipstatus");
} //end function




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FIXPOSFORGOOGLEEARTH
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function FixPosForGoogleEarth($oldval){
/*	
_gps_gpsPos_gpsLat="2108.8873S"  //if S then thats southern hemisphere so we add a - negative
we use these numbers from the string '08.8873' and devide by 60 = .148121666666 , and we drop off more than 6 places to get .148121
it becomes 21.148121 then we drop the s and add a negative for southern hemispheere
_gps_gpsPos_gpsLat="-21.148121"  //if S then thats southern hemisphere so we add a - negative

_gps_gpsPos_gpsLong="14911.2502E" //if W then thats west of GMT so we add a - negative
_gps_gpsPos_gpsLong="149 AND .  AND 11.2502 / 60 "  //here we just need to get rid of the E for east
_gps_gpsPos_gpsLong="149.187391"

_gps_gpsPos_gpsPrecisionH=1.2

*/
//ie 2108.8873S  = $oldval
echo $oldval.chr(10);
$gpsarray=explode(chr(46),strval($oldval));  //split at the decimal  ie 2108 and 8873S chr46 = .
print_r($gpsarray);
$DecMax=substr($gpsarray[0],0,strlen($gpsarray[0])-2);  //get the beggining of the dec whole numbers minus 2 numbers from the end  ie 21
echo $DecMax.chr(10);
$DecPlus=substr($gpsarray[0],-2); // get the decimal val to ad to the decimal places ie 08 
echo $DecPlus.chr(10);
$hemiID=substr($gpsarray[1],-1); // get the hemisphere id ie S is south
echo $hemiID.chr(10);
$decimal=substr($gpsarray[1],0,strlen($gpsarray[1])-1);  //get the beggining of the deimal minus the S ie 8873
echo $decimal.chr(10);
$decimal=$DecPlus.".".$decimal;  //put our decimal back together  ie 08.8873
echo $decimal.chr(10);
$decimal=floatval($decimal)/60;  //divide by 60 to get the google earth compatible decimal value
echo $decimal.chr(10);
$decimal= round($decimal,6);  //round the result to 6 decimal places
echo $decimal.chr(10);

if (strtoupper($hemiID) == "S"){
	$FinalVal=$DecMax+$decimal; //add the - if required
	$FinalVal= 0-$FinalVal;
}else{
	if (strtoupper($hemiID) == "W"){
		$FinalVal=$DecMax+$decimal; //add the - if required
		$FinalVal= 0-$FinalVal;
	}else{
		$FinalVal=$DecMax+$decimal; //otherwise just add the string back together
	}
}
echo $oldval.chr(10).$FinalVal;
##sleep(15);
dbg("k","convertered for GE $oldval to $FinalVal");
return $FinalVal;
	
}  //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//PLACENAME  //returns the shortened name and the type of placemark from the ini file attribrutes
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function placename($namestr){
$returntype="";	
//recieves name  , translate new name and returns also type via csv
//gp1_filter_replace='BMACVMTR','TR'.'Trailers':'MACVMJS','',Infrastructure:
#echo $GLOBALS[gp1_filter_replace].chr(10);
$search4array=split(":",$GLOBALS[gp1_filter_replace]);  //search for criteria
for ($x=0;$x<sizeof($search4array);$x++){ //autoincrement through the array to the maximimnumber of elements counter 
	#echo $search4array[$x]." ";
	##sleep(1);
	$miniA=explode(",",$search4array[$x]) ;
	if (stripos($namestr,$miniA[0],0) ){
		$namestr=str_ireplace($miniA[0],$miniA[1],$namestr );
		if ($miniA[2] <> "" ) $returntype= $miniA[2];
	} //end if
}//end for
#echo $namestr.",".$returntype.chr(10);
##sleep(5);
return $namestr.",".$returntype;

}//end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//RetrieveCrumbsCostPaths
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function RetrieveCrumbsCostPaths(){
global $crumb_plotted_kml_info;//we have a crumb array with gps info called $crumb_gps_info
//so we can dip into the peers and get the  best peers information on the next loop
//$tempstring=$bcname.",".$gpsmode.",".$gpslat.",".$gpslon.",".$gpsalt;  //make a nice gps string of csv values
//array_push ($crumb_gps_info,$tempstring);  //add the gps coordinates to an array to spped things up later and to twest to see if we need to do the kml section


/*
Path Example placemark from ge developers give elonggated elevated extruded  trasnparent lines similar to a dam wall
 <Placemark>
      <name>Absolute Extruded</name>
      <description>Transparent green wall with yellow outlines</description>
      <styleUrl>#yellowLineGreenPoly</styleUrl>
      <LineString>
        <extrude>1</extrude>
        <tessellate>1</tessellate>
        <altitudeMode>absolute</altitudeMode>
        <coordinates> -112.2550785337791,36.07954952145647,2357
          -112.2549277039738,36.08117083492122,2357
          -112.2552505069063,36.08260761307279,2357
          -112.2564540158376,36.08395660588506,2357
          -112.2580238976449,36.08511401044813,2357
          -112.2595218489022,36.08584355239394,2357
          -112.2608216347552,36.08612634548589,2357
          -112.262073428656,36.08626019085147,2357
          -112.2633204928495,36.08621519860091,2357
          -112.2644963846444,36.08627897945274,2357
          -112.2656969554589,36.08649599090644,2357 
        </coordinates>
      </LineString>
    </Placemark>

	//here we are trialling the clamp to ground feature which may cause lines to disappear depending on the terain profile
	
 </Placemark>
	  <Placemark>
      <name>clampToGround</name>
      <description>Clamped to ground can disappear when going through hills</description>
      <styleUrl>#yellowLineGreenPoly</styleUrl>
      <LineString>
        <extrude>0</extrude>
        <tessellate>0</tessellate>
        <altitudeMode>clampToGround</altitudeMode>
        <coordinates> -112.2550785337791,36.07954952145647,2357
             -112.2656969554589,36.08649599090644,2357 
        </coordinates>
      </LineString>
    </Placemark>


	
		-peers database below-


CREATE TABLE IF NOT EXISTS peers (
   runseq INT(12) NOT NULL,
   serialno VARCHAR(20)  DEFAULT NULL,  --origin serial no
   bcname VARCHAR(40) DEFAULT NULL,  --origin crumb name
   entrydate DATETIME DEFAULT NULL,   
   address VARCHAR(16)  DEFAULT NULL,  --destination connected ip address
   connectedbcname VARCHAR(40) DEFAULT NULL,  --destination connected crumb
   mac VARCHAR(12) DEFAULT NULL,  --destination/connected mac address
   action VARCHAR(12) DEFAULT NULL,
   enabled INT(1) DEFAULT NULL,
   cost INT(6) DEFAULT NULL,
   rate INT(4) DEFAULT NULL,
   rssi INT(4) DEFAULT NULL,
   ssignal INT(4) DEFAULT NULL,
   sitename VARCHAR(40) DEFAULT NULL,
   moredetail VARCHAR(80) DEFAULT NULL  --our cct,cct name,channel or state,destination cct name,destination channel or state

   --MariaDB [MST_BC_TRACKER]> SELECT * FROM peers ;
--+--------+----------------+------------+---------------------+---------------+-----------------+--------------+--------+---------+-------+------+------+---------+-------------+---------------------------------------------------+
--| runseq | serialno       | bcname     | entrydate           | address       | connectedbcname | mac          | action | enabled | cost  | rate | rssi | ssignal | sitename    | moredetail                                        |
--+--------+----------------+------------+---------------------+---------------+-----------------+--------------+--------+---------+-------+------+------+---------+-------------+---------------------------------------------------+
--|      2 | LX 2424-7808   | MST17      | 2015-11-11 00:28:39 | 192.168.3.231 | MST WAP BC      | 00156d6a1f0b | ADD    |       1 | 17760 |  360 |   62 |     -37 | DevPlatform | wireless0,wlan1,11,wlan2,11                       |
--|      2 | LX 2424-7808   | MST17      | 2015-11-11 00:28:39 | 192.168.3.231 | MST WAP BC      | 00156d6a1fad | ADD    |       1 | 19825 |  360 |   57 |     -41 | DevPlatform | wireless1,wlan0,1,wlan1,1                         |
--|      2 | LX 2424-7808   | MST17      | 2015-11-11 00:28:39 | 192.168.3.231 | MST WAP BC      | 00d012e7ed99 | ADD    |       1 |   295 |  360 |   57 |     -41 | DevPlatform | wired0,eth0,APT_STATE_SLAVE,eth0,APT_STATE_MASTER |


runseq,serialno,bcname,entrydate,address,connectedbcname,mac,action,enabled,cost,rate,rssi,ssignal,sitename,moredetail


also referece ini file 

gp1_filter_path_cost_poor_range=10000-9999999999
gp1_filter_path_cost_poor_polycolor=ff00ff55
gp1_filter_path_cost_poor_color=ff00ff55
gp1_filter_path_cost_poor_width=1
gp1_filter_path_cost_average_range=5000-9999
gp1_filter_path_cost_average_polycolor=ff00ff55
gp1_filter_path_cost_average_color=ff00ff55
gp1_filter_path_cost_average_width=1
gp1_filter_path_cost_good_range=1000-4999
gp1_filter_path_cost_good_polycolor=ff00ff55
gp1_filter_path_cost_good_color=ff00ff55
gp1_filter_path_cost_good_width=1
gp1_filter_path_cost_excellent_range=1-999
gp1_filter_path_cost_excellent_polycolor=ff00ff55
gp1_filter_path_cost_excellent_color=ff00ff55
gp1_filter_path_cost_excellent_width=1


  */


//here is the array details to check for peer infomation
//save some info into an array to use as first loop in peer paths function
//tempstring=shortname,bcfullname,.$gpsmode.",".$geolat.",".$geolong.",".$geoalt,Wire0data,Wire1data,radio0data,radio1data,radio2data,radio3data
//wire0data = statedata ,wire1data = statedata ,radio0data=wlan0 freq details ie. wlan2:2.4GHz:11:2462Mhz11g made by $row[28].":".$row[72]
//$tempstring=tempa[0].",".$row[4].",".$row[13].",".$geolat.",".$geolong.",".$geoalt.",".$row[62].",".$row[65].",".$row[28].":".$row[72].",".$row[46].":".$row[73].",".$row[44].":".$row[74].",".$row[52].":".$row[75];  //make a nice gps string of csv values
//array_push ($crumb_plotted_kml_info,$tempstring);  //add the gps coordinates to an array to spped things up later and to twest to see if we need to do the kml section
	
$recordkeepingarray=array();  //record keeeping array tracka which paths have been completed to stop duplicates  
$MegaCostText="";
$ACords="";
$BCords="";
$GPSA=$GLOBALS["crumb_gps_info"];  //this was done here for readability copies the array for the gps coords
$mybestcostfreq="";  //adds the freq and channel to the cost desction in the kml ie Good 11 [2.4 Ghz]

####
##first loop through the saved array to get the breadcrumb source and destination , then gest the path for each link , then get best ,format , save for kml , and update the matrix array to check if the pathway is allready witten to prevent double occurances of paths. 
####

	dbg("o","".print_r($crumb_plotted_kml_info));  //temp printout for debugging
echo "1.1".chr(10);
	##sleep(10);
$x=0;
$y=0;
$G=0;
	for ($x=0;$x<sizeof($crumb_plotted_kml_info);$x++){ //autoincrement through the array to the maximimnumber of elements counter 
		$tempA=explode(",",$crumb_plotted_kml_info[$x]);
		for ($y=0;$y<sizeof($crumb_plotted_kml_info);$y++){ //autoincrement through the array to the maximimnumber of elements counter 
			$tempB=explode(",",$crumb_plotted_kml_info[$y]);
			echo $tempA[1]."--".$tempB[1].chr(10);
			##sleep(5);
			if ($tempA[1] != $tempB[1]){ //quick checkl first to make sure we have a different origin/destination from our double array search x and y
				echo $tempA[1]."--".$tempB[1].chr(10)."A<>B".chr(10);
				##sleep(5);
					echo $tempA[1]."--".$tempB[1].chr(10)."Done it already".chr(10);
					if (in_array($tempA[1]."--".$tempB[1],$recordkeepingarray)){
					}else{
					  //if we have NOT proccessed this already .. lets go
						//ceclare some veariales /resetthem
						$mybestcost=9999999999;
						$mybestpathway="";
						$InfoString="- Peers Info -".chr(10).chr(10); //title
						$InfoString=$InfoString.$tempA[1]."--".$tempB[1].chr(10);  //bcname--connectedname 
						$PeerCostString="";
						$PeerCostString=$PeerCostString.chr(10).chr(10).chr(10)."---------------".chr(10)."-Peer List-".chr(10).chr(10); //header
						$PeerSNRString="";
						$WhCondition = " WHERE (runseq = '$GLOBALS[seq]' and bcname = '$tempA[1]' and connectedbcname = '$tempB[1]') "; //IST ROUND THEN WE SWAP THE CRUMBS AROUND TO GET THE OTHER PEER INFO
						$query = "SELECT * FROM peers".$WhCondition; 
						$queryP = mysql_query($query);
#+--------+----------------+--------------+---------------------+---------------+-----------------+--------------+--------+---------+------+------+------+---------+-------------+-----------------------------+
#| runseq | serialno       | bcname       | entrydate           | address       | connectedbcname | mac          | action | enabled | cost | rate | rssi | ssignal | sitename    | moredetail                  |
#+--------+----------------+--------------+---------------------+---------------+-----------------+--------------+--------+---------+------+------+------+---------+-------------+-----------------------------+
#|     16 | LX4-2295-21839 | cams test bc | 2015-11-21 08:48:26 | 192.168.3.231 | MST WAP BC      | 00156d6a1f0b | ADD    |       1 | 1808 |  540 |   64 |     -31 | DevPlatform | wireless0,wlan1,11,wlan2,11 |
#|     16 | LX4-2295-21839 | cams test bc | 2015-11-21 08:48:26 | 192.168.3.231 | MST WAP BC      | 00156d6a1fad | ADD    |       1 | 1374 |  540 |   67 |     -30 | DevPlatform | wireless3,wlan2,1,wlan1,1   |
#+--------+----------------+--------------+---------------------+---------------+-----------------+--------------+--------+---------+------+------+------+---------+-------------+-----------------------------+
#uptohere echoall the strings to faultfind
						echo $queryP.chr(10);
						#sleep(10);
						while ($row = mysql_fetch_row($queryP)) { //we have our rows of data , stepping through now to create infostring and peer retrieval/get query 
							echo chr(10).chr(10).chr(10)."sizeof($row)=".sizeof($row).chr(10);
							dbg("d","result set number of records = ".sizeof($row));
							dbg("d","test set beggining =".$row[0]." ".$row[1]." ".$row[2]." ".$row[3]." ".$row[4]." ".$row[5]);
							//find the wlan details to simplify reading
							$tempDETAILS=explode(",",$row[14]); //row14=moredetails for peer to peer info
						$PeerCostString=$PeerCostString."'".$tempA[1]."' to '".$tempB[1]."' on '".$tempDETAILS[1]."' Channel '".$tempDETAILS[2]."' COST =".$row[9]."  [SNR=".ABS($row[12])."]".chr(10); //cost of crumb A
//							$PeerSNRString=$PeerSNRString."CrumbA '".$tempA[1]."' Pathway '".$tempDETAILS[1]."' Channel '".$tempDETAILS[2]."' SNR =".ABS($row[12]).chr(10); //snr of crumb A
							if ((int)$row[9]<(int)$mybestcost) { //this is the best cost , we keep this metric to color the pathway
								$mybestcost=$row[9];
								$mybestcostfreq=$tempDETAILS[2];  //adds the freq and channel to the cost desction in the kml ie Good 11 [2.4 Ghz]
								echo "newbestcost=".$mybestcost.chr(10);
								$mybestpathwaystring="'".$tempA[1]."' to '".$tempB[1]."' on '".$tempDETAILS[1]."' Channel '".$tempDETAILS[2]."' COST =".$row[9]."  [SNR=".ABS($row[12])."]".chr(10); //cost of crumb A
								$mybestpathway=$tempA[1].",".$tempDETAILS[1].",".$tempDETAILS[2].",".$tempB[1].",".$tempDETAILS[3].",".$tempDETAILS[4]; //name,eth0,APTSATE_SLAVE ,nameb , eth0 , master
								echo "newbestpathwaystring=".$mybestpathwaystring.chr(10);
								#sleep(3);
							}//end if
						}//end while 1st query
						echo "PeerCostString=".$PeerCostString.chr(10);
						#sleep(1);
						$WhCondition = " WHERE (runseq = '$GLOBALS[seq]' and bcname = '$tempB[1]' and connectedbcname = '$tempA[1]') ";//2ND ROUND OF RECORDS
						$query = "SELECT * FROM peers".$WhCondition; 
						$queryP = mysql_query($query);
						echo $queryP.chr(10);
						#sleep(5);
						while ($row = mysql_fetch_row($queryP)) { //we have our rows of data , stepping through now to create infostring and peer retrieval/get query 
							dbg("d","result set number of records = ".sizeof($row));
							dbg("d","test set beggining =".$row[0]." ".$row[1]." ".$row[2]." ".$row[3]." ".$row[4]." ".$row[5]);
							//find the wlan details to simplify reading
							$tempDETAILS=explode(",",$row[14]); //row14=moredetails for peer to peer info
							$PeerCostString=$PeerCostString."'".$tempB[1]."' to '".$tempA[1]."' on '".$tempDETAILS[1]."' Channel '".$tempDETAILS[2]."' COST =".$row[9]."  [SNR=".ABS($row[12])."]".chr(10); //cost of crumb A
//							$PeerCostString=$PeerCostString."CrumbB '".$tempB[1]."' Pathway '".$tempDETAILS[1]."' Channel '".$tempDETAILS[2]."' cost =".$row[9].chr(10); //cost of crumb B
//							$PeerSNRString=$PeerSNRString."CrumbB '".$tempB[1]."' Pathway '".$tempDETAILS[1]."' Channel '".$tempDETAILS[2]."' SNR =".ABS($row[12]).chr(10); //snr of crumb B
							if ((int)$row[9]<(int)$mybestcost) { //this is the best cost , we keep this metric to color the pathway
								$mybestcost=$row[9];
								$mybestcostfreq=$tempDETAILS[2];  //adds the freq and channel to the cost desction in the kml ie Good 11 [2.4 Ghz]
								echo "newbestcost=".$mybestcost.chr(10);
								$mybestpathwaystring="'".$tempB[1]."' to '".$tempA[1]."' on '".$tempDETAILS[1]."' Channel '".$tempDETAILS[2]."' COST =".$row[9]."  [SNR=".ABS($row[12])."]".chr(10); //cost of crumb B
								$mybestpathway=$tempB[1].",".$tempDETAILS[1].",".$tempDETAILS[2].",".$tempA[1].",".$tempDETAILS[3].",".$tempDETAILS[4]; //name,eth0,APTSATE_SLAVE ,nameb , eth0 , master
								echo "newbestpathwaystring=".$mybestpathwaystring.chr(10);
								#sleep(3);
							}//end if
						}//end while 2nd query
						
						//$mybestpathwaystring="'".$tempA[1]."' to '".$tempB[1]."' ".$tempDETAILS[1].",".$tempDETAILS[2].",".$tempB[1].",".$tempDETAILS[3].",".$tempDETAILS[4]; //name,eth0,APTSATE_SLAVE ,nameb , eth0 , master
						$PeerCostString=$PeerCostString.chr(10)."---------------".chr(10).chr(10); //footer
						$PeerCostString=chr(10)."---------------".chr(10)."-Best Cost-".chr(10).chr(10).$mybestpathwaystring.$PeerCostString.chr(10); //add our two strings together to make the COST sects combined
						$PeerSNRString="";  // empty the peers SNR
						$tempstring=$tempA[1]."--".$tempB[1];
						array_push($recordkeepingarray,$tempstring);  //add A-B and the B-A to prevent duplicates
						$tempstring=$tempB[1]."--".$tempA[1];
						array_push($recordkeepingarray,$tempstring);  //add A-B and the B-A to prevent duplicates
						echo "uptohere to make a cost pathway placemark , temp stop";
						echo "PeerCostString=".$PeerCostString.chr(10);
						echo "newbestcost=".$mybestcost.chr(10);
						echo "newbestpathway=".$mybestpathway.chr(10);
						
						//get our variables in arrays for cost levels from the ini file
						$levelp=explode("-",$GLOBALS["gp1_filter_path_cost_poor_range"]);
						$levela=explode("-",$GLOBALS["gp1_filter_path_cost_average_range"]);
						$levelg=explode("-",$GLOBALS["gp1_filter_path_cost_good_range"]);
						$levele=explode("-",$GLOBALS["gp1_filter_path_cost_excellent_range"]);
						//compare best cost to levels
						if (($levelp[0] <= (int)$mybestcost) && ((int)$mybestcost <= $levelp[1])) $costdesc="poor"; //if bestcost is in the range of a poor cost //  ($min <= $value) && ($value <= $max)
						if (($levela[0] <= (int)$mybestcost) && ((int)$mybestcost <= $levela[1])) $costdesc="average"; //if bestcost is in the range of a poor cost //  ($min <= $value) && ($value <= $max)
						if (($levelg[0] <= (int)$mybestcost) && ((int)$mybestcost <= $levelg[1])) $costdesc="good"; //if bestcost is in the range of a poor cost //  ($min <= $value) && ($value <= $max)
						if (($levele[0] <= (int)$mybestcost) && ((int)$mybestcost <= $levele[1])) $costdesc="excellent"; //if bestcost is in the range of a poor cost //  ($min <= $value) && ($value <= $max)
						
						$PeerCostString=ucfirst($costdesc)." - ".$mybestcostfreq.chr(10).$PeerCostString;
						// get our coordinates ready for the placemark	
						//$tempstring=$bcname.",".$gpsmode.",".$gpslat.",".$gpslon.",".$gpsalt;  //make a nice gps string of csv values
						//array_push ($crumb_gps_info,$tempstring);  //add the gps coordinates to an array to spped things up later and to twest to see if we need to do the kml section
						for ($g=0;$g<sizeof($GPSA);$g++){ //autoincrement through the array to the maximimnumber of elements counter 
							$tempG=explode(",",$GPSA[$g]);  //explode array contents intoanother array for idividual values
							if ($tempA[1]==$tempG[0]) $ACords=FixPosForGoogleEarth($tempG[3]).",".FixPosForGoogleEarth($tempG[2]).",".$tempG[4]; //save the latlongalt co-ords for A
							if ($tempB[1]==$tempG[0]) $BCords=FixPosForGoogleEarth($tempG[3]).",".FixPosForGoogleEarth($tempG[2]).",".$tempG[4]; //save the latlongalt co-ords for B
						}//end for
						
						echo CHR(10).$ACords.CHR(10).$BCords.CHR(10);
						#sleep(3);
						//make the placmark for the path
						$MegaCostText=$MegaCostText."
	  <Placemark>
	  <name>$tempA[1] -- $tempB[1]</name>
      <description>$PeerCostString</description>
      <styleUrl>#gp1_filter_path_cost_$costdesc</styleUrl>
      <LineString>
        <extrude>0</extrude>
        <tessellate>0</tessellate>
        <altitudeMode>clampToGround</altitudeMode>
        <coordinates> $ACords
             $BCords 
        </coordinates>
      </LineString>
    </Placemark>";


						echo CHR(10).$MegaCostText.CHR(10);	
						sleep (5);
					}//endif
				}//end if
			}//end if
		}//end for

echo CHR(10).$MegaCostText.CHR(10);	
#sleep(15);
return $MegaCostText;
/*

	$InfoString="<description><![CDATA[
	<b>Name: </b>$row[4]<br />
	<br />
	<b>Serial No: </b>$row[55]<br />
	<b>IP: </b>$row[56]<br />
	<b>Uptime: </b>$row[58]<br />
	<b>Group: </b>$row[18]<br />
	<b>--------------------------------------------</b><br />
	<b>Total number of peers: </b>$row[57]<br />
	<b>--------------------------------------------</b><br />
	<b>Longitude: </b>$row[12]<br />
	<b>Latitude: </b>$row[11]<br />
	<b>Altitude: </b>$row[10]<br />
	<b>GPS mode: </b>$row[13] [0=man 1=gps]<br />
	<b>--------------------------------------------</b><br />
	<b>Radio slot 0: </b>$row[27]  $row[28]  $row[72]<br />
	<b>Radio slot 1: </b>$row[35]  $row[36]  $row[73]<br />
	<b>Radio slot 2: </b>$row[43]  $row[44]  $row[74]<br />
	<b>Radio slot 3: </b>$row[51]  $row[52]  $row[75]<br />
	<b>--------------------------------------------</b><br />
	<b>APT priority: </b>$row[2]<br />
	<b>Wire 0 state: </b>$row[62]<br />
	<b>Wire 1 state: </b>$row[65]<br />
	<br />
	]]></description>
	";
	
 </Placemark>
	  <Placemark>
      <name>clampToGround</name>
      <description>Clamped to ground can disappear when going through hills</description>
      <styleUrl>#yellowLineGreenPoly</styleUrl>
      <LineString>
        <extrude>0</extrude>
        <tessellate>0</tessellate>
        <altitudeMode>clampToGround</altitudeMode>
        <coordinates> -112.2550785337791,36.07954952145647,2357
             -112.2656969554589,36.08649599090644,2357 
        </coordinates>
      </LineString>
    </Placemark>


	*/
  


}//end function RetrieveCrumbsCostPaths()


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FTP    attempt to ftp the kmz file out
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ftp($s,$archive){
// set up basic connection
dbg("f","ftp function start with input =".$s." / ".$archive);
/* ini file variables

ftp_1_server = 192.168.3.250
ftp_1_port=21
ftp_1_user_name= BCTfileupload
ftp_1_user_pass=BCTfiles0192
ftp_2_server = 101.178.255.174
ftp_2_port=88
ftp_2_user_name= BCTfileupload
ftp_2_user_pass=BCTfiles0192

*/


//#$s=$GLOBALS["sitename"];
$destination_file=$s."_".date("Ymd_His").".kmz";
$Destination_dir=$s;
$source_file=trim($s.".kmz"); //kmz file to send
$source_dir="" ;//here
error_reporting(E_ALL); //helps with debugging
if (checkfilefirst("",$source_file,get_current_user()) == "OK"){ //checks ownership permissiions etc
	for ($x=1;$x<=9;$x++){ //autoincrement through from 1 to 9 possible ftp servers stored inside the ini file
	echo $x;
		$ftp_server="ftp_".$x."_server";
		$ftp_port="ftp_".$x."_port";
		$ftp_un="ftp_".$x."_user_name";
		$ftp_up="ftp_".$x."_user_pass";
		if ($GLOBALS[$ftp_server] != "") { //if the globals array value for the next server ip or host name exists else skip
			dbg("f","ftp fields for connections ".$x."= Server=".$GLOBALS[$ftp_server]." Port=".$GLOBALS[$ftp_port]." User=".$GLOBALS[$ftp_un]." pass=".$GLOBALS[$ftp_up]." file=".$s);
			$conn_id = ftp_connect($GLOBALS[$ftp_server],$GLOBALS[$ftp_port]); //connect
			if ($conn_id == false){
					dbg("e","ftp Connect failed=".$conn_id);
			}else{ //cool success
				if ($conn_id == true) dbg("f","ftp Connect success ".$x."= Server=".$GLOBALS[$ftp_server]." Port=".$GLOBALS[$ftp_port]);
				// login with username and password
				$login_result = ftp_login($conn_id, $GLOBALS[$ftp_un], $GLOBALS[$ftp_up]);
				if ($login_result == false){
					dbg("e","ftp Login failed User=".$GLOBALS[$ftp_un]." pass=".$GLOBALS[$ftp_up]);
				}else{
					echo "login result OK =".$login_result." / ".$conn_id.chr(10); //error confirmed
					// check connection
					if ((!$conn_id) || (!$login_result)) {  //check connection 
						dbg("e","ftp Error login failed for  ".$x."= Server=".$GLOBALS[$ftp_server]." Port=".$GLOBALS[$ftp_port]." User=".$GLOBALS[$ftp_un]." pass=".$GLOBALS[$ftp_up]." file=".$s);
					} else {
						dbg("e","ftp login success for  ".$x."= Server=".$GLOBALS[$ftp_server]." Port=".$GLOBALS[$ftp_port]." User=".$GLOBALS[$ftp_un]." pass=".$GLOBALS[$ftp_up]." file=".$s);
						sleep(1);
						echo ftp_pasv($conn_id, true).chr(10); //set connection to passive to force single port
						sleep(1);
						echo $Destination_dir." , ".$destination_file ." , " .$source_dir. $source_file.chr(10);
						if (ftp_chdir($conn_id, $Destination_dir)==False){ //cant change to directoryso we will make it first
							dbg("f","ftp Destination directory change unsuccessfull attempting to create it dir=".$Destination_dir);
							if (! ftp_mkdir($conn_id, $Destination_dir)) {  //make a new destination directory
								dbg("e","ftp Destination directory mkdir Error  no directory created  check permissions at destination ftp server =".$Destination_dir);
							} else {
								dbg("f","ftp Destination directory success directory=".$Destination_dir);
							}
							if (ftp_chdir($conn_id, $Destination_dir)){
								dbg("f","ftp Destination directory changed to  successfull directory=".$Destination_dir);
							}else{
								dbg("e","ftp Destination directory changed Error  no directory change check permissions at destination ftp server=".$Destination_dir);
							}
						}else{  //we just changed directorys
							dbg("f","ftp Destination directory changed to  successfull directory=".$Destination_dir);
						}
						// upload the file
						dbg("e","ftp put paramters ".$x."= Conid=".$conn_id." Destination file same name=".$source_dir." source dir=".$source_dir." source file=".$source_file." site=".$s. " wdir=".getcwd());
						if (!ftp_put($conn_id,$source_file,$source_file, FTP_BINARY)){
							dbg("e","ftp PUT Error  no file sent =".$source_dir.$source_file);
						} else {
							dbg("f","ftp PUT success file sent =".$source_dir.$source_file);
							if ($archive != "") {
									dbg("f","ftp Archive set to activate remote rename and resend");
								// try to rename $old_file to $new_file FOR ARCHIVING  , THEN REDO THE COPY
								if (ftp_rename($conn_id, $source_file, $destination_file)){
									dbg("f","ftp success rename command sent =".$source_file ." RENAME TO ".$destination_file);
								}else{
									dbg("e","ftp Error rename command error ,file may exist.. see logs , as it can happen with two different entrys to same server, or check permissions on ftp server =".$source_file ." RENAME TO ".$destination_file);
								}
								// upload the file ... again
								dbg("e","ftp put paramters ".$x."= Conid=".$conn_id." Destination file same name=".$source_dir." source dir=".$source_dir." source file=".$source_file." site=".$s. " wdir=".getcwd());
								if (!ftp_put($conn_id, $source_file,$source_file, FTP_BINARY)){
									dbg("e","ftp PUT Error  no file sent =".$source_dir.$source_file);
								} else {
									dbg("f","ftp PUT success file sent =".$source_dir.$source_file);
								} //end if put again
							} //end if archive
						}//end if
					} //end if
				} //end if
			} //end if
			if (! is_bool($conn_id)) ftp_close($conn_id); 		// close the FTP stream if started 
			
		}//end if
		#sleep(1);
	} //end for

}//end if

}//end function

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//zipkmz   make a kmz file and put it in /archives
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function zipkmz($s){
//$s=sitename


$file = $s.".kmz";
dbg("f","KMZ site name =" . $file);
dbg("f","KMZ ini system user name =" . $GLOBALS["linuxsytemfileusername"]);
dbg("f","KMZ linux user name =" . get_current_user());

$zip = new ZipArchive();


if (unlink($file)) dbg("f","zipkmz deleted ".$file. " "); // delete the kmz file if it exists

if ($zip->open($file, ZIPARCHIVE::CREATE)!==TRUE) {
dbg("e","zipkmz Error - cannot open new zip file - check zip librarys are installed in Yast 'Zlib' and 'PHP5-Zip' ".$file);
exit("cannot open <$file>\n");
}

if (checkfilefirst("kml","active.kml",get_current_user()) != "OK"){
	dbg("e","zipkmz Error - cannot read active.kml in kml directory  - check directory exists and permissions for ".get_current_user());
}else{
$zip->addFile('kml/active.kml', 'doc.kml');
}	

###########add icons;
if($zip->addEmptyDir('icons')) {
       	dbg("f","zipkmz icons directory inserted into zip");
} else {
       	dbg("e","zipkmz icons directory error, not inserted into zip");
}

	
$path    = 'kml/icons';
$files = scandir($path);
print_r($files);
for ($x=1;$x<sizeof($files);$x++){ //autoincrement through from no2 of the array of files names to the maximimnumber of elements counter 
	if (($files[$x]<>".") and ($files[$x]<>"..")) {
		if (checkfilefirst("$path",$files[$x],get_current_user()) == "OK"){ //checks ownership permissiions etc
			IF ($zip->addFile("kml/icons/".$files[$x], "icons/".$files[$x])) { //add files to archive
				dbg("f","zipkmz Created file in ZIP icons/'".$files[$x]);
			} else {
				dbg("e","zipkmz Failed to add to ZIP archive in ZIP icons/'".$files[$x]);
			}
		}
	}//end if files`	
} //end for x

##########add logs;
if($zip->addEmptyDir('logs')) {
       	dbg("f","zipkmz logs directory inserted into zip");
} else {
      	dbg("e","zipkmz logs directory error, not inserted into zip");
}
$path = 'logs';
$files = scandir($path);
print_r($files);
for ($x=1;$x<sizeof($files);$x++){ //autoincrement through from no2 the array of files names to the maximimnumber of elements counter 
	if (($files[$x]<>".") and ($files[$x]<>"..")) {
		if (checkfilefirst("$path",$files[$x],get_current_user()) == "OK"){ //checks ownership permissiions etc
			IF ($zip->addFile("logs/".$files[$x], "logs/".$files[$x])) {  //add files to archive
				dbg("f","zipkmz Created file in ZIP logs/'".$files[$x]);
			} else {
				dbg("e","zipkmz Failed to add to ZIP archive in ZIP logs/'".$files[$x]);
			}
		}	
	} // end if files
} //end for x

$zip->close();

if (! is_readable($file)) dbg("e","zipkmz Error - cannot read new zip file - check zip librarys are installed in Yast 'Zlib' and 'PHP5-Zip' ".$file);
if (is_readable($file)) dbg("e","zipkmz New zip filereadable ".$file);
		
		
if (!is_dir('archives')) {
    mkdir('archives',0755); //make archives with permision level 0755
}

//create the archive with date
if (Copy($s.".kmz","archives/".$s."_".date("Ymd_His").".kmz")) {
	dbg("f","zipkmz Created file in archives/".$s."_".date("Ymd_His").".kmz");
} else {
	dbg("e","zipkmz Error could not create file in archives/".$s."_".date("Ymd_His").".kmz");
}

//create the last active kmz for network limking to GE
if (Copy($s.".kmz","archives/".$s."_LastActiveCopy.kmz")) {
	dbg("f","zipkmz Created file in archives/".$s."_LastActiveCopy.kmz");
} else {
	dbg("e","zipkmz Error could not create file in archives/".$s."_LastActiveCopy.kmz");
}
dbg("f","zipkmz end function");
} // end funtion zipkmz


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//checkfilefirst    checks the directory exists [makes if it not , check the file in the directory and write permissions and the owner of the file and checks to be readable , created to minimise errors in dev and production environments 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function checkfilefirst($d,$f,$o){  //$d = directory is made if not exist, $f=file name or blank to just check the directory  , $o = owner
 // owner will be the user/group the PHP script is run under
 //had to write this for zip files containing bad permissioned ziiped files causing grief during ftp
 dbg("f","checkfilefirst inputs d=" . $d." f=".$f. " o=".$o);
 if ($d!="") $d=$d."/";
 dbg("f","checkfilefirst modified input if d not ='' inputs d=" . $d." f=".$f. " o=".$o);
 if ( (!file_exists($d)) AND ($d!="")) {  // if directory does not exist make it AND THE DIRECTORY FIELD IS NOT BLANK MEANING NOT OUR CURRENT DIREECTOR
     dbg("f","checkfilefirst directory does not exist , making it now" . $d." ".$f. " ".$o);
	 $oldmask = umask(0);  // helpful when used in linux server //dunno what this is  i cutnpasted  	
     mkdir ($d, 0755);  //directory made
     dbg("f","checkfilefirst directory made" .$d." ".getcwd());
	 $returnval = "OK";
}else{  //directory exists check for acces via writing a temp file
	dbg("f","checkfilefirst checking file write access to directory".$d." by ".$f." in CWD ".getcwd());
	if (! file_put_contents ($d.'test.txt', 'Test for access to the file system')){
	    dbg("f","checkfilefirst non fatal error - file write access NOT allowed to directory ".$d." in CWD ".getcwd());
		$returnval="Error - file write access not allowed to directory ".$d." in CWD ".getcwd();
	}else{ //cool we have a directory and write access
		dbg("f","checkfilefirst write access allowed ".$d." in CWD ".getcwd());
		unlink($d.'test.txt'); //now delete the temp file we just made	
	    dbg("f","checkfilefirst temp file deleted - file write access allowed to directory ".$d." in CWD ".getcwd());
		if ($f != "" ){ //if a file check is required due to the file name is given  we test it otherwise we are done with the matching else statement
			if (! file_exists($d.$f)) { //check it exists
			    dbg("f","checkfilefirst Error - file does not exist ".$f." in " .$d." in CWD ".getcwd());
				$returnval="Error - file does not exist ".$f." in CWD ".getcwd();
			}else{ //cool it exists
				dbg("f","checkfilefirst file exists ".$f." in " .$d." in CWD ".getcwd());
				if (! chown($d.$f,$o)) { //check we are the owner
					dbg("f","checkfilefirst Error - could not change owner in ".$f." in " .$d." in CWD ".getcwd());
					$returnval="Error - could not change owner in ".$f." in CWD ".getcwd();
				}else{ //cool we are the owner
					dbg("f","checkfilefirst owner rights OK ".$f." in " .$d." in CWD ".getcwd());
					if (! chmod($d.$f,0755)) { //check the permissions
						dbg("f","checkfilefirst Error-permissions set failed ".$f." in " .$d." in CWD ".getcwd());
						$returnval="Error - could not change permissions in ".$f." in CWD ".getcwd();
					}else{ //cool permissions set was ok
						dbg("f","checkfilefirst permission set OK ".$f." in " .$d." in CWD ".getcwd());
						if (! is_readable($d.$f)){  //check if readable
							dbg("f","checkfilefirst Error - file not readable ".$f." in " .$d." in CWD ".getcwd());
							$returnval="Error - file not readable ".$f." in CWD ".getcwd();
						}else{ //cool everthing is good
							dbg("f","checkfilefirst -file readable OK ".$f." in " .$d." in CWD ".getcwd());
							$returnval="OK";
						}
					}	
				}
			}
		}else{
			dbg("f","checkfilefirst file name not given skipped filename checks ".$f." in " .$d." ".getcwd());
			$returnval="OK";
		}
	}
}
dbg("f","checkfilefirst return value =".$returnval." for these inputs ".$f." in " .$d." ".getcwd());
return $returnval;
}//end function checkfilefirst
/*
if ($zip->open('test.zip') == TRUE) {

    //connect to the ftp server
    $conn_id = ftp_connect('ftp.example.com');
    $login_result = ftp_login($conn_id, 'user', 'password');    

    //if the connection is ok, then...
    if ($login_result) {

        //iterate each zipped file
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);

            //create a "local" temp file in order to put it "remotely" in the same machine
            $temp = tmpfile();

            //create the new file with the same name from the extracted file in question
            ftp_fput($conn_id, $ftp_path_to_unzip . $filename, $temp, FTP_ASCII);

            //set write permissions, eventually we will put its content
            ftp_site($conn_id, "CHMOD 0777 " . $ftp_path_to_unzip . $filename);

            //open the new file that we have created
            $fp = fopen($local_path_to_unzip . $filename, 'w');

            //put the content from zipped file
            $content = $zip->getFromName($filename);
            fputs($fp, $content);

            //close the file
            fclose($fp);

            //now only the owner can write the file
            ftp_site($conn_id, "CHMOD 0644 " . $ftp_path_to_unzip . $filename);

        }
    }

    // close the connection and the file handler
    ftp_close($conn_id);

    //close the zip file
    $zip->close();
}
*/



////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DUMPDATA
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
function dumpdata($databasename,$tablename){

/*
$DBserver	= "localhost";
$DBname		= "MST_BC_TRACKER";
$DBuser		= "root";
$DBpasswd	= "";
$DBconn = mysql_connect($DBserver, $DBuser, $DBpasswd);// or die("Could not connect to database server $DBserver<br>");
mysql_select_db($DBname);// or die("Could not select database '$DBname'<br>");
*/

//lots of attempts to output colmuns only...no good
#$query="select column_name from information_schema.columns where table_schema='".$datyabasename."' and table_name='".$tablename."'";
#$query="select column_name from information_schema.columns";
#$query = "mysqldump -u root -h 127.0.0.1 -d ".$databasename." ".$tablename." > ".$GLOBALS["mywdir"]."/datadump/".$tablename.".col";
#dbg("d","$query =>".chr(10).$query.chr(10)."<=".chr(10));
#$msqlr=mysql_query($query);
#exec($query);
#dbg("d","msqlr=".$msqlr);
#sleep(5);


#$query = "mysqldump -u root -h 127.0.0.1 ".$databasename." ".$tablename." > ".$GLOBALS["mywdir"]."/datadump/".$tablename.".sql";
$query = "mysqldump -u root -h 127.0.0.1 -T ".$GLOBALS["mywdir"]."/datadump ".$databasename." ".$tablename." --fields-terminated-by=','";
dbg("d","$query =>".chr(10).$query.chr(10)."<=".chr(10));
#$msqlr=mysql_query($query);
exec($query);
#dbg("d","msqlr=".$msqlr);
#sleep(5);

#$query = "mysqldump -u root -h 127.0.0.1 ".$databasename." ".$tablename." > ".$GLOBALS["mywdir"]."/datadump/".$tablename.".sql";
$query = "mysqldump -u root -h 127.0.0.1 -T ".$GLOBALS["mywdir"]."/datadump ".$databasename." ".$tablename." --fields-terminated-by=','";
dbg("d","$query =>".chr(10).$query.chr(10)."<=".chr(10));
#$msqlr=mysql_query($query);
exec($query);
#dbg("d","msqlr=".$msqlr);
#sleep(5);



}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Calculates the great-circle distance between two points, with
 * the Haversine formula.
 * @param float $latitudeFrom Latitude of start point in [deg decimal]
 * @param float $longitudeFrom Longitude of start point in [deg decimal]
 * @param float $latitudeTo Latitude of target point in [deg decimal]
 * @param float $longitudeTo Longitude of target point in [deg decimal]
 * @param float $earthRadius Mean earth radius in [m]
 * @return float Distance between points in [m] (same as earthRadius)
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function distance($lat1, $lon1, $lat2, $lon2, $unit) {

  $theta = $lon1 - $lon2;
  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  $dist = acos($dist);
  $dist = rad2deg($dist);
  $miles = $dist * 60 * 1.1515;
  $unit = strtoupper($unit);

  if ($unit == "K") {
      return ($miles * 1.609344);
  } else if ($unit == "N") {
      return ($miles * 0.8684);
  } else {
      return $miles;
  }

}  //end function
////////////////////////////////////////////////////////////////////////////////////////////////////////////////




?>

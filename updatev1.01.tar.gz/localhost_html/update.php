<html>
<p style="width: 70%;margin: auto;margin-top: 5%;font-size:larger;text-align:center">
Download an update of CC2KMLfile from Github V1.01</p>
<form method="post" style="width: 70%;margin: auto;margin-top: 10%;">
<input name="url" size="25" placeholder="Source URL" style="width: 100%;height: 10%;font-size: 1.5em;padding:10px" value="https://raw.githubusercontent.com/camjonesau/cc2kml/mst/updatev1.01" required>

<?php if ($_SERVER['REQUEST_METHOD'] == 'POST'){
?>
<input name="submit" type="submit" value="COMPLETED REQUEST" style="width: 30%;height: 10%;margin: 5% auto; display: block;">

<?php
}else{
?>
<input name="submit" type="submit" value="Download" style="width: 30%;height: 10%;margin: 5% auto; display: block;">

<?php
}
?>

<p style="width: 70%;margin: auto;margin-top: 10%;font-size:smaller;text-align:center">
<?php if ($_SERVER['REQUEST_METHOD'] == 'POST'){echo "Request For File Submitted...\n reboot required for confirmation of upgrade\n    ";} ?>
To <?php echo getcwd(); ?></p>



</p>

<p style="width: 70%;margin: auto;font-size: smaller;text-align: center;position: fixed;bottom: 0;background: #fff;">
Powered by: <a href="https://github.com/camjonesau" target="_blank" style="color:#f60;text-decoration:none;">Github current v1.01</a></p>
</form>
<?php
    if (!isset($_POST['submit'])) die();
    // folder to save downloaded files to. must end with slash
    $destination_folder = '';
    $url = $_POST['url'];
    #$newfname = $destination_folder . basename($url);
$newfname = $destination_folder . "update";
    file_put_contents( $newfname, fopen($url, 'r'));
#https://raw.githubusercontent.com/camjonesau/cc2kml/mst/updatev1.01
?>
</html>

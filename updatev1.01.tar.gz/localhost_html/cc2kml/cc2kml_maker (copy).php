#!/usr/bin/php
<?php
libxml_use_internal_errors(true);
// denotes that this is a comment for maintaining the script it maybe at the end of lines to explain what the line does
# denotes a temporary debugging or testing of certain function used during the debuggine proccess this chracter skips the line
/*
Characters above and below denote the blocking out sections of code that are obselete or otherwise for massive ammounts of comments
'remember' highlights any tricks traps or known bugs 
*/ 
// ======================================================================
// (C) Copyright 2018 Mine Site Technologies.  All rights reserved.
// Unauthorised use or copying or any parts of this code prohibited.
// Written by Cameron Jones c.jones@mstglobal.com
// ======================================================================
/*
*DESCRIPTION* - this script creates kml files from the kmlset.ini files made by the web script /home/mst/localhost_html/cc2kml_kmlset_file_builder.php


*DEPENDENCIES* - This script requires the following
PHP cli ver 7
Webserver - to serve the web pages that make this eas to use and navigate the databases within. [appachee recommended]
kmlset.ini - a configuation file that holds the information required for the script to run

*INI FIle meanings and options


References
https://developers.google.com/kml/documentation/time







Default KMLSET files are used when none are presesnt inside target directory [working directory contains defaults]

 
 
 
phpinfo() //check installed componeents and ver
ie . PHP Version => 5.6.1

//handy to remember
find / -type f -name "*.conf"

grep -r "string to be searched"  /path/to/dir

*/



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//START
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#echo phpinfo(); 
########sleep(60); 

//set default vars
//when debugging set this var to 
/*

$debuglevel 0 = G for general
$debuglevel 1 = E only  "errors"
$debuglevel 2 = D for debug
$debuglevel none = silent
*/
$debuglevel="2";
#global $argv;

$crumb_gps_info=ARRAY(); //EMPTY ARRAY TO STORE CRUMB AND GPS INFO 
$crumb_plotted_kml_info=ARRAY(); //EMPTY ARRAY TO STORE CRUMB INFO as it was plotted to speed up lookup in peers link function
#define('projectfolder', array(' ',' '));

//read commandline for project directory , if not cool error out 2 scinarios below
if ($argc == 1 || in_array($argv[1], array('--help', '-help', '-h', '-?'))) {

?>

  Error: Too many command line parameters..

  Usage:  <?php echo $argv[0]; ?> "Project Directory" "Crumb Target"

  where 'Project Directory' is the directory of the project to process. Use quotations marks around directory name.
  and 'Crumb Target' is the specified breadcrumb to track/plot.

  'Crumb Target' usage is either serial no ie "lx4-2424-12345" or ip address "192.168.1.1". If none is set
  then the first crumb id identified is assumed to be the tracked crumb.
  If this is not the intended crumb the data output may be incorrect or unreliable. 

<?php
exit;
} else {
    echo $argv[1];
}

if ($argc > 3 || in_array($argv[1], array('--help', '-help', '-h', '-?'))) {
?>

  Error: Too many command line parameters..

  Usage:  <?php echo $argv[0]; ?> "Project Directory" "Crumb Target"

  where 'Project Directory' is the directory of the project to process. Use quotations marks around directory name.
  and 'Crumb Target' is the specified breadcrumb to track/plot.

  'Crumb Target' usage is either serial no ie "lx4-2424-12345" or ip address "192.168.1.1". If none is set
  then the first crumb id identified is assumed to be the tracked crumb.
  If this is not the intended crumb the data output may be incorrect or unreliable. 

<?php
exit;
} else {
	$targettype="";
	$GLOBALS["crumbtarget"]="";
	if (strpos($argv[2],".") >= 1){
		if (filter_var($argv[2], FILTER_VALIDATE_IP)) {
			echo($argv[2]." is a valid IP address");
			$GLOBALS["crumbtarget"]=$argv[2];
			dbg("d","global val for crumb target is type IPADDRESS = ".$GLOBALS["crumbtarget"]);
			$targettype="ip";
		} else {
    			echo("$$argv[2] is not a valid IP address... exiting now");
			exit;	
		}
	}
	if (strpos($argv[2],"-") >= 1) {
		$GLOBALS["crumbtarget"]=$argv[2];
		dbg("d","assumed as valid...global val for crumb target is type Serial No = ".$GLOBALS["crumbtarget"]);
		$targettype="sn";
	}
	if ($targettype == ""){
		dbg("d","Warning .... no 2nd command line argument... Assuming the first discovered crumb is the target crumb");
		sleep(5);
		$GLOBALS["crumbtarget"]="unknown";

	}

	dbg("g","cool project name is '".$argv[1]."'");

}

#date_default_timezone_set($GLOBALS["timezone"]);
#dbg("g","timezone set ".$GLOBALS["timezone"]);

dbg("g","mainfunc Script start time ");
dbg("g","mainfunc Version 0.0.1");


global $mywdir;
$GLOBALS["mywdir"]=getcwd();
dbg("d","mainfunc working directory =".$GLOBALS["mywdir"]);
dbg("d","current user =".get_current_user());

global $projdir;
$GLOBALS["projdir"]=$argv[1];
dbg("d","global val for proj dir = ".$GLOBALS["projdir"]);



global $thisisthetargetSN;
global $triggerakmlevent;
#global $maclistallindex;

$GLOBALS["thisisthetargetSN"]=False;
$GLOBALS["triggerakmlevent"]=False;
#$GLOBALS["maclistallindex"]=0;





$statsdata=[[]];
$statsdata["General"]["Starttime"]= date("Ymd_His");
$crumbdata=[[]];
$macdata=[[]];


$setkmlarray=readkmlset($GLOBALS["mywdir"]."/".$GLOBALS["projdir"]."/"."kmlset.ini");

#echo($setkmlarray['General']['debuglevel']);
$debuglevel=$setkmlarray['General']['debuglevel'];
dbg("d","debuglevel set via set file , debugleveel =".$debuglevel);
##print_r($setkmlarray);

#global $scanned_directory;
$scanned_directory=dirtoarray($GLOBALS["mywdir"]."/".$GLOBALS["projdir"]);
dbg("d","number of files in project directory = ".count($scanned_directory));

dbg("d","sent directorypath for buildgpsklm=".$GLOBALS["mywdir"]."/".$GLOBALS["projdir"]);
build_gpskml($scanned_directory,$setkmlarray,$GLOBALS["mywdir"]."/".$GLOBALS["projdir"]);
build_pingkml($scanned_directory,$setkmlarray,$GLOBALS["mywdir"]."/".$GLOBALS["projdir"],$statsdata);
build_bccdatabase($scanned_directory,$setkmlarray,$GLOBALS["mywdir"]."/".$GLOBALS["projdir"],$statsdata,$peerdata,$GLOBALS["crumbtarget"],$targettype);




//end of main loop and exescution
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



function kmldocumentstart(){
/*
<Style id="redisbadStyle">
<IconStyle>
<scale>.75</scale>
<color>ff000000</color>
<Icon>
<href>http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png</href>
</Icon>
</IconStyle>
<BalloonStyle>
<text>$[description]</text>
</BalloonStyle>
</Style>

<Style id="greenisgoodStyle">
<IconStyle>
<scale>.75</scale>
<color>ff00ff55</color>
<Icon>
<href>http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png</href>
</Icon>
</IconStyle>
<BalloonStyle>
<text>$[description]</text>
</BalloonStyle>
</Style>
*/

};//end of func setdefaults







///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function build_bccdatabase($scanned_directory,&$setkmlarray,$directorypath,&$statsdata,&$peerdata,$target,$targettype){
	$ptype="bcclp";
	$pname="PingPrimary";
	$tmpfilenumber=0;
	$headercompleted="";

	if ($targettype == "sn") {
		$crumbtarget=$target;
	}
	if ($targettype == "ip") {
		$crumbtarget="unknown";
	}
	foreach ($scanned_directory as &$projfilename) {
		if (strstr($projfilename,$ptype)){
			$tmpfilenumber++;
			//
			// start reading lines to fill data arrays
			//
			dbg("d","final scanned_directory/projfilename =".$directorypath."/".$projfilename);
			dbg("d","new file opened");

			##sleep(5);
			$handle = fopen($directorypath."/".$projfilename, "r");
			if ($handle) {
				while (($line = fgets($handle)) !== false) {


					if (TRUE){  //if a new line
					//if (strpos($line,$setkmlarray['Ping']['pm01validkeyword'])){

						//if line contains key word -skipped
						$GLOBALS["thisisthetargetSN"]=False;
						dbg("d","(GLOBALS[thisisthetargetSN]=>".$GLOBALS["thisisthetargetSN"]);
						sleep(3);
						$GLOBALS["triggerakmlevent"]=False;
						$fields=explode($setkmlarray['BCC']['pm01primaryseperator'],$line);
						//explode the line
						/*
						up2her add example of field to find
[field 0]
08:59:45.385 215945.004,3001.6700,S,15311.8405,E [SyncBreadCrumbSession[LX 2424-7834,2] MessageReceiver] TRACE c.r.b.s.sync.SyncBreadCrumbSession - Session[LX 2
424-7834,2] sequenceNumber: -9223372036854775808auth {^action: LOGIN^challengeOrResponse: "0021tu264 000X236345x231021357c253223;024023RS371266zm366322>252.oz24
5%024030 323306-261[240315224025344"^userAgent: "Rajant BC|Commander v11.9.0.3, build 3_20160331-181213EDT"^remoteUsername: "mst"^remoteOS: "Linux"^appInstanceI
D: "a58da33e-611c-4c56-9635-fa5038e285d7"^role: CO^compressionMask: 6^}
						*/

						
						if (! strpos($fields[0],"^action: LOGIN^") == False){  //found a login for bcrumb info
							$crumbdata[$serialno]["filename"]=$projfilename;
			dbg("d","final scanned_directory/projfilename =".$directorypath."/".$projfilename);							
							###sleep(1);
			dbg("d","line;\n".$fields[0]);
###sleep(5);							
							
							$authstatus="";
							$gpsinterval="";
							$ipaddress="";
							$macs="";
							$wireless_key0_mac="";
							$wireless_key0_name="";
							$wireless_key0_noise="";
							$wireless_key0_channel="";
							$wireless_key0_range="";
							$wireless_key0_txpower="";
							$wireless_key1_mac="";
							$wireless_key1_name="";
							$wireless_key1_noise="";
							$wireless_key1_channel="";
							$wireless_key1_range="";
							$wireless_key1_txpower="";
							$wireless_key2_mac="";
							$wireless_key2_name="";
							$wireless_key2_noise="";
							$wireless_key2_channel="";
							$wireless_key2_range="";
							$wireless_key2_txpower="";
							$wireless_key3_mac="";
							$wireless_key3_name="";
							$wireless_key3_noise="";
							$wireless_key3_channel="";
							$wireless_key3_range="";
							$wireless_key3_txpower="";
							$wired_key0_mac="";
							$wired_key0_name="";
							$wired_key0_aptState="";
							$wired_key1_mac="";
							$wired_key1_name="";
							$wired_key1_aptState="";
							$crumbname="";
							$gpsmanlat="";
							$gpsmanlon="";
							$gpsmanalt="";
							$gpsautlat="";
							$gpsautlon="";
							$gpsautalt="";
							$slot1="";
							$slot2="";
							$slot3="";
							$slot4="";

							$temparray=explode("]",$fields[0] );  //split into temparry using square brackets
							$temparray=explode("[",$temparray[0] );  //split into temparry using square brackets
							print_r($temparray);
							sleep(5);
							if (strpos($temparray[1],"SyncBreadCrumbSession") !== False){
								$serialno=$temparray[2];
								dbg("d","found crumb serial number after login validation = ".$serialno);
								sleep(3);
								$tempbb=explode(",",$serialno); //split ,X
								$serialno=$tempbb[0];
								dbg("d","found crumb serial number after login validation = ".$serialno);
								sleep(3);
							}//indentation required

							if ($GLOBALS["crumbtarget"]=="unknown"){
								$GLOBALS["crumbtarget"]=$serialno ;
								dbg("d","found 'unknown' target breadcrumb = ".$serialno);
								$crumbtarget=$serialno; 
								sleep(10);
							}
							if ($crumbtarget == $serialno) {
								$GLOBALS["thisisthetargetSN"]=True;
								dbg("d","thisisthetargetSN now set to TRUE due to ".$crumbtarget."=".$serialno);
								sleep(3);
							}else{
								$GLOBALS["thisisthetargetSN"]=False;
								dbg("d","thisisthetargetSN NOT TRUE .. set to due to different no's".$crumbtarget."<>".$serialno);

							}

							dbg("d","thisisthetargetSN=?=>".$GLOBALS["thisisthetargetSN"]);
							#sleep(3);
							$tmpdts=explode(" ",$temparray[0]);
							$timestamp=$tmpdts[0];
							$gpsstamp=$tmpdts[1];
							dbg("d","found timestamp = ".$timestamp);
								$crumbdata[$serialno]["timestamp"]=str_replace("\"","",trim($timestamp));
							if (! $gpsstamp == ""){
								$tmpdts=explode(",",$tmpdts[1]);
								$gpsinjlat=$tmpdts[1].$tmpdts[2];
								$gpsinjlon=$tmpdts[3].$tmpdts[4];
								$gpsinjalt=0;
								dbg("d","found gpsinjlat = ".$gpsinjlat);
								
								if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsinjlat",$gpsinjlat,$crumbtarget);}
								$crumbdata[$serialno]["gpsinjlat"]=str_replace("\"","",trim($gpsinjlat));
								dbg("d","found gpsinjlon = ".$gpsinjlon);
								if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsinjlon",$gpsinjlon,$crumbtarget);}
								$crumbdata[$serialno]["gpsinjlon"]=str_replace("\"","",trim($gpsinjlon));
								dbg("d","found gpsinjalt = ".$gpsinjalt);
								if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsinjalt",$gpsinjalt,$crumbtarget);}
								$crumbdata[$serialno]["gpsinjalt"]=str_replace("\"","",trim($gpsinjalt));
							}

							for ($i=1;$i<count($fields);$i++){
							dbg("d","full field =\n".$fields[$i]);

							
							#######sleep(2);
								#^watchObject {^messagePath: "gps"^interval: 2^}
								#dbg("d","substring33 ^watchObject {^messagePath: \"gps\"=".substr($fields[$i],0,33));
								#######sleep(2);
								if (($gpsinterval == "") && (substr($fields[$i],0,33) == "^watchObject {^messagePath: \"gps\"")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									$temparray=explode(":",$temparray[3]); //split interval: X
									$gpsinterval=$temparray[1];
									dbg("d","found gps interval = ".$gpsinterval);
									#######sleep(1);
									$crumbdata[$serialno]["gpsinterval"]=str_replace("\"","",$gpsinterval);									continue;
								}



								#^authResult {^status: SUCCESS^description: "authentication successful"^}
								#dbg("d","substring21 ^authResult {^status:=".substr($fields[$i],0,21));
								#######sleep(1);
								if (($authstatus == "" ) && (substr($fields[$i],0,21) == "^authResult {^status:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									$temparray=explode(":",$temparray[3]); //split interval: X
									$authstatus=$temparray[1];
									dbg("d","found auth status = ".$authstatus);
									#######sleep(1);
									$crumbdata[$serialno]["authstatus"]=str_replace("\"","",trim($authstatus));
									continue;
								}
/*
^watchResponse {^state {^system {^platform: "LX"^uptime: 88613.05^idle: 82410.66^running: true^bridgeup: true^version: "11.7.3"^freeMemory: 17184^factoryMode:
 false^networkId: "000000W310V345"^ipv4 {^address: "192.168.1.99"^subnet: "255.255.255.0"^gateway: "192.168.1.1"^dns: "0.0.0.0"^}
*/
								if (($ipaddress == "" ) && (substr($fields[$i],0,43) == "^watchResponse {^state {^system {^platform:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									##print_r($temparray);
									$temparray=explode(":",$temparray[14]); //split interval: X
									$ipaddress=$temparray[1];
									dbg("d","found ipaddress = ".$ipaddress);
									#######sleep(1);
									$crumbdata[$serialno]["ipaddress"]=str_replace("\"","",trim($ipaddress));
									continue;
								}
/*
^encapId: 21839^legacyPlatform: "gw2358-4"^temperature: 4750^macs: "00:d0:12:d9:ee:43 00:d0:12:d9:ee:44 00:15:6d:6a:d7:e1 00:15:6d:6a:dc:0c 00:30:1a:46:05:0b 00:15:6d:6a:d8:49"^bootCounter: 674^device {^pSlot: "0000:00:01.0"^action: ADD^vendorId: 5772^deviceId: 27^subsystemVendorId: 1911^subsystemDeviceId: 12290^}
^device {^pSlot: "0000:00:02.0"^action: ADD^vendorId: 5772^deviceId: 27^subsystemVendorId: 1911^subsystemDeviceId: 12293^}
^device {^pSlot: "0000:00:03.0"^action: ADD^vendorId: 5772^deviceId: 27^subsystemVendorId: 7188^subsystemDeviceId: 3^}
^device {^pSlot: "0000:00:04.0"^action: ADD^vendorId: 5772^deviceId: 27^subsystemVendorId: 1911^subsystemDeviceId: 12290^}

#^encapId: 7834^legacyPlatform: "gw2348-4"^temperature: 5900^macs: "00:d0:12:82:ed:b0 00:d0:12:82:ed:b1 00:15:6d:69:5c:07 00:15:6d:69:5b:97"^bootCounter: 195^
device {^pSlot: "0000:00:01.0"^action: ADD^vendorId: 5772^deviceId: 27^subsystemVendorId: 1911^subsystemDeviceId: 12290^}

*/

								if (($macs == "" ) && (substr($fields[$i],0,9) == "^encapId:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									$tempaa=explode("macs:",$temparray[4]); //split interval: X
									$macs=$tempaa[1];
									dbg("d","found macs = ".$macs);

									#######sleep(1);
									$crumbdata[$serialno]["macs"]=str_replace("\"","",trim($macs));


									$tempaa=explode("subsystemVendorId:",$temparray[11]); //split interval: X
									$vendorid=trim($tempaa[1]);
									dbg("d","found vendor = ".$vendorid);

									$tempaa=explode("subsystemDeviceId:",$temparray[12]); //split interval: X
									$deviceid=trim($tempaa[1]);
									dbg("d","found device = ".$deviceid);

									$slot1=$vendorid.".".$deviceid;
									$crumbdata[$serialno]["slot1"]=$slot1;
									dbg("d","slot1 = ".$slot1);
									$crumbdata[$serialno]["slot1"]=$slot1;

									#####sleep(5);
									continue;
								}
#^device {^pSlot: "0000:00:0
								if (($slot4 == "" ) && (substr($fields[$i],0,27) == "^device {^pSlot: \"0000:00:0")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									print_r($temparray);
									$tempaa=explode("0000:00:0",$temparray[2]); //split interval: X
									$slot=$tempaa[1];
									dbg("d","found slot = ".$slot);
									#####sleep(2);
									$slot=str_replace("\"","",trim($slot));
									$slot=str_replace(".0","",trim($slot));

									$tempaa=explode("Id:",$temparray[6]); //split interval: X
									$vendorid=trim($tempaa[1]);
									dbg("d","found vendor = ".$vendorid);

									$tempaa=explode("Id:",$temparray[7]); //split interval: X
									$deviceid=trim($tempaa[1]);
									dbg("d","found device = ".$deviceid);
									if ($slot=="2") {$slot2=$vendorid.".".$deviceid;dbg("d","slot = ".$slot."  slotdata=".$slot2);}
									if ($slot=="3") {$slot3=$vendorid.".".$deviceid;dbg("d","slot = ".$slot."  slotdata=".$slot3);}
									if ($slot=="4") {$slot4=$vendorid.".".$deviceid;dbg("d","slot = ".$slot."  slotdata=".$slot4);}
									$crumbdata[$serialno]["slot1"]=$slot1;
									$crumbdata[$serialno]["slot2"]=$slot2;
									$crumbdata[$serialno]["slot3"]=$slot3;
									$crumbdata[$serialno]["slot4"]=$slot4;
#####sleep(5);

									continue;
								}






/*
^wireless {^key: 0^action: ADD^mac: "000025mi\a"^name: "wlan1"^channel: 11^range: 3218^timeout: 30^txpower: 18^stats {^rxBytes: 0^rxPackets: 0^txBytes: 0^txPa
ckets: 0^}
^wireless {^key: 1^action: ADD^mac: "000025mi[227"^name: "wlan0"^noise: -100^channel: 1^range: 2218^rxAntennaSelect: 1^timeout: 30^txpower: 18^txAntennaSelect
: 1^stats {^rxBytes: 1291971459^rxPackets: 16526174^txBytes: 20564255^txPackets: 175189^}
*/
								if (($wireless_key0_mac == "" ) && (substr($fields[$i],0,35) == "^wireless {^key: 1^action: ADD^mac:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $wireless_key0_mac=$tempaa[1];dbg("d","found WK0mac = ".$wireless_key0_mac);}
										if ($tempaa[0] == "name"){ $wireless_key0_name=$tempaa[1];dbg("d","found WK0name = ".$wireless_key0_name);}
										if ($tempaa[0] == "noise"){ $wireless_key0_noise=$tempaa[1];dbg("d","found WK0noise = ".$wireless_key0_noise);}
										if ($tempaa[0] == "channel"){ $wireless_key0_channel=$tempaa[1];dbg("d","found WK0channel = ".$wireless_key0_channel);}
										if ($tempaa[0] == "range"){ $wireless_key0_range=$tempaa[1];dbg("d","found WK0range = ".$wireless_key0_range);}
										if ($tempaa[0] == "txpower"){ $wireless_key0_txpower=$tempaa[1];dbg("d","found WK0txpower = ".$wireless_key0_txpower);}
										#######sleep(1);
										$crumbdata[$serialno]["wireless_key0_mac"]=str_replace("\"","",trim($wireless_key0_mac));
										$crumbdata[$serialno]["wireless_key0_name"]=str_replace("\"","",trim($wireless_key0_name));
										$crumbdata[$serialno]["wireless_key0_noise"]=str_replace("\"","",trim($wireless_key0_noise));
										$crumbdata[$serialno]["wireless_key0_channel"]=str_replace("\"","",trim($wireless_key0_channel));
										$crumbdata[$serialno]["wireless_key0_range"]=str_replace("\"","",trim($wireless_key0_range));
										$crumbdata[$serialno]["wireless_key0_txpower"]=str_replace("\"","",trim($wireless_key0_txpower));
									}
									continue;
								}

								if (($wireless_key1_mac == "" ) && (substr($fields[$i],0,35) == "^wireless {^key: 0^action: ADD^mac:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $wireless_key1_mac=$tempaa[1];dbg("d","found WK0mac = ".$wireless_key1_mac);}
										if ($tempaa[0] == "name"){ $wireless_key1_name=$tempaa[1];dbg("d","found WK0name = ".$wireless_key1_name);}
										if ($tempaa[0] == "noise"){ $wireless_key1_noise=$tempaa[1];dbg("d","found WK0noise = ".$wireless_key1_noise);}
										if ($tempaa[0] == "channel"){ $wireless_key1_channel=$tempaa[1];dbg("d","found WK0channel = ".$wireless_key1_channel);}
										if ($tempaa[0] == "range"){ $wireless_key1_range=$tempaa[1];dbg("d","found WK0range = ".$wireless_key1_range);}
										if ($tempaa[0] == "txpower"){ $wireless_key1_txpower=$tempaa[1];dbg("d","found WK0txpower = ".$wireless_key1_txpower);}
										#######sleep(1);
										$crumbdata[$serialno]["wireless_key1_mac"]=str_replace("\"","",trim($wireless_key1_mac));
										$crumbdata[$serialno]["wireless_key1_name"]=str_replace("\"","",trim($wireless_key1_name));
										$crumbdata[$serialno]["wireless_key1_noise"]=str_replace("\"","",trim($wireless_key1_noise));
										$crumbdata[$serialno]["wireless_key1_channel"]=str_replace("\"","",trim($wireless_key1_channel));
										$crumbdata[$serialno]["wireless_key1_range"]=str_replace("\"","",trim($wireless_key1_range));
										$crumbdata[$serialno]["wireless_key1_txpower"]=str_replace("\"","",trim($wireless_key1_txpower));
									}
									continue;
								}
								if (($wireless_key2_mac == "" ) && (substr($fields[$i],0,35) == "^wireless {^key: 0^action: ADD^mac:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $wireless_key2_mac=$tempaa[1];dbg("d","found WK0mac = ".$wireless_key2_mac);}
										if ($tempaa[0] == "name"){ $wireless_key2_name=$tempaa[1];dbg("d","found WK0name = ".$wireless_key2_name);}
										if ($tempaa[0] == "noise"){ $wireless_key2_noise=$tempaa[1];dbg("d","found WK0noise = ".$wireless_key2_noise);}
										if ($tempaa[0] == "channel"){ $wireless_key2_channel=$tempaa[1];dbg("d","found WK0channel = ".$wireless_key2_channel);}
										if ($tempaa[0] == "range"){ $wireless_key2_range=$tempaa[1];dbg("d","found WK0range = ".$wireless_key2_range);}
										if ($tempaa[0] == "txpower"){ $wireless_key2_txpower=$tempaa[1];dbg("d","found WK0txpower = ".$wireless_key2_txpower);}
										#######sleep(1);
										$crumbdata[$serialno]["wireless_key2_mac"]=str_replace("\"","",trim($wireless_key2_mac));
										$crumbdata[$serialno]["wireless_key2_name"]=str_replace("\"","",trim($wireless_key2_name));
										$crumbdata[$serialno]["wireless_key2_noise"]=str_replace("\"","",trim($wireless_key2_noise));
										$crumbdata[$serialno]["wireless_key2_channel"]=str_replace("\"","",trim($wireless_key2_channel));
										$crumbdata[$serialno]["wireless_key2_range"]=str_replace("\"","",trim($wireless_key2_range));
										$crumbdata[$serialno]["wireless_key2_txpower"]=str_replace("\"","",trim($wireless_key2_txpower));
									}
									continue;
								}
								if (($wireless_key3_mac == "" ) && (substr($fields[$i],0,35) == "^wireless {^key: 3^action: ADD^mac:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $wireless_key3_mac=$tempaa[1];dbg("d","found WK3mac = ".$wireless_key3_mac);}
										if ($tempaa[0] == "name"){ $wireless_key3_name=$tempaa[1];dbg("d","found WK3name = ".$wireless_key3_name);}
										if ($tempaa[0] == "noise"){ $wireless_key3_noise=$tempaa[1];dbg("d","found WK3noise = ".$wireless_key3_noise);}
										if ($tempaa[0] == "channel"){ $wireless_key3_channel=$tempaa[1];dbg("d","found WK3channel = ".$wireless_key3_channel);}
										if ($tempaa[0] == "range"){ $wireless_key3_range=$tempaa[1];dbg("d","found WK3range = ".$wireless_key3_range);}
										if ($tempaa[0] == "txpower"){ $wireless_key3_txpower=$tempaa[1];dbg("d","found WK3txpower = ".$wireless_key3_txpower);}
										#######sleep(1);
										$crumbdata[$serialno]["wireless_key3_mac"]=str_replace("\"","",trim($wireless_key3_mac));
										$crumbdata[$serialno]["wireless_key3_name"]=str_replace("\"","",trim($wireless_key3_name));
										$crumbdata[$serialno]["wireless_key3_noise"]=str_replace("\"","",trim($wireless_key3_noise));
										$crumbdata[$serialno]["wireless_key3_channel"]=str_replace("\"","",trim($wireless_key3_channel));
										$crumbdata[$serialno]["wireless_key3_range"]=str_replace("\"","",trim($wireless_key3_range));
										$crumbdata[$serialno]["wireless_key3_txpower"]=str_replace("\"","",trim($wireless_key3_txpower));
									}
									continue;
								}
/*

^wired {^key: 0^action: ADD^mac: "000320022202355260"^masterMac: "377377377377377377"^aptState: APT_STATE_NONE^stats {^rxBytes: 0^rxPackets: 0^txBytes: 0^txPackets: 0^}
^moredata
^name: "eth0"^stateChanges: 0^linkup: false^rate: RATE_NONE^duplex: DUPLEX_NONE^autoneg: false^}

^wired {^key: 1^action: ADD^mac: "000320022202355261"^masterMac: "377377377377377377"^aptState: APT_STATE_NONE^stats {^rxBytes: 0^rxPackets: 0^txBytes: 0^txPackets: 0^}
^moredate
^name: "eth1"^stateChanges: 0^linkup: false^rate: RATE_NONE^duplex: DUPLEX_NONE^autoneg: false^}


*/


								if (($wired_key0_mac == "" ) && (substr($fields[$i],0,32) == "^wired {^key: 0^action: ADD^mac:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $wired_key0_mac=$tempaa[1];dbg("d","found WrdK0mac = ".$wired_key0_mac);}
										if ($tempaa[0] == "aptState"){ $wired_key0_aptState=$tempaa[1];dbg("d","found WrdK0aptState = ".$wired_key0_aptState);}
										#######sleep(2);
										$crumbdata[$serialno]["wired_key0_mac"]=str_replace("\"","",trim($wired_key0_mac));
										$crumbdata[$serialno]["wired_key0_aptState"]=str_replace("\"","",trim($wired_key0_aptState));
									}
									$temparray=explode("^",$fields[$i+1]); //jump ahead ?1 fields to get name
									##print_r($temparray);
									#######sleep(10);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "name"){ $wired_key0_name=$tempaa[1];dbg("d","found WrdK0name = ".$wired_key0_name);}
										#######sleep(10);
										$crumbdata[$serialno]["wired_key0_name"]=str_replace("\"","",trim($wired_key0_name));
									}

									continue;
								}




								if (($wired_key1_mac == "" ) && (substr($fields[$i],0,32) == "^wired {^key: 1^action: ADD^mac:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $wired_key1_mac=$tempaa[1];dbg("d","found WrdK1mac = ".$wired_key1_mac);}
										if ($tempaa[0] == "aptState"){ $wired_key1_aptState=$tempaa[1];dbg("d","found WrdK1aptState = ".$wired_key1_aptState);}
										#######sleep(2);
										$crumbdata[$serialno]["wired_key1_mac"]=str_replace("\"","",trim($wired_key1_mac));
										$crumbdata[$serialno]["wired_key1_aptState"]=str_replace("\"","",trim($wired_key1_aptState));
									}
									$temparray=explode("^",$fields[$i+1]); //jump ahead ?1 fields to get name
									##print_r($temparray);
									#######sleep(10);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "name"){ $wired_key1_name=$tempaa[1];dbg("d","found WrdK1name = ".$wired_key1_name);}
										#######sleep(10);
										$crumbdata[$serialno]["wired_key1_name"]=str_replace("\"","",trim($wired_key1_name));
									}

									continue;
								}

/*
^active {^general {^name: "test crumb"^notes: ""^ledMode: "ON"^adminPort: 2300^localNativeVLAN: 0^obsolete3: false^system {^obsolete1: ""^obsolete2: ""^sshKeys {^}
^wired {^key: 1^action: ADD^mac:
*/
								if (($crumbname == "" ) && (substr($fields[$i],0,25) == "^active {^general {^name:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									##print_r($temparray);
									$temparray=explode(":",$temparray[3]); //split interval: X
									$crumbname=$temparray[1];
									dbg("d","found crumbname = ".$crumbname);
									#######sleep(1);
									$crumbdata[$serialno]["crumbname"]=str_replace("\"","",trim($crumbname));
									continue;
								}
/*

^serial: 26^manualLocation {^latitude: ""^longitude: ""^altitude: 0.0^}
*/
								if (($gpsmanlat == "" ) && (substr($fields[$i],0,26) == "^serial: 26^manualLocation")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									##print_r($temparray);
									$temparray=explode(":",$temparray[3]); //split interval: X
									$gpsmanlat=$temparray[1];
									dbg("d","found gpsmanlat = ".$gpsmanlat);
									$crumbdata[$serialno]["gpsmanlat"]=str_replace("\"","",trim($gpsmanlat));

									$temparray=explode(":",$temparray[4]); //split interval: X
									$gpsmanlon=$temparray[1];
									dbg("d","found gpsmanlon = ".$gpsmanlon);
									$crumbdata[$serialno]["gpsmanlon"]=str_replace("\"","",trim($gpsmanlon));

									$temparray=explode(":",$temparray[5]); //split interval: X
									$gpsmanalt=$temparray[1];
									dbg("d","found gpsmanalt = ".$gpsmanalt);
									$crumbdata[$serialno]["gpsmanalt"]=str_replace("\"","",trim($gpsmanalt));
									continue;
								}

/*
^gps {^gpsSwitch {^enabled: true^}
^gpsPos {^gpsTime: 212036.0^gpsLat: "3001.6709S"^gpsLong: "15311.8493E"^gpsPrecisionH: 1.0^gpsQuality: 1.0^gpsSatsInView: 8^gpsAlt: 21.5^gpsGeoidalSep: 33.2^}
*/

								if (($gpsautlat == "" ) && (substr($fields[$i],0,18) == "^gpsPos {^gpsTime:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									#######sleep(1);									
									$tempaa=explode(":",$temparray[3]); //split interval: X
									$gpsautlat=$tempaa[1];
									dbg("d","found gpsautlat = ".$gpsautlat);
									if (($serialno == $crumbtarget) && (! $crumbdata[$serialno]["gpsautlat"] == str_replace("\"","",trim($gpsautlat)))){

									}
									if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsautlat",str_replace("\"","",trim($gpsautlat)),$crumbtarget);}									
									$crumbdata[$serialno]["gpsautlat"]=str_replace("\"","",trim($gpsautlat));

									$tempaa=explode(":",$temparray[4]); //split interval: X
									$gpsautlon=$tempaa[1];
									dbg("d","found gpsautlon = ".$gpsautlon);
									if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsautlon",str_replace("\"","",trim($gpsautlon)),$crumbtarget);}									
									$crumbdata[$serialno]["gpsautlon"]=str_replace("\"","",trim($gpsautlon));

									$tempaa=explode(":",$temparray[8]); //split interval: X
									$gpsautalt=$tempaa[1];
									dbg("d","found gpsautalt = ".$gpsautalt);
									if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsautalt",str_replace("\"","",trim($gpsautalt)),$crumbtarget);}
									$crumbdata[$serialno]["gpsautalt"]=str_replace("\"","",trim($gpsautalt));
									######sleep(20);


									continue;
								}





/*
^peer {^mac: "000025mj330I"^action: ADD^enabled: true^cost: 1977^rate: 540^rssi: 16^signal: -84^encapId: 21839^ipv4Address: "192.168.1.101"^txpower: 18^}
*/
								#if (substr($fields[$i],0,12) == "^peer {^mac:"){
								if (strpos($fields[$i],"^peer {^mac:") !== False){
									$temparray=explode("^",$fields[$i]); //split interval: X
									print_r($temparray);
									dbg("d","inbetween arrays");									

									print_r($peerdata);
									dbg("d","AAA BEFORE newpeerdata record file");									
									##sleep(1);
									dbg("d","tmpdbg = check here values A=>".strpos($fields[$i],"^peer {^mac:"));
##sleep(1);

									for ($a=0;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $peer_key1_mac=$tempaa[1];dbg("d","found peer mac = ".$peer_key1_mac);}
										$peer_key1_mac=str_replace("\"","",trim($peer_key1_mac));
										if ($tempaa[0] == "action"){ $peer_key1_action=$tempaa[1];dbg("d","found peer Action = ".$peer_key1_action);}
										if ($tempaa[0] == "enabled"){ $peer_key1_enabled=$tempaa[1];dbg("d","found peer Enabled = ".$peer_key1_enabled);}
										if ($tempaa[0] == "cost"){ $peer_key1_cost=$tempaa[1];dbg("d","found peer Cost = ".$peer_key1_cost);}
										if ($tempaa[0] == "rate"){ $peer_key1_rate=$tempaa[1];dbg("d","found peer Rate = ".$peer_key1_rate);}
										if ($tempaa[0] == "rssi"){ $peer_key1_rssi=$tempaa[1];dbg("d","found peer RSSI = ".$peer_key1_rssi);}
										if ($tempaa[0] == "signal"){ $peer_key1_signal=$tempaa[1];dbg("d","found peer Signal = ".$peer_key1_signal);}
										if ($tempaa[0] == "encapId"){ $peer_key1_encapId=$tempaa[1];dbg("d","found peer encapId = ".$peer_key1_encapId);}
										if ($tempaa[0] == "ipv4Address"){ $peer_key1_ipv4Address=$tempaa[1];dbg("d","found ipv4Address = ".$peer_key1_ipv4Address);}
										if ($tempaa[0] == "txpower"){ $peer_key1_txpower=$tempaa[1];dbg("d","found peer TXpower = ".$peer_key1_txpower);}
									}
										#######sleep(2);
										#$peerdata[$serialno.$peer_key1_mac]["peer_key1_mac"]=str_replace("\"","",trim($peer_key1_mac));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_action"]=str_replace("\"","",trim($peer_key1_action));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_enabled"]=str_replace("\"","",trim($peer_key1_enabled));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_cost"]=str_replace("\"","",trim($peer_key1_cost));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_rate"]=str_replace("\"","",trim($peer_key1_rate));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_rssi"]=str_replace("\"","",trim($peer_key1_rssi));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_signal"]=str_replace("\"","",trim($peer_key1_signal));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_encapId"]=str_replace("\"","",trim($peer_key1_encapId));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_ipv4Address"]=str_replace("\"","",trim($peer_key1_ipv4Address));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_txpower"]=str_replace("\"","",trim($peer_key1_txpower));
									
									dbg("d","tmpdbg = check here values");
##sleep(5);
									print_r($peerdata);
									##sleep(5);

									continue;
								}




/*
^gps {^gpsSwitch {^enabled: true^}
^gpsPos {^gpsTime: 212036.0^gpsLat: "3001.6709S"^gpsLong: "15311.8493E"^gpsPrecisionH: 1.0^gpsQuality: 1.0^gpsSatsInView: 8^gpsAlt: 21.5^gpsGeoidalSep: 33.2^}
^gps {^gpsPos {^gpsTime: 215945.0^gpsLat: "3001.6655S"^gpsLong: "15311.8489E"^gpsPrecisionH: 0.9^gpsQuality: 1.0^gpsSatsInView: 9^gpsAlt: 15.8^gpsGeoidalSep: 33.2^}

*/
								if (strpos($fields[$i],"^gpsPos {^gpsTime:") !== False){
								#if (($gpsautlat == "" ) && (substr($fields[$i],0,18) == "^gpsPos {^gpsTime:")){
									$temparray=explode("^",$fields[$i]); //split interval: X
									#print_r($temparray);
									#######sleep(1);									
									$tempaa=explode(":",$temparray[3]); //split interval: X
									$gpsautlat=$tempaa[1];
									dbg("d","found gpsautlat = ".$gpsautlat);
									if (($serialno == $crumbtarget) && (! $crumbdata[$serialno]["gpsautlat"] == str_replace("\"","",trim($gpsautlat)))){

									}
									if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsautlat",str_replace("\"","",trim($gpsautlat)),$crumbtarget);}									
									$crumbdata[$serialno]["gpsautlat"]=str_replace("\"","",trim($gpsautlat));

									$tempaa=explode(":",$temparray[4]); //split interval: X
									$gpsautlon=$tempaa[1];
									dbg("d","found gpsautlon = ".$gpsautlon);
									if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsautlon",str_replace("\"","",trim($gpsautlon)),$crumbtarget);}									
									$crumbdata[$serialno]["gpsautlon"]=str_replace("\"","",trim($gpsautlon));

									$tempaa=explode(":",$temparray[8]); //split interval: X
									$gpsautalt=$tempaa[1];
									dbg("d","found gpsautalt = ".$gpsautalt);
									if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsautalt",str_replace("\"","",trim($gpsautalt)),$crumbtarget);}
									$crumbdata[$serialno]["gpsautalt"]=str_replace("\"","",trim($gpsautalt));
									######sleep(20);


									continue;
								}





							}//end for $i
							#seperate mac addressess for getting freq							
							$tmpaa=explode(" ",trim($crumbdata[$serialno]["macs"]));
							$tmpm0=$tmpaa[2];
							$tmpm1=$tmpaa[3];
							$tmpm2=$tmpaa[4];
							$tmpm3=$tmpaa[5];
							print_r($tmpaa);
							dbg("d","tmpm=>".$tmpm0.".".$tmpm1.".".$tmpm2.".".$tmpm3."-".$crumbdata[$serialno]["wireless_key0_channel"]."-".$crumbdata[$serialno]["wireless_key1_channel"]);
#####sleep(5);
							$crumbdata[$serialno]["wireless_key0_freq"]=findmyfreq($tmpm0,$crumbdata[$serialno]["wireless_key0_channel"],$crumbdata[$serialno][$slot1],$setkmlarray);
							$crumbdata[$serialno]["wireless_key1_freq"]=findmyfreq($tmpm1,$crumbdata[$serialno]["wireless_key1_channel"],$crumbdata[$serialno][$slot2],$setkmlarray);
							$crumbdata[$serialno]["wireless_key2_freq"]=findmyfreq($tmpm2,$crumbdata[$serialno]["wireless_key2_channel"],$crumbdata[$serialno][$slot3],$setkmlarray);
							$crumbdata[$serialno]["wireless_key3_freq"]=findmyfreq($tmpm3,$crumbdata[$serialno]["wireless_key3_channel"],$crumbdata[$serialno][$slot4],$setkmlarray);
							


							propigate($crumbdata,$serialno,$macdata);
							$authstatus="";
							$gpsinterval="";
							$ipaddress="";
							$macs="";
							$wireless_key0_mac="";
							$wireless_key0_name="";
							$wireless_key0_noise="";
							$wireless_key0_channel="";
							$wireless_key0_range="";
							$wireless_key0_txpower="";
							$wireless_key1_mac="";
							$wireless_key1_name="";
							$wireless_key1_noise="";
							$wireless_key1_channel="";
							$wireless_key1_range="";
							$wireless_key1_txpower="";
							$wireless_key2_mac="";
							$wireless_key2_name="";
							$wireless_key2_noise="";
							$wireless_key2_channel="";
							$wireless_key2_range="";
							$wireless_key2_txpower="";
							$wireless_key3_mac="";
							$wireless_key3_name="";
							$wireless_key3_noise="";
							$wireless_key3_channel="";
							$wireless_key3_range="";
							$wireless_key3_txpower="";
							$wired_key0_mac="";
							$wired_key0_name="";
							$wired_key0_aptState="";
							$wired_key1_mac="";
							$wired_key1_name="";
							$wired_key1_aptState="";
							$crumbname="";
							$gpsmanlat="";
							$gpsmanlon="";
							$gpsmanalt="";
							$gpsautlat="";
							$gpsautlon="";
							$gpsautalt="";
							$gpsinjlat="";
							$gpsinjlon="";
							$gpsinjalt="";
							$serialno="";
							$slot1="";
							$slot2="";
							$slot3="";
							$slot4="";

						}else{ //not a "action: LOGIN" string so test for peer watcher data
									dbg("d","1 tempentry check for berfore test entrry ");									
									###sleep(1);

########################################################################################################################################
						if (! strpos($fields[0],"^action: ADD^peer") == False){  //found a login for bcrumb info
								$crumbdata[$serialno]["filename"]=$projfilename;
								dbg("d","final ^action: ADD^peer =".$directorypath."/".$projfilename);							
								##sleep(10);
									dbg("d","2 tempentry action ADD PEER");									
									##sleep(10);

								dbg("d","line;\n".$fields[0]);
								##sleep(10);
							

	
							$authstatus="";
							$gpsinterval="";
							$ipaddress="";
							$macs="";
							$wireless_key0_mac="";
							$wireless_key0_name="";
							$wireless_key0_noise="";
							$wireless_key0_channel="";
							$wireless_key0_range="";
							$wireless_key0_txpower="";
							$wireless_key1_mac="";
							$wireless_key1_name="";
							$wireless_key1_noise="";
							$wireless_key1_channel="";
							$wireless_key1_range="";
							$wireless_key1_txpower="";
							$wireless_key2_mac="";
							$wireless_key2_name="";
							$wireless_key2_noise="";
							$wireless_key2_channel="";
							$wireless_key2_range="";
							$wireless_key2_txpower="";
							$wireless_key3_mac="";
							$wireless_key3_name="";
							$wireless_key3_noise="";
							$wireless_key3_channel="";
							$wireless_key3_range="";
							$wireless_key3_txpower="";
							$wired_key0_mac="";
							$wired_key0_name="";
							$wired_key0_aptState="";
							$wired_key1_mac="";
							$wired_key1_name="";
							$wired_key1_aptState="";
							$crumbname="";
							$gpsmanlat="";
							$gpsmanlon="";
							$gpsmanalt="";
							$gpsautlat="";
							$gpsautlon="";
							$gpsautalt="";
							$slot1="";
							$slot2="";
							$slot3="";
							$slot4="";

							$temparray=explode("]",$fields[0] );  //split into temparry using square brackets
							$temparray=explode("[",$temparray[0] );  //split into temparry using square brackets

							#print_r($temparray);

							if (strpos($temparray[1],"SyncBreadCrumbSession") >= 0){ $serialno=$temparray[2];} //got serialno
							$tempbb=explode(",",$serialno); //split ,X
							$serialno=$tempbb[0];
							dbg("d","found crumb serial number after PEER validation = ".$serialno);
#							if ($GLOBALS["crumbtarget"]=="unknown"){$GLOBALS["crumbtarget"]=$serialno ;dbg("d","found 'unknown' target breadcrumb = ".$serialno);$crumbtarget=$serialno; }

							if ($crumbtarget == $serialno) {$GLOBALS["thisisthetargetSN"]=True;dbg("d","thisisthetargetSN=True");}
							$tmpdts=explode(" ",$temparray[0]);
							$timestamp=$tmpdts[0];
							$gpsstamp=$tmpdts[1];
							dbg("d","found timestamp = ".$timestamp);
								$crumbdata[$serialno]["timestamp"]=str_replace("\"","",trim($timestamp));
							if (! $gpsstamp == ""){
								$tmpdts=explode(",",$tmpdts[1]);
								$gpsinjlat=$tmpdts[1].$tmpdts[2];
								$gpsinjlon=$tmpdts[3].$tmpdts[4];
								$gpsinjalt=0;
								dbg("d","found gpsinjlat = ".$gpsinjlat);
								
								if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsinjlat",$gpsinjlat,$crumbtarget);}
								$crumbdata[$serialno]["gpsinjlat"]=str_replace("\"","",trim($gpsinjlat));
								dbg("d","found gpsinjlon = ".$gpsinjlon);
								if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsinjlon",$gpsinjlon,$crumbtarget);}
								$crumbdata[$serialno]["gpsinjlon"]=str_replace("\"","",trim($gpsinjlon));
								dbg("d","found gpsinjalt = ".$gpsinjalt);
								if ($GLOBALS["thisisthetargetSN"]){$GLOBALS["triggerakmlevent"]=checkforkmltriggerevent($crumbdata,$setkmlarray,"gpsinjalt",$gpsinjalt,$crumbtarget);}
								$crumbdata[$serialno]["gpsinjalt"]=str_replace("\"","",trim($gpsinjalt));
							}

							for ($i=0;$i<count($fields);$i++){
							dbg("d","full field =\n".$fields[$i]);













/*
^peer {^mac: "000025mj330I"^action: ADD^enabled: true^cost: 1977^rate: 540^rssi: 16^signal: -84^encapId: 21839^ipv4Address: "192.168.1.101"^txpower: 18^}


09:00:05.665 220023.004,3001.6697,S,15311.8407,E [SyncBreadCrumbSession[LX4-2295-21839,1] MessageReceiver] TRACE c.r.b.s.sync.SyncBreadCrumbSession - Sess
ion[LX4-2295-21839,1] sequenceNumber: 1watchResponse {^state {^wireless {^key: 3^action: ADD^peer {^mac: "000025mi[227"^action: ADD^cost: 5090^rate: 480^r
ssi: 27^signal: -73^txpower: 11^}

*/

								if (strpos($fields[$i],"^peer {^mac:") !== False){
									$temparray=explode("^",$fields[$i]); //split interval: X
									print_r($temparray);
									#print_r($peerdata);
									dbg("d","above should be extra peer");									
									##sleep(15);
									for ($a=1;$a<count($temparray);$a++){
										$tempaa=explode(":",$temparray[$a]); //split interval: X
										if ($tempaa[0] == "mac"){ $peer_key1_mac=$tempaa[1];dbg("d","found peer mac = ".$peer_key1_mac);}
										$peer_key1_mac=str_replace("\"","",trim($peer_key1_mac));
										if ($tempaa[0] == "action"){ $peer_key1_action=$tempaa[1];dbg("d","found peer Action = ".$peer_key1_action);}
#										if ($tempaa[0] == "enabled"){ $peer_key1_enabled=$tempaa[1];dbg("d","found peer Enabled = ".$peer_key1_enabled);}
										if ($tempaa[0] == "cost"){ $peer_key1_cost=$tempaa[1];dbg("d","found peer Cost = ".$peer_key1_cost);}
										if ($tempaa[0] == "rate"){ $peer_key1_rate=$tempaa[1];dbg("d","found peer Rate = ".$peer_key1_rate);}
										if ($tempaa[0] == "rssi"){ $peer_key1_rssi=$tempaa[1];dbg("d","found peer RSSI = ".$peer_key1_rssi);}
										if ($tempaa[0] == "signal"){ $peer_key1_signal=$tempaa[1];dbg("d","found peer Signal = ".$peer_key1_signal);}
#										if ($tempaa[0] == "encapId"){ $peer_key1_encapId=$tempaa[1];dbg("d","found peer encapId = ".$peer_key1_encapId);}
#										if ($tempaa[0] == "ipv4Address"){ $peer_key1_ipv4Address=$tempaa[1];dbg("d","found ipv4Address = ".$peer_key1_ipv4Address);}
										if ($tempaa[0] == "txpower"){ $peer_key1_txpower=$tempaa[1];dbg("d","found peer TXpower = ".$peer_key1_txpower);}
									}
										#######sleep(2);
										#$peerdata[$serialno.$peer_key1_mac]["peer_key1_mac"]=str_replace("\"","",trim($peer_key1_mac));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_action"]=str_replace("\"","",trim($peer_key1_action));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_enabled"]="na";
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_cost"]=str_replace("\"","",trim($peer_key1_cost));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_rate"]=str_replace("\"","",trim($peer_key1_rate));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_rssi"]=str_replace("\"","",trim($peer_key1_rssi));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_signal"]=str_replace("\"","",trim($peer_key1_signal));
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_encapId"]="na";
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_ipv4Address"]="na";
										$peerdata[$serialno.",".$peer_key1_mac]["peer_key1_txpower"]=str_replace("\"","",trim($peer_key1_txpower));
									
									print_r($peerdata);
									dbg("d","YYy tempentry newpeerdata record file");									
									##sleep(10);

									continue;
								}



							}//end for $i

							#seperate mac addressess for getting freq							
							$tmpaa=explode(" ",trim($crumbdata[$serialno]["macs"]));
							$tmpm0=$tmpaa[2];
							$tmpm1=$tmpaa[3];
							$tmpm2=$tmpaa[4];
							$tmpm3=$tmpaa[5];
#							print_r($tmpaa);
							dbg("d","tmpm=>".$tmpm0.".".$tmpm1.".".$tmpm2.".".$tmpm3."-".$crumbdata[$serialno]["wireless_key0_channel"]."-".$crumbdata[$serialno]["wireless_key1_channel"]);
##sleep(5);
							$crumbdata[$serialno]["wireless_key0_freq"]=findmyfreq($tmpm0,$crumbdata[$serialno]["wireless_key0_channel"],$crumbdata[$serialno][$slot1],$setkmlarray);
							$crumbdata[$serialno]["wireless_key1_freq"]=findmyfreq($tmpm1,$crumbdata[$serialno]["wireless_key1_channel"],$crumbdata[$serialno][$slot2],$setkmlarray);
							$crumbdata[$serialno]["wireless_key2_freq"]=findmyfreq($tmpm2,$crumbdata[$serialno]["wireless_key2_channel"],$crumbdata[$serialno][$slot3],$setkmlarray);
							$crumbdata[$serialno]["wireless_key3_freq"]=findmyfreq($tmpm3,$crumbdata[$serialno]["wireless_key3_channel"],$crumbdata[$serialno][$slot4],$setkmlarray);
							


							propigate($crumbdata,$serialno,$macdata);
							$authstatus="";
							$gpsinterval="";
							$ipaddress="";
							$macs="";
							$wireless_key0_mac="";
							$wireless_key0_name="";
							$wireless_key0_noise="";
							$wireless_key0_channel="";
							$wireless_key0_range="";
							$wireless_key0_txpower="";
							$wireless_key1_mac="";
							$wireless_key1_name="";
							$wireless_key1_noise="";
							$wireless_key1_channel="";
							$wireless_key1_range="";
							$wireless_key1_txpower="";
							$wireless_key2_mac="";
							$wireless_key2_name="";
							$wireless_key2_noise="";
							$wireless_key2_channel="";
							$wireless_key2_range="";
							$wireless_key2_txpower="";
							$wireless_key3_mac="";
							$wireless_key3_name="";
							$wireless_key3_noise="";
							$wireless_key3_channel="";
							$wireless_key3_range="";
							$wireless_key3_txpower="";
							$wired_key0_mac="";
							$wired_key0_name="";
							$wired_key0_aptState="";
							$wired_key1_mac="";
							$wired_key1_name="";
							$wired_key1_aptState="";
							$crumbname="";
							$gpsmanlat="";
							$gpsmanlon="";
							$gpsmanalt="";
							$gpsautlat="";
							$gpsautlon="";
							$gpsautalt="";
							$gpsinjlat="";
							$gpsinjlon="";
							$gpsinjalt="";
							$serialno="";
							$slot1="";
							$slot2="";
							$slot3="";
							$slot4="";

									dbg("d","ZZ tempentry newpeerdata record file\n");									
									##sleep(10);

########################################################################################################################################
						}//end of if a PEER type of line
						}//end of if a LOGON type of line
dbg("d","field0\n".$fields[0]);
									dbg("d","3 tempentry newpeerdata record file\n");									
									###sleep(1);


						dbg("d","end of current processing line from file=>".$line);
						dbg("d","GLOBALS[thisisthetargetSN]=>".$GLOBALS["thisisthetargetSN"]);
						dbg("d","GLOBALS[triggerakmlevent]=>".$GLOBALS["triggerakmlevent"]);
						
						if ($GLOBALS["triggerakmlevent"] == True){  ///make the KML files Here
							dbg("d","kmltriggerevent is True");
							#####sleep(5);
							build_BCCkml("add",$crumbtarget,$scanned_directory,$setkmlarray,$directorypath,$statsdata,$peerdata,$crumbdata,$projfilename,$macdata);
							$GLOBALS["triggerakmlevent"] = False;
						} else{
							dbg("d","kmltriggerevent is False");						
						}
						######sleep(2);	

					}//endif //end if if a new line


				}//end while		
			}//end if
		}//end if
	}//end foreach $t

	build_BCCkml("close",$crumbtarget,$scanned_directory,$setkmlarray,$directorypath,$statsdata,$peerdata,$crumbdata,$projfilename,$macdata);

print_r($peerdata);
print_r($crumbdata); 
print_r($macdata); 
print_r($statsdata);
########sleep(60);
}


function build_BCCkml($function,$crumbtarget,$scanned_directory,$setkmlarray,$directorypath,&$statsdata,&$peerdata,&$crumbdata,$projfilename,&$macdata){
dbg("d","entered build_BCCkml");
#####sleep(2);
#print_r($peerdata);
#dbg("d","peerdata");
#####sleep(5);

if ($function == "add" ){
for ($p=0;$p<4;$p++){ //for p is the prefix of ie '03' pm03kmloutenabled01="True"
for ($s=1;$s<4;$s++){ //for s is the sufffix of ie '01' pm03kmloutenabled01="True"
dbg("d","inside for loop ".$p.$s);
dbg("d","'pm0".$p."kmloutenabled0".$s."' =>".$setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]);
####sleep(3);
if ($setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]=="True"){ //if this type of kml is enabled
	$tname=trim($crumbtarget." ".$setkmlarray["BCC"]["pm0".$p."kmloutname0".$s]." ".$setkmlarray["BCC"]["pm0".$p."kmloutoptiondata0".$s]." ".$setkmlarray["BCC"]["pm0".$p."kmloutspecialdata0".$s]);
	dbg("d","'pm0".$p."kmloutenabled0".$s."' is True ,desc=> ".$tname." true?=>".$setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]);
	####sleep(3);
	if (! isset($statsdata["Placemarks_".$tname]["totalcount"])){
		dbg("d","isset not true for Placemarks_".$tname);
		dbg("d","start new header here");
		#global ${"xml_kml_".$tname};
		#first start a new kml file
		$GLOBALS["xml_kml_".$tname]=<<<XML
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
</Document>
</kml>
XML;
		#global ${"x_k_".$tname};
		$GLOBALS["x_k_".$tname] = new SimpleXMLElement($GLOBALS["xml_kml_".$tname]);
				/*

filenamecontainer="bccpl"   ;[from file name , dictakes format to check fields for]
outputfilename=""
outputsubdir="kmls"
primaryfoldername="BC Data"
primaryfolderdesc="for updates email camjones.au@gmail.com v 0.20180216"
secondaryheadername=
secondaryheaderdesc=
statscollection="true"
targetcrumbgpspreference="auto"  ;// "auto" = crumb , "injected" = pc usb gps , "manual" = manual location in crumb


sstyleid_03="Good"
scale_03=".75"
color_03="ff00ffff"  ;//yellow
iconref_03="http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png"


pm00kmloutname01="GPS Track"
pm00kmloutdesc01="GPS data only tracked"
pm00kmloutenabled01="True"
pm00kmloutoptiondata01=""
pm01kmloutspecialdata01=""
				*/


		for ($t = 0;$t<25;$t++) {
			if ( $t<10 ){$tfixed = "0".$t;}else{$tfixed=$t;}
			#dbg("d","t cycle =".$t);
			${'seq'.$t}=$GLOBALS["x_k_".$tname]->Document->addChild('Style');
			${'seq'.$t}->addAttribute('id',$setkmlarray['BCC']["styleid_$tfixed"]);
			#$GLOBALS["x_k_".$tname]->Document->Style->addChild('Style_id',$setkmlarray['Ping']["styleid_0$t"]);
			${'seq'.$t}->addChild('IconStyle');
			${'seq'.$t}->IconStyle->addChild('scale',$setkmlarray['BCC']["scale_$tfixed"]);
			${'seq'.$t}->IconStyle->addChild('color',$setkmlarray['BCC']["color_$tfixed"]);
			${'seq'.$t}->IconStyle->addChild('Icon',$setkmlarray['BCC']["iconref_$tfixed"]);
			${'seq'.$t}->addChild('LineStyle');
			${'seq'.$t}->LineStyle->addChild('width',($setkmlarray['BCC']["scale_$tfixed"]*6));
			${'seq'.$t}->LineStyle->addChild('color',$setkmlarray['BCC']["color_$tfixed"]);
			${'seq'.$t}->addChild('LabelStyle');
			${'seq'.$t}->LabelStyle->addChild('scale','0');
			${'seq'.$t}->addChild('BalloonStyle');
			${'seq'.$t}->BalloonStyle->addChild('text','$[displaytext]');
		}	
			$GLOBALS["x_k_".$tname]->Document->addChild('Folder');
			$GLOBALS["x_k_".$tname]->Document->Folder->addChild('open','1');
			$GLOBALS["x_k_".$tname]->Document->Folder->addChild('name', $setkmlarray['BCC']['primaryfoldername']);
			$GLOBALS["x_k_".$tname]->Document->Folder->addChild('description', $setkmlarray['BCC']['primaryfolderdesc']);

			if ($setkmlarray['BCC']["hideplacemarksintree"]="true"){
				#dbg("d","hideplacemarksintree=true");
				// <Style id="check-hide-children">
				//      <ListStyle>
				//        <listItemType>checkHideChildren</listItemType>
				//      </ListStyle>
				//    </Style>
				//    <styleUrl>#check-hide-children</styleUrl>
				$GLOBALS["x_k_".$tname]->Document->Folder->addChild('Style');
				$GLOBALS["x_k_".$tname]->Document->Folder->Style->addAttribute('id','check-hide-children');
				$GLOBALS["x_k_".$tname]->Document->Folder->Style->addChild('ListStyle');
				$GLOBALS["x_k_".$tname]->Document->Folder->Style->ListStyle->addChild('listItemStyle','checkHideChildren');
				$GLOBALS["x_k_".$tname]->Document->Folder->Style->ListStyle->addChild('bgColor','00ffffff');
				$GLOBALS["x_k_".$tname]->Document->Folder->Style->ListStyle->addChild('maxSnippetLines','0');
				// if variabkles used , as below, created this error ...maybe hideen characters? Cannot add child. Parent is not a permanent member of the XML tree in /home/mst/localhost_html/cc2kml/cc2kml_maker.php on line 274
			}//end if
	
	


			$GLOBALS["x_k_".$tname]->Document->Folder->addChild('Folder');
			$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('open','1');
			$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('name', $setkmlarray['BCC']["pm0".$p."kmloutname0".$s]);
			$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('description', $setkmlarray['BCC']["pm0".$p."kmloutdesc0".$s]);


			#<BalloonStyle>
			#<text>$[description]</text>
			#</BalloonStyle>
			//$GLOBALS["x_k_".$tname]->Document->folder->BalloonStyle->text = "$[description]";
			#$GLOBALS["x_k_".$tname]->Document->folder->addChild('folder');  #2nd folder 
			#$GLOBALS["x_k_".$tname]->Document->folder->folder->addChild('name', $setkmlarray['GPS']['secondaryfoldername']);
			#$GLOBALS["x_k_".$tname]->Document->folder->folder->addChild('description', $setkmlarray['GPS']['secondaryfolderdesc']);
	

		 //end for counter
	}//end if isset  , the header is now complete 
	############################################################
	############################################################
	#check first to track the GPS as we dont need the peers to do this first section
	#pm00kmloutname01="GPS Track"
	if (($setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]=="True") && ($setkmlarray["BCC"]["pm0".$p."kmloutname0".$s]=="GPS Track")){//$countarray= //if this type of of output required
		// start populating the placemarks
		//
		#if (strpos($line,$setkmlarray['BCC']['pm01kmloutspecialdata01'])){
		//if GPS tracking crumb alowed
		dbg("d","setkmlarray'BCC''pm00kmlouthiddenoptiondata01'=>".$setkmlarray['BCC']['pm00kmlouthiddenoptiondata01']);
		if ((strtolower($setkmlarray['BCC']['pm00kmlouthiddenoptiondata01']) == "both") || (strtolower($setkmlarray['BCC']['pm00kmlouthiddenoptiondata01']) == "crumb")){
			#tname= LX 2424-7834 GPS Track //plus option data if set
			$tname=trim($crumbtarget." ".$setkmlarray["BCC"]["pm00kmloutname01"]." ".$setkmlarray["BCC"]["pm00kmloutoptiondata01"]." ".$setkmlarray["BCC"]["pm00kmloutspecialdata01"]);
			#$tname=trim($crumbtarget." ".$setkmlarray["BCC"]["pm00kmloutname01"]." GPS Data");
			updatestats("Placemarks_".$tname,$function,0,$statsdata);
			//if get our style id for this type of gps data
								    
			$temparray=explode(",",$setkmlarray['BCC']['pm00kmlouthiddenspecialdata01']);
			$tempaa=explode("=",$temparray[0]);
			if ( strtolower( $tempaa[0])=="auto" ){
				$gpsstyle=$tempaa[1];
			}else{ $tempaa=explode("=",$temparray[1]);
				if ( strtolower($tempaa[0])=="auto" ){
					$gpsstyle=$tempaa[1];
				}else{
					$gpsstyle="styleid_03";
				}	
			}
			dbg("d","gpsstyle => ".$gpsstyle); ####sleep(2);
				//array data structures
			/*
			[setkmlarray][BCC]
			pm00kmloutname01="GPS Track"
			pm00kmloutdesc01="GPS data only tracked"
			pm00kmloutenabled01="True"
			pm00kmloutoptiondata01="Both";//options are Auto,USB,Both
			pm01kmloutspecialdata01="Auto=styleid_18,USB=styleid_14"
			[crumbdata][LX 2424-7834] => Array
			        (
			            [timestamp] => 08:59:45.385
			            [gpsinjlat] => 3001.6700S
			            [gpsinjlon] => 15311.8405E
			            [gpsinjalt] => 0
			            [gpsinterval] =>  2
			            [ipaddress] => 192.168.1.99
			            [gpsmanlat] => 
			            [gpsmanlon] => 
			            [gpsmanalt] => 
			            [crumbname] => test crumb
			            [gpsautlat] => 3001.6648S
			            [gpsautlon] => 15311.8550E
			            [gpsautalt] => 11.0
			*/
			$tmp=$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('Placemark');
			$tmp->addChild('TimeStamp');
			$tmp->addChild('when',datetime2kml($projfilename,$crumbdata[$crumbtarget]['timestamp']));					
			$tmp->addChild('styleUrl',"#".$setkmlarray['BCC'][$gpsstyle]);
			$tmp->addChild('ExtendedData');
			$tmp->ExtendedData->addChild('Data');
			$tmp->ExtendedData->Data->addAttribute('name','displaytext');
			#2018-02-02T08:59:45Z,Crumb GPS
			$displayline=datetime2kml($projfilename,$crumbdata[$crumbtarget]['timestamp']).",".$setkmlarray['BCC'][$gpsstyle];
			$tmp->ExtendedData->Data->addChild('value',htmlspecialchars(fetchmetadata("GPS",$setkmlarray['BCC'][$gpsstyle],"no data",$displayline,$statsdata)));
			#$tmp->ExtendedData->Data->addChild('value',$setkmlarray['BCC'][$gpsstyle]);
			$tmp->addChild('Point');
			$tmp->Point->addChild('coordinates',nema2kml(GPScoord($crumbdata[$crumbtarget]['gpsautlat']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlat']).",".GPScoord($crumbdata[$crumbtarget]['gpsautlon']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlon']).",0,1"));
			dbg("d","tempentry end of adding placemark ?>".$projfilename);
			#dbg("d",GPScoord($crumbdata[$crumbtarget]['gpsautlon']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlon']).",".GPScoord($crumbdata[$crumbtarget]['gpsautlat']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlat']).",");
			####sleep(1);
		}//end if gps to placemark is auto or both
			##############
		if ((strtolower($setkmlarray['BCC']['pm00kmlouthiddenoptiondata01']) == "both") || (strtolower($setkmlarray['BCC']['pm00kmlouthiddenoptiondata01']) == "usb")){
			#tname= LX 2424-7834 GPS Track //plus option data if set
			$tname=trim($crumbtarget." ".$setkmlarray["BCC"]["pm00kmloutname01"]." ".$setkmlarray["BCC"]["pm00kmloutoptiondata01"]." ".$setkmlarray["BCC"]["pm00kmloutspecialdata01"]);
			#$tname=trim($crumbtarget." ".$setkmlarray["BCC"]["pm00kmloutname01"]." GPS Data");
			updatestats("Placemarks_".$tname,$function,0,$statsdata);
			//if get our style id for this type of gps data
								    
			$temparray=explode(",",$setkmlarray['BCC']['pm00kmlouthiddenspecialdata01']);
			$tempaa=explode("=",$temparray[0]);
			if ( strtolower($tempaa[0])=="usb" ){
				$gpsstyle=$tempaa[1];
			}else{ $tempaa=explode("=",$temparray[1]);
				if ( strtolower($tempaa[0])=="usb" ){
					$gpsstyle=$tempaa[1];
				}else{
					$gpsstyle="styleid_04";
				}	
			}
			dbg("d","gpsstyle => ".$gpsstyle); ####sleep(2);
			//array data structures
			/*
			[setkmlarray][BCC]
			pm00kmloutname01="GPS Track"
			pm00kmloutdesc01="GPS data only tracked"
			pm00kmloutenabled01="True"
			pm00kmloutoptiondata01="Both";//options are Auto,USB,Both
			pm01kmloutspecialdata01="Auto=styleid_18,USB=styleid_14"
			[crumbdata][LX 2424-7834] => Array
			        (
			            [timestamp] => 08:59:45.385
			            [gpsinjlat] => 3001.6700S
			            [gpsinjlon] => 15311.8405E
			            [gpsinjalt] => 0
			            [gpsinterval] =>  2
			            [ipaddress] => 192.168.1.99
			            [gpsmanlat] => 
			            [gpsmanlon] => 
			            [gpsmanalt] => 
			            [crumbname] => test crumb
			            [gpsautlat] => 3001.6648S
			            [gpsautlon] => 15311.8550E
			            [gpsautalt] => 11.0
			*/
			$tmp=$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('Placemark');
			$tmp->addChild('TimeStamp');
			$tmp->addChild('when',datetime2kml($projfilename,$crumbdata[$crumbtarget]['timestamp']));					
			$tmp->addChild('styleUrl',"#".$setkmlarray['BCC'][$gpsstyle]);
			$tmp->addChild('ExtendedData');
			$tmp->ExtendedData->addChild('Data');
			$tmp->ExtendedData->Data->addAttribute('name','displaytext');
			#2018-02-02T08:59:45Z,Crumb GPS
			$displayline=datetime2kml($projfilename,$crumbdata[$crumbtarget]['timestamp']).",".$setkmlarray['BCC'][$gpsstyle];
			$tmp->ExtendedData->Data->addChild('value',htmlspecialchars(fetchmetadata("GPS",$setkmlarray['BCC'][$gpsstyle],"no data",$displayline,$statsdata)));
			#$tmp->ExtendedData->Data->addChild('value',$setkmlarray['BCC'][$gpsstyle]);
			$tmp->addChild('Point');
			$tmp->Point->addChild('coordinates',nema2kml(GPScoord($crumbdata[$crumbtarget]['gpsinjlat']).",".GPShemis($crumbdata[$crumbtarget]['gpsinjlat']).",".GPScoord($crumbdata[$crumbtarget]['gpsinjlon']).",".GPShemis($crumbdata[$crumbtarget]['gpsinjlon']).",0,1"));
			dbg("d","tempentry end of adding placemark ?>".$projfilename);
			#dbg("d",GPScoord($crumbdata[$crumbtarget]['gpsautlon']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlon']).",".GPScoord($crumbdata[$crumbtarget]['gpsautlat']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlat']).",");
			####sleep(1);
		}//end if gps to placemark is GPS or both
	} //End GPS track section
	############################################################
	############################################################
	//start SNR Section

	#pm01kmloutname01="Best SNR"
	#pm01kmloutdesc01="Best SNR Value"
	#pm01kmloutenabled01="True"
	#pm01kmloutoptiondata01="All"  ;// All=all freq ,else just selected freq 2.4Ghz,5.8Ghz,900Mhz
	#3pm01kmloutspecialdata01="All" ;//or list of channels

	#first to extract the SNRs in the peers array
	
	if (! isset($runonce)){
	$runonce=True;	
	for ($ep=1;$ep<2;$ep++){ //for p is the prefix of ie '03' pm03kmloutenabled01="True" ...here limited to 1
	for ($es=1;$es<6;$es++){ //for s is the sufffix of ie '01' pm03kmloutenabled01="True"
	if (($setkmlarray["BCC"]["pm0".$ep."kmloutenabled0".$es]=="True") && (strpos($setkmlarray["BCC"]["pm0".$ep."kmloutname0".$es],"SNR") !== False )) {
		# start populating the placemarks by finding the ones we want first

		dbg("d","setkmlarray BCC pm01kmloutoptiondata0EX->".$setkmlarray['BCC']["pm0".$ep."kmloutoptiondata0".$es]);
		###sleep(5);
		
		/*
		Peers example
 		(

		    [LX 2424-7834, "000025mj330I"] => Array
		        (
		            [peer_key1_action] => ADD
		            [peer_key1_enabled] => true
		            [peer_key1_cost] => 1506
		            [peer_key1_rate] => 540
		            [peer_key1_rssi] => 17
		            [peer_key1_signal] => -84
		            [peer_key1_encapId] => 21839
		            [peer_key1_ipv4Address] => 192.168.1.101
		            [peer_key1_txpower] => 18
		        )

[000025mi\a] => Array
        (
            [name] => wlan1
            [type] => wireless
            [ownername] => test crumb
            [ownerserialno] => LX 2424-7834
            [emac] => 00:15:6d:69:5b:97
            [slotdata] => 1911.12290
            [slotno] => 2
            [noise] => 
            [channel] => 11
            [freq] => 2.4Ghz
            [range] => 3218
            [txpower] => 18
            [gpsinjlat] => 3001.6700S
            [gpsinjlon] => 15311.8405E
            [gpsinjalt] => 0
            [gpsautlat] => 3001.6648S
            [gpsautlon] => 15311.8550E
            [gpsautalt] => 11.0
            [gpsmanlat] => 
            [gpsmanlon] => 
            [gpsmanalt] => 
            [timestamp] => 08:59:45.385
            [filename] => 
        )
		   [Freq.List] => Array
		        (
		            [0] => 2.4Ghz
		            [1] => unknown
		            [2] => 5.8Ghz
		            [3] => 900Mhz

		    [Channel.List.2.4Ghz] => Array
		        (
		            [0] => 1
		            [1] => 11
		        )

		    [MeshMacWireless.2.4Ghz.1] => Array
		        (
		            [0] => 000025mi[227
		            [1] => 000025mj330I
		        )


		*/

		#First loop throught the peerdata to get the best SNR values per selected type required push to new temp array and then make kml
		$peercollect="False";
		foreach(array_keys($peerdata) as $peerserialmac){
			$tempa=explode(",",$peerserialmac);
			dbg("d","1.1 peerserial and mac=>".$tempa[0]." ".$tempa[1]);
			foreach(array_keys($macdata) as $tmpinfo){
				dbg("d","macdata indexes =>".$tmpinfo);
			}	
			print_r($peerdata);
			print_r($crumbdata);
			if (! isset($macdata[$tempa[1]])){
				dbg("d","wmac not seen , set to unknown/skip");
				#sleep(3);

			}else{
			#sleep(1);
			$tempf=explode(",",$setkmlarray['BCC']["pm0".$ep."kmloutoptiondata0".$es]);
			$tempc=explode(",",$setkmlarray['BCC']["pm0".$ep."kmloutspecialdata0".$es]);
			if ((! $tempf[0]=="") && (! $tempc[0] =="" )){ //process both fields have data
				if ( strtolower($tempf[0]) !== "all"){ // filter out the freqs we need
				dbg("d","2 NOT all =>".strtolower($tempf[0]));
				#sleep(2);
					for ($ff=0;$ff<count($tempf);$ff++){ //list of freq to test

						dbg("d","3 ff step list of freq =>".$ff." ".$tempf[$ff]." macdata->freq->".$macdata[$tempa[1]]['freq']);
						#sleep(4);
						#print_r($macdata);
						#foreach(array_keys($macdata) as $tmpinfo){
						#	dbg("d","macdata indexes =>".$tmpinfo);
						#}	
						##sleep(8);
						if (($tempa[0]==$crumbtarget) && ($macdata[$tempa[1]]['freq'] == $tempf[$ff] )){ //if freq match freq qe use
							dbg("d","4 crumb=>".$tempa[0]."found match freq =>".$macdata[$tempa[1]]['freq']."=".$tempf[$ff]);
							#sleep(4);
							if ( strtolower($tempc[0]) !== "all"){ // filter out the channels we need
								dbg("d","5 NOT all channels");
								#sleep(4);
								for ($cc=0;$cc<count($tempc);$cc++){ //list of channels to test
									dbg("d","6 cc step list of channels =>".$cc);
									#sleep(4);
									if (($tempa[0]==$crumbtarget) && ($macdata[$tempa[1]]['channel'] == $tempc[$cc] )){ //if chan match chan we use
										dbg("d","7 found matching channels");
										comparethispeer("SNR",$tempa[0],$tempa[1],$ep,$es,$peerdata);
										#sleep(4);
									}//end if
								}//end for cc
							}else{
								comparethispeer("SNR",$tempa[0],$tempa[1],$ep,$es,$peerdata);
										#sleep(4);
							}//end if
						}//end if
 
					}//end for
				}else{
					dbg("d","A ALL freq =>".strtolower($tempf[0]));
					#sleep(4);
					if (! $tempc[0] =="All"){ // filter out the channels we need
						for ($cc=0;$cc<count($tempc);$cc++){ //list of channels to test
							if (($tempa[0]==$crumbtarget) && (getemychan($tempa[1]) == $tempc[$cc] )){ //if chan match chan we use
								comparethispeer("SNR",$tempa[0],$tempa[1],$ep,$es,$peerdata);
							}//end if
						}//end for cc
					}else{
						comparethispeer("SNR",$tempa[0],$tempa[1],$ep,$es,$peerdata);
										#sleep(4);
					}//end if
				}//end if all
			}//end if not unknown
			}//end if data
		}
	}	
	}//end for es
	}//end for ep
	}
	#for ($p=1;$p<2;$p++){ //for p is the prefix of ie '03' pm03kmloutenabled01="True" ...here limited to 1
		#for ($s=1;$s<6;$s++){ //for s is the sufffix of ie '01' pm03kmloutenabled01="True"
			if (($setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]=="True") && (strpos($setkmlarray["BCC"]["pm0".$p."kmloutname0".$s],"SNR") !== False )) {
#Build the kml

###################33
				if (! isset($peerdata["Max.".$p."SNR".$s])){

				$tname=trim($crumbtarget." ".$setkmlarray["BCC"]["pm0".$p."kmloutname0".$s]." ".$setkmlarray["BCC"]["pm0".$p."kmloutoptiondata0".$s]." ".$setkmlarray["BCC"]["pm0".$p."kmloutspecialdata0".$s]);
				if (! isset($statsdata["Placemarks_".$tname]["totalcount"])){

					dbg("d","isset not true for =>"."pm0".$p."kmloutenabled0".$s);
					dbg("d","start new header here");
					#global ${"xml_kml_".$tname};
					#first start a new kml file
					$tname=$setkmlarray["BCC"]["pm0".$p."kmloutname0".$s];
					$GLOBALS["xml_kml_".$tname]=<<<XML
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
</Document>
</kml>
XML;
					#global ${"x_k_".$tname};
					$GLOBALS["x_k_".$tname] = new SimpleXMLElement($GLOBALS["xml_kml_".$tname]);
					for ($t = 0;$t<25;$t++) {
						if ( $t<10 ){$tfixed = "0".$t;}else{$tfixed=$t;}
							#dbg("d","t cycle =".$t);
							${'seq'.$t}=$GLOBALS["x_k_".$tname]->Document->addChild('Style');
							${'seq'.$t}->addAttribute('id',$setkmlarray['BCC']["styleid_$tfixed"]);
							#$GLOBALS["x_k_".$tname]->Document->Style->addChild('Style_id',$setkmlarray['Ping']["styleid_0$t"]);
							${'seq'.$t}->addChild('IconStyle');
							${'seq'.$t}->IconStyle->addChild('scale',$setkmlarray['BCC']["scale_$tfixed"]);
							${'seq'.$t}->IconStyle->addChild('color',$setkmlarray['BCC']["color_$tfixed"]);
							${'seq'.$t}->IconStyle->addChild('Icon',$setkmlarray['BCC']["iconref_$tfixed"]);
							${'seq'.$t}->addChild('LineStyle');
							${'seq'.$t}->LineStyle->addChild('width',($setkmlarray['BCC']["scale_$tfixed"]*6));
							${'seq'.$t}->LineStyle->addChild('color',$setkmlarray['BCC']["color_$tfixed"]);
							${'seq'.$t}->addChild('LabelStyle');
							${'seq'.$t}->LabelStyle->addChild('scale','0');
							${'seq'.$t}->addChild('BalloonStyle');
							${'seq'.$t}->BalloonStyle->addChild('text','$[displaytext]');
							$GLOBALS["x_k_".$tname]->Document->addChild('Folder');
							$GLOBALS["x_k_".$tname]->Document->Folder->addChild('open','1');
							$GLOBALS["x_k_".$tname]->Document->Folder->addChild('name', $setkmlarray['BCC']['primaryfoldername']);
							$GLOBALS["x_k_".$tname]->Document->Folder->addChild('description', $setkmlarray['BCC']['primaryfolderdesc']);		
							if ($setkmlarray['BCC']["hideplacemarksintree"]="true"){
								#dbg("d","hideplacemarksintree=true");
								// <Style id="check-hide-children">
								//      <ListStyle>
								//        <listItemType>checkHideChildren</listItemType>
								//      </ListStyle>
								//    </Style>
								//    <styleUrl>#check-hide-children</styleUrl>
								$GLOBALS["x_k_".$tname]->Document->Folder->addChild('Style');
								$GLOBALS["x_k_".$tname]->Document->Folder->Style->addAttribute('id','check-hide-children');
								$GLOBALS["x_k_".$tname]->Document->Folder->Style->addChild('ListStyle');
								$GLOBALS["x_k_".$tname]->Document->Folder->Style->ListStyle->addChild('listItemStyle','checkHideChildren');
								$GLOBALS["x_k_".$tname]->Document->Folder->Style->ListStyle->addChild('bgColor','00ffffff');
								$GLOBALS["x_k_".$tname]->Document->Folder->Style->ListStyle->addChild('maxSnippetLines','0');
								// if variabkles used , as below, created this error ...maybe hideen characters? Cannot add child. Parent is not a permanent member of the XML tree in /home/mst/localhost_html/cc2kml/cc2kml_maker.php on line 274
							}//end if
							$GLOBALS["x_k_".$tname]->Document->Folder->addChild('Folder');
							$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('open','y');
							$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('name', $setkmlarray['BCC']["pm0".$p."kmloutname0".$s]);
							$GLOBALS["x_k_".$tname]->Document->Folder->Folder->addChild('description', $setkmlarray['BCC']["pm0".$p."kmloutdesc0".$s]);
							#<BalloonStyle>
							#<text>$[description]</text>
						#</BalloonStyle>
						//$GLOBALS["x_k_".$tname]->Document->folder->BalloonStyle->text = "$[description]";
						#$GLOBALS["x_k_".$tname]->Document->folder->addChild('folder');  #2nd folder 
						#$GLOBALS["x_k_".$tname]->Document->folder->folder->addChild('name', $setkmlarray['GPS']['secondaryfoldername']);
						#$GLOBALS["x_k_".$tname]->Document->folder->folder->addChild('description', $setkmlarray['GPS']['secondaryfolderdesc']);
	

					} //end for counter
				}//end if isset  , the header is now complete 
				############################################################
				//
				// start populating the placemarks
				//
				updatestats($statsdata[$setkmlarray["BCC"]["pm0".$p."kmloutname0".$s]],"SNR",$peerdata["Max.".$p."SNR".$s]["peer_key1_rssi"],$statsdata);

				if (! isset($peerdata["Max.".$p."SNR".$s])){
 					// process the array.
					/*    [LX 2424-7834,000025mj330I] => Array
				        (
					    [peer_key1_thisserial =>LX 2424-15043
					    [peer_key1_peermac] =>dsfasf/rfsf	
				            [peer_key1_action] => ADD
				            [peer_key1_enabled] => true
				            [peer_key1_cost] => 1506
				            [peer_key1_rate] => 540
				            [peer_key1_rssi] => 17
				            [peer_key1_signal] => -84
				            [peer_key1_encapId] => 21839
				            [peer_key1_ipv4Address] => 192.168.1.101
				            [peer_key1_txpower] => 18
					        )

    [000025mi[227] => Array
        (
            [name] => wlan0
            [type] => wireless
            [ownername] => test crumb
            [ownerserialno] => LX 2424-7834
            [emac] => 00:15:6d:69:5c:07
            [slotdata] => 1911.12290
            [slotno] => 1
            [noise] => -101
            [channel] => 1
            [freq] => 2.4Ghz
            [range] => 2218
            [txpower] => 18
            [gpsinjlat] => 3001.6700S
            [gpsinjlon] => 15311.8405E
            [gpsinjalt] => 0
            [gpsautlat] => 3001.6648S
            [gpsautlon] => 15311.8550E
            [gpsautalt] => 11.0
            [gpsmanlat] => 
            [gpsmanlon] => 
            [gpsmanalt] => 
            [timestamp] => 08:59:45.385
            [filename] => 
        )

					*/		

					//function updatestats($thisapplyedtype,$thistype,$thisdata,$statsdata){
					#dbg("d",GPScoord($crumbdata[$crumbtarget]['gpsautlon']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlon']).",".GPScoord($crumbdata[$crumbtarget]['gpsautlat']).",".GPShemis($crumbdata[$crumbtarget]['gpsautlat']).",");
					####sleep(1);
					updatestats($statsdata[$setkmlarray["BCC"]["pm0".$p."kmloutname0".$s]],"SNR",$peerdata["Max.".$p."SNR".$s]["peer_key1_rssi"],$statsdata);
					$tmp=$GLOBALS["x_k_".$tname]->Document->Folder->addChild('Placemark');							
					$tmp->addChild('TimeStamp');
					$tmp->TimeStamp->addChild('when',datetime2kml($projfilename,$fields[0]));
					$tmpstyle=fetchstyle("SNR",$peerdata["Max.".$p."SNR".$s]["peer_key1_rssi"],$setkmlarray);		
					$tmp->addChild('styleUrl',"#".$tmpstyle);
					$tmp->addChild('ExtendedData');
					$tmp->ExtendedData->addChild('Data');
					$tmp->ExtendedData->Data->addAttribute('name','displaytext');
					$displayline=datetime2kml($crumbdata[$crumbtarget]['timestamp']).",".$setkmlarray["BCC"]["pm0".$p."kmloutname0".$s].",".$peerdata["Max.".$p."SNR".$s]["peer_key1_rssi"].",".$peerdata["Max.".$p."SNR".$s]["peer_key1_channel"].",".$peerdata["Max.".$p."SNR".$s]["peer_key1_freq"];
					$tmp->ExtendedData->Data->addChild('value',htmlspecialchars(fetchmetadata("BCC","SNR","Max.".$p."SNR".$s,$displayline,$statsdata)));
					$tmp->addChild('Point');
					$nematmp=explode($setkmlarray['SNR']['pmo1metadataseperator'],$primary[$s]);
					$tmp->Point->addChild('extrude','1');
					$tmp->Point->addChild('altitudeMode','relativeToGround');
					$tmp->Point->addChild('coordinates',nema2kml($fields[1],$thisdata,".1"));
					dbg("d","add name = ".$tmp->addChild('name',$fields[0].$tmpstyle." ".$peerdata["Max.".$p."SNR".$s]["peer_key1_rssi"]));
					#######sleep(1);
				}	
				}//endif for SNR max exista
			}//if 
		updatestats("Project_Info",$tname,filesize($directorypath."/".$projfilename),$statsdata);
		#}
	#}
###################33
	#make kml with array=> best
	dbg("d","best snr updated");
	#sleep(1);






}//end if enabled
}//end for $p
}//end for $s
}//end if add new record

if ($function == "close" ){
for ($p=0;$p<4;$p++){ //for p is the prefix of ie '03' pm03kmloutenabled01="True"
for ($s=1;$s<4;$s++){ //for s is the sufffix of ie '01' pm03kmloutenabled01="True"
dbg("d","inside for loop ".$p.$s);
dbg("d","'pm0".$p."kmloutenabled0".$s."' =>".$setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]);
dbg("d","");
#####sleep(5);
if ($setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]=="True"){ //if this type of kml is enabled
	$tname=trim($crumbtarget." ".$setkmlarray["BCC"]["pm0".$p."kmloutname0".$s]." ".$setkmlarray["BCC"]["pm0".$p."kmloutoptiondata0".$s]." ".$setkmlarray["BCC"]["pm0".$p."kmloutspecialdata0".$s]);
	dbg("d","'pm0".$p."kmloutenabled0".$s."' is True ,desc=> ".$tname." true?=>".$setkmlarray["BCC"]["pm0".$p."kmloutenabled0".$s]);
	####sleep(3);
	if (! isset($statsdata["Placemarks_".$tname]["totalcount"])){
		dbg("d","isset not true for Placemarks_".$tname);
		dbg("e","Error NO PLACEMARKS in kml bcc file... mmm ");
		####sleep(1);
	}else{//yep placemarks in xml, close the xml	if ($headercompleted == "done"){
		dbg("d","saving to xml");
		$tmp=$directorypath."/".$setkmlarray['BCC']['outputsubdir']."/".$setkmlarray['BCC']['outputfilename'].$tname.".kml";
		checknmake($directorypath."/".$setkmlarray['BCC']['outputsubdir']);
		#$x_k_ping->asXML($tmp); saving this creates non readable format no line breaks
		#this code preserves original indented formating ... why its not automatic i dunno
		$dom = new DOMDocument("1.0");
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($GLOBALS["x_k_".$tname]->asXML());
		// Saving the XML to filename
		$tmp=$directorypath."/".$setkmlarray['BCC']['outputsubdir']."/".$setkmlarray['BCC']['outputfilename'].$tname.".kml";
		dbg("d","output dir/file = ".$tmp);
		####sleep(10);
		checknmake($directorypath."/".$setkmlarray['BCC']['outputsubdir']);
		$test=$dom->saveXML();
		$dom->save($tmp);
	}


#	$GLOBALS["x_k_".$tname] = new SimpleXMLElement($GLOBALS[${"xml_kml_".$tname}]);


}//end if enabled
}//end for $p
}//end for $s
}//end if 'close'
}//end func	


/*
updatestats($thisapplyedtype,$thistype,$thisdata,&$statsdata){
$statsdata[$thisapplyedtype]["totalcount"]++;
$statsdata[$thisapplyedtype][$thistype."count"]++;
$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
#return($statsdata);
*/

function comparethispeer($type,$peerserial,$peermac,$p,$s,& $peerdata){
if ($type == "SNR"){
 dbg("d","Type = SNR");
 dbg("d","Does ".$peerdata[$peerserial.",".$peermac]["rssi"]." >= ".$peerdata["Max.".$p.$type.$s]["rssi"] );
 if ($peerdata[$peerserial.",".$peermac]["rssi"] >= $peerdata["Max.".$p.$type.$s]["rssi"]){
  $peerdata["Max.".$p.$type.$s]=$peerdata[$peerserial.",".$peermac];
  $peerdata["Max.".$p.$type.$s]["peer_key1_thisserial"]=$peerserial;
  $peerdata["Max.".$p.$type.$s]["peer_key1_peermac"]=$peermac;
print_r($peerdata["Max.".$p.$type.$s]);
  dbg("d","updated topdog peerdata =>"."Max.".$p.$type.$s);
#sleep(4);
 }
}


#  foreach(array_keys($peerdata) as $peerserialmac){
#		$tempa=explode(",",$peerserialmac);
#function test_print($item, $key)
#{
#    echo "$key holds $item\n";
#}
#array_walk_recursive($fruits, 'test_print');





if ($type == "COST"){

}
}//end fuction



function GPShemis($coord){ //split out the S or N from the coords strings
return (substr($coord,-1,1));
}//end function

function GPScoord($coord){ //split out the 'coord' from the coords strings
return (substr($coord,0,strlen($coord)-1));
}//end function





function checkforkmltriggerevent(&$crumbdata,&$setkmlarray,$type,$typeval,$crumbtarget){
#checkforkmltriggerevent($crumbdata,$setkmlarray,gpsinjlat,$gpsinjlat);
dbg("d","entered checkforkmltriggerevent with => ".$type.",".$typeval.",".$crumbtarget);
sleep(1);
dbg("d","entered checkforkmltriggerevent ");
sleep(1);
dbg("d","GLOBALS[triggerakmlevent] value =>".$GLOBALS["triggerakmlevent"]);
sleep(1);
if (! $GLOBALS["triggerakmlevent"] == True) { //if not already triggered for this file line row
	#targetcrumbgpspreference="auto"  ;// "auto" = crumb , "injected" = pc usb gps 
	dbg("d","1 trigerakmlevvent already false , checking for true");####sleep(1);
	if (($type=="gpsinjlat") || ($type=="gpsinjlon") || ($type=="gpsinjalt")){ //if inject gps coords
		dbg("d","2 trigerakmlevent inj type being checked= true");####sleep(1);
		if  ( strtolower($setkmlarray['BCC']['targetcrumbgpspreference'] ) == "injected") { //if gps selection is injected then only trigger on injected change
			dbg("d","3 trigerakmlevvent  checking for injected only for crumbgpspreference");####sleep(1);
			if (strtolower($setkmlarray['BCC']['triggeronmovementonly']) == "true") {
				dbg("d","4 trigerakmlevvent triggeronmovementobnly = true");####sleep(1);
				if (! $crumbdata[$crumbtarget]["$type"] == $typeval){
					$GLOBALS["triggerakmlevent"] = True;
					dbg("d","5 GLOBALS[triggerakmlevent] - set to true dps location changed ... inj =>".$GLOBALS["triggerakmlevent"]);
					####sleep(1);
					return (True);//if changed the trigger a 'kml make event'
				}

			}else{
				dbg("d","trigerakmlevvent triggeronmovementobnly = false reporting a trigger");
				$GLOBALS["triggerakmlevent"] = True;
				dbg("d","GLOBALS[triggerakmlevent] - set to true dps location changed ... inj =>".$GLOBALS["triggerakmlevent"]);
				return (True);//if changed the trigger a 'kml make event'
	
			}
		}
	}
	if (($type=="gpsautlat") || ($type=="gpsautlon") || ($type=="gpsautalt")){ //if auto bc gps coords
		dbg("d","2 trigerakmlevent aut type being checked= true");####sleep(1);
		if  (strtolower($setkmlarray['BCC']['targetcrumbgpspreference']) == "auto"){ //if gps selection is auto then only trigger on auto change
			dbg("d","3 trigerakmlevvent  checking for auto only for crumbgpspreference");####sleep(1);
			if (strtolower($setkmlarray['BCC']['triggeronmovementonly']) == "true") {
				dbg("d","4 trigerakmlevvent triggeronmovementobnly = true");####sleep(1);
				if (! $crumbdata[$crumbtarget]["$type"] == $typeval){
					$GLOBALS["triggerakmlevent"] = True;
					dbg("d","5 GLOBALS[triggerakmlevent] - set to true dps location changed ... inj =>".$GLOBALS["triggerakmlevent"]);
					####sleep(1);
					return (True);//if changed the trigger a 'kml make event'
				}

			}else{
				dbg("d","trigerakmlevvent triggeronmovementobnly = false reporting a trigger");
				$GLOBALS["triggerakmlevent"] = True;
				dbg("d","GLOBALS[triggerakmlevent] - set to true dps location changed ... inj =>".$GLOBALS["triggerakmlevent"]);
				return (True);//if changed the trigger a 'kml make event'
	
			}
		}
	}
}else{
	dbg("d","GLOBALS[triggerakmlevent] - exiting =>".$GLOBALS["triggerakmlevent"]);
	return(True);
#	#####sleep(5);
}//end if
}


function propigate(& $crumbdata,$serialno,& $macdata){

/*
    [LX4-2295-21839] => Array
        (
            [gpsinterval] =>  2
            [authstatus] =>  authentication successful
            [ipaddress] =>  192.168.1.101
            [macs] =>  00:d0:12:d9:ee:43 00:d0:12:d9:ee:44 00:15:6d:6a:d7:e1 00:15:6d:6a:dc:0c 00:30:1a:46:05:0b 00:15:6d:6a:d8:49
            [wireless_key1_mac] =>  000025mj327341
            [wireless_key1_name] =>  wlan1
            [wireless_key1_noise] =>  -96
            [wireless_key1_channel] =>  11
            [wireless_key1_range] =>  3218
            [wireless_key1_txpower] =>  9
            [wireless_key0_mac] =>  000025mj334f
            [wireless_key0_name] =>  wlan3
            [wireless_key0_noise] => 
            [wireless_key0_channel] =>  153
            [wireless_key0_range] =>  3218
            [wireless_key0_txpower] =>  17
            [wireless_key3_mac] =>  000025mj330I
            [wireless_key3_name] =>  wlan2
            [wireless_key3_noise] =>  -100
            [wireless_key3_channel] =>  1
            [wireless_key3_range] =>  2218
            [wireless_key3_txpower] =>  11
            [wired_key0_mac] =>  000320022331356C
            [wired_key0_aptState] =>  APT_STATE_LINK
            [wired_key0_name] =>  eth0
            [wired_key1_mac] =>  000320022331356D
            [wired_key1_aptState] =>  APT_STATE_NONE
            [wired_key1_name] =>  eth1
            [crumbname] =>  mst19
        )

    [000025mi\a] => Array
        (
            [name] => wlan1
            [type] => wireless
            [ownername] => test crumb
            [ownerserialno] => LX 2424-7834
            [emac] => 00:15:6d:69:5b:97
            [noise] => 
            [channel] => 11
            [range] => 3218
            [txpower] => 18
            [gpsinjlat] => 3001.6700S
            [gpsinjlon] => 15311.8405E
            [gpsinjalt] => 0
            [gpsautlat] => 3001.6648S
            [gpsautlon] => 15311.8550E
            [gpsautalt] => 11.0
            [gpsmanlat] => 
            [gpsmanlon] => 
            [gpsmanalt] => 
            [timestamp] => 08:59:45.385
            [filename] => 201802020859_bcclp.log
            [slot] => 1
        )


Arrays with $macdata
[MeshMacList.All]

[MeshMacWireless,2400ghz,1]
000025mi\a

[MeshMacWireless,5800ghz,146]
000025mi\a

[MeshMacWired]
000025mi\a

MeshMacWireless.All
000025mi\a

Freq.List
2400Ghz

Channel.List.2400Ghz
11
1


*/
$tmpaa=explode(" ",trim($crumbdata[$serialno]["macs"]));
##print_r($tmpaa);
print_r($crumbdata);
######sleep(15);
#$maclistallindex;
for ($s=0;$s<2;$s++){
$tmp=$crumbdata[$serialno]["wired_key".$s."_mac"];
$macdata[$tmp]["name"]=$crumbdata[$serialno]["wired_key".$s."_name"];
$macdata[$tmp]["type"]="wired";
$macdata[$tmp]["state"]=$crumbdata[$serialno]["wired_key".$s."_aptState"];
$macdata[$tmp]["ownername"]=$crumbdata[$serialno]["crumbname"];
$macdata[$tmp]["ownerserialno"]=$serialno;
$macdata[$tmp]["gpsinjlat"]=$crumbdata[$serialno]["gpsinjlat"];
$macdata[$tmp]["gpsinjlon"]=$crumbdata[$serialno]["gpsinjlon"];
$macdata[$tmp]["gpsinjalt"]=$crumbdata[$serialno]["gpsinjalt"];
$macdata[$tmp]["gpsautlat"]=$crumbdata[$serialno]["gpsautlat"];
$macdata[$tmp]["gpsautlon"]=$crumbdata[$serialno]["gpsautlon"];
$macdata[$tmp]["gpsautalt"]=$crumbdata[$serialno]["gpsautalt"];
$macdata[$tmp]["gpsmanlat"]=$crumbdata[$serialno]["gpsmanlat"];
$macdata[$tmp]["gpsmanlon"]=$crumbdata[$serialno]["gpsmanlon"];
$macdata[$tmp]["gpsmanalt"]=$crumbdata[$serialno]["gpsmanalt"];
$macdata[$tmp]["timestamp"]=$crumbdata[$serialno]["timestamp"];
$macdata[$tp]["filename"]=$crumbdata[$serialno]["filename"];
if (!in_array($crumbdata[$serialno]["wired_key".$s."_mac"], $macdata["MeshMacWired"])){
    $macdata["MeshMacWired"][] = $crumbdata[$serialno]["wired_key".$s."_mac"]; //addded to MeshMacWired
}
if (!in_array($crumbdata[$serialno]["wired_key".$s."_mac"], $macdata["MeshMacList.All"])){
    $macdata["MeshMacList.All"][] = $crumbdata[$serialno]["wired_key".$s."_mac"]; //addded to MeshMacAll
}



#$GLOBALS["maclistallindex"]++;




}

for ($s=0;$s<4;$s++){
$tmp=$crumbdata[$serialno]["wireless_key".$s."_mac"];
$macdata[$tmp]["name"]=$crumbdata[$serialno]["wireless_key".$s."_name"];
$macdata[$tmp]["type"]="wireless";
#$macdata[$tmp]["state"]="na";
$macdata[$tmp]["ownername"]=$crumbdata[$serialno]["crumbname"];
$macdata[$tmp]["ownerserialno"]=$serialno;
$macdata[$tmp]["emac"]=$tmpaa[$s+2];
$macdata[$tmp]["slotdata"]=$crumbdata[$serialno]["slot".($s+1)];
$macdata[$tmp]["slotno"]=$s+1;
$macdata[$tmp]["noise"]=$crumbdata[$serialno]["wireless_key".$s."_noise"];
$macdata[$tmp]["channel"]=$crumbdata[$serialno]["wireless_key".$s."_channel"];
$macdata[$tmp]["freq"]=$crumbdata[$serialno]["wireless_key".$s."_freq"];
$macdata[$tmp]["range"]=$crumbdata[$serialno]["wireless_key".$s."_range"];
$macdata[$tmp]["txpower"]=$crumbdata[$serialno]["wireless_key".$s."_txpower"];
$macdata[$tmp]["gpsinjlat"]=$crumbdata[$serialno]["gpsinjlat"];
$macdata[$tmp]["gpsinjlon"]=$crumbdata[$serialno]["gpsinjlon"];
$macdata[$tmp]["gpsinjalt"]=$crumbdata[$serialno]["gpsinjalt"];
$macdata[$tmp]["gpsautlat"]=$crumbdata[$serialno]["gpsautlat"];
$macdata[$tmp]["gpsautlon"]=$crumbdata[$serialno]["gpsautlon"];
$macdata[$tmp]["gpsautalt"]=$crumbdata[$serialno]["gpsautalt"];
$macdata[$tmp]["gpsmanlat"]=$crumbdata[$serialno]["gpsmanlat"];
$macdata[$tmp]["gpsmanlon"]=$crumbdata[$serialno]["gpsmanlon"];
$macdata[$tmp]["gpsmanalt"]=$crumbdata[$serialno]["gpsmanalt"];
$macdata[$tmp]["timestamp"]=$crumbdata[$serialno]["timestamp"];
$macdata[$tmp]["filename"]=$crumbdata[$serialno]["filename"];

if (!in_array($crumbdata[$serialno]["wireless_key".$s."_mac"], $macdata["MeshMacList.All"])){
    $macdata["MeshMacList.All"][] = $crumbdata[$serialno]["wireless_key".$s."_mac"]; //addded to MeshMacAll
}


if (!in_array($crumbdata[$serialno]["wireless_key".$s."_mac"], $macdata["MeshMacWireless.".$crumbdata[$serialno]["wireless_key".$s."_freq"].".".$crumbdata[$serialno]["wireless_key".$s."_channel"]])){
    $macdata["MeshMacWireless.".$crumbdata[$serialno]["wireless_key".$s."_freq"].".".$crumbdata[$serialno]["wireless_key".$s."_channel"]][] = $crumbdata[$serialno]["wireless_key".$s."_mac"]; //addded to MeshMacWireless
}
if (!in_array($crumbdata[$serialno]["wireless_key".$s."_freq"], $macdata["Freq.List"])){
    $macdata["Freq.List"][] = $crumbdata[$serialno]["wireless_key".$s."_freq"]; //addded to Freq.List
}

if (!in_array($crumbdata[$serialno]["wireless_key".$s."_channel"], $macdata["Channel.List.".$crumbdata[$serialno]["wireless_key".$s."_freq"]])){
    $macdata["Channel.List.".$crumbdata[$serialno]["wireless_key".$s."_freq"]][] = $crumbdata[$serialno]["wireless_key".$s."_channel"]; //addded to Channel.List.{freq}
}

if (!in_array($crumbdata[$serialno]["wireless_key".$s."_mac"], $macdata)){
    $macdata[$crumbdata[$serialno]["wireless_key".$s."_mac"]]["freq"] = $crumbdata[$serialno]["wireless_key".$s."_freq"]; //addded to macdata mac freq
    $macdata[$crumbdata[$serialno]["wireless_key".$s."_mac"]]["channel"] = $crumbdata[$serialno]["wireless_key".$s."_channel"]; //addded to macdata mac freq
    $macdata[$crumbdata[$serialno]["wireless_key".$s."_mac"]]["noise"] = $crumbdata[$serialno]["wireless_key".$s."_noise"]; //addded to macdata mac freq
    $macdata[$crumbdata[$serialno]["wireless_key".$s."_mac"]]["range"] = $crumbdata[$serialno]["wireless_key".$s."_range"]; //addded to macdata mac freq
    $macdata[$crumbdata[$serialno]["wireless_key".$s."_mac"]]["txpower"] = $crumbdata[$serialno]["wireless_key".$s."_txpower"]; //addded to macdata mac freq
    $macdata[$crumbdata[$serialno]["wireless_key".$s."_mac"]]["name"] = $crumbdata[$serialno]["wireless_key".$s."_name"]; //addded to macdata mac freq
}


#$GLOBALS["maclistallindex"]++;

}


#print_r($macdata); 
####sleep(20);
}





function findmyfreq($mac,$channel,$slotdata,&$setkmlarray){
#dbg("d","findmyfreq=>".$mac.",".$channel.",".$slotdata);
/*
[mactochannellist]
freq2400="00:15:6D" ;//list can be delited with ,
freq5800="00:15:6D"
freq900="00:30:1a"
freq4800=""
freq4900=""
chan2400min="1"
chan2400max="14"
chan5800min="149"
chan5800max="165"
chan900min="4"
chan900max="7"
chan4800min="162"
chan4800max="174"
chan4900min="5"
chan4900max="95"
*/

if ($mac==""){dbg("d","mac is null, returnval=unknown"); return("unknown");}
#dbg("d","findmyfreq=>".$mac.",".$channel.",".$slotdata);
$mac=substr($mac,0,8);
#dbg("d","findmyfreq=>".$mac.",".$channel.",".$slotdata."=>".$setkmlarray['mactochannellist']['chan2400min'].".".$setkmlarray['mactochannellist']['chan2400max']);
######sleep(10);

$temparray=explode(",",$setkmlarray['mactochannellist']['freq900']);
for ($i=0;$i<=count[$temparray];$i++){
	if ($mac==$temparray[$i]){dbg("d","mac returnval=900Mhz"); return("900Mhz");}
}
$temparray=explode(",",$setkmlarray['mactochannellist']['freq2400']);
for ( $i=0;$i<count($temparray);$i++ ){
	if ( $mac==$temparray[$i] ){
		for($o=$setkmlarray['mactochannellist']['chan2400min'];$o<=$setkmlarray['mactochannellist']['chan2400max'];$o++){
			#dbg("d","findmyfreq=>".$o);
			######sleep(1);
			if ($channel == $o){dbg("d","mac returnval=2.4Ghz"); return("2.4Ghz");}
		}//end for channel list
	}
}
$temparray=explode(",",$setkmlarray['mactochannellist']['freq5800']);
for ($i=0;$i<=count($temparray);$i++){
	if ( $mac==$temparray[$i] ){
		for($o=$setkmlarray['mactochannellist']['chan5800min'];$o<=$setkmlarray['mactochannellist']['chan5800max'];$o++){
			if ($channel == $o){dbg("d","mac returnval=5.8Ghz"); return("5.8Ghz");}
		}//end for channel list
	}
}
$temparray=explode(",",$setkmlarray['mactochannellist']['freq4800']);
for ($i=0;$i<=count($temparray);$i++){
	if ( $mac==$temparray[$i] ){
		for($o=$setkmlarray['mactochannellist']['chan4800min'];$o<=$setkmlarray['mactochannellist']['chan4800max'];$o++){
			if ($channel == $o){dbg("d","mac returnval=4.8Ghz"); return("4.8Ghz");}
		}//end for channel list
	}
}

$temparray=explode(",",$setkmlarray['mactochannellist']['freq4900']);
for ($i=0;$i<=count($temparray);$i++){
	if ( $mac==$temparray[$i] ){
		for($o=$setkmlarray['mactochannellist']['chan4900min'];$o<=$setkmlarray['mactochannellist']['chan4900max'];$o++){
			if ($channel == $o){dbg("d","mac returnval=4.9Ghz"); return("4.9Ghz");}
		}//end for channel list
	}
}

dbg("d","mac is not matched, returnval=unknown");

return("unknown");

}//endfuction









function build_pingkml($scanned_directory,$setkmlarray,$directorypath,&$statsdata){
	for ($p = 1;$p<3;$p++){
	if ($p=='1'){ 
	 $ptype="ping1";
	 $pname="PingPrimary";
        }
	if ($p=='2'){
	 $ptype="ping2";
	 $pname="PingSecondary";
	}
	$tmpfilenumber=1;
	$headercompleted="";
	foreach ($scanned_directory as &$projfilename) {
		if (strstr($projfilename,$ptype)){
			#echo "filnum=".$projfilename.">".$tmpfilenumber;
			#######sleep(3);
			#could here export to GPXfile for ver2? maybe
			if ($tmpfilenumber == 1) { //first occurrance make a header
				#first start a new kml file
				$xml_kml_ping=<<<XML
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
</Document>
</kml>
XML;

				$x_k_ping = new SimpleXMLElement($xml_kml_ping);
				/*
				#[gps]
				#filenamecontainer="gps"   ;[unique txt from file name , dictakes format to check fields for]
				#outputfilename="gps_track.kml"
				#primaryfoldername="CC2KML"
				#primaryfolderdesc="Data collection tool . v 0.20180216"
				#secondaryfoldername="GPS track data"
				#secondaryfolderdesc="Collected GPS Data from target "


				#styleid_00=None
				#scale_00=.75
				#color_00=ff000000 ;//Red
				#iconref_00=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png
				*/


				/*
				Style id="redisbadStyle">
				<IconStyle>
				<scale>.75</scale>
				<color>ff000000</color>
				<Icon>
				<href>http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png</href>
				</Icon>
				</IconStyle>
				<BalloonStyle>
				<text>$[description]</text>
				</BalloonStyle>
				</Style>
				*/
				for ($t = 0;$t<6;$t++) {
					#$t=0;
					#dbg("d","t cycle =".$t);
					${'seq'.$t}=$x_k_ping->Document->addChild('Style');
					${'seq'.$t}->addAttribute('id',$setkmlarray['Ping']["styleid_0$t"]);
					#$x_k_ping->Document->Style->addChild('Style_id',$setkmlarray['Ping']["styleid_0$t"]);
					${'seq'.$t}->addChild('IconStyle');
					${'seq'.$t}->IconStyle->addChild('scale',$setkmlarray['Ping']["scale_0$t"]);
					${'seq'.$t}->IconStyle->addChild('color',$setkmlarray['Ping']["color_0$t"]);
					${'seq'.$t}->IconStyle->addChild('Icon',$setkmlarray['Ping']["iconref_0$t"]);

					${'seq'.$t}->addChild('LineStyle');
					${'seq'.$t}->LineStyle->addChild('width',($setkmlarray['Ping']["scale_0$t"]*6));
					${'seq'.$t}->LineStyle->addChild('color',$setkmlarray['Ping']["color_0$t"]);

					${'seq'.$t}->addChild('LabelStyle');
					${'seq'.$t}->LabelStyle->addChild('scale','0');

					${'seq'.$t}->addChild('BalloonStyle');
					${'seq'.$t}->BalloonStyle->addChild('text','$[displaytext]');
				}
				$x_k_ping->Document->addChild('Folder');
				$x_k_ping->Document->Folder->addChild('open','1');
				$x_k_ping->Document->Folder->addChild('name', $setkmlarray['Ping']['primaryfoldername']);
				#description addded with stats below
				#$x_k_ping->Document->Folder->addChild('description', $setkmlarray['Ping']['primaryfolderdesc']);

				if ($setkmlarray['Ping']["hideplacemarksintree"]="true"){
					#dbg("d","hideplacemarksintree=true");

					// <Style id="check-hide-children">
					//      <ListStyle>
					//        <listItemType>checkHideChildren</listItemType>
					//      </ListStyle>
					//    </Style>
					//    <styleUrl>#check-hide-children</styleUrl>
					$x_k_ping->Document->Folder->addChild('Style');
					$x_k_ping->Document->Folder->Style->addAttribute('id','check-hide-children');
					$x_k_ping->Document->Folder->Style->addChild('ListStyle');
					$x_k_ping->Document->Folder->Style->ListStyle->addChild('listItemStyle','checkHideChildren');
					$x_k_ping->Document->Folder->Style->ListStyle->addChild('bgColor','00ffffff');
					$x_k_ping->Document->Folder->Style->ListStyle->addChild('maxSnippetLines','0');
					// if variabkles used , as below, created this error ...maybe hideen characters? Cannot add child. Parent is not a permanent member of the XML tree in /home/mst/localhost_html/cc2kml/cc2kml_maker.php on line 274
				}

				#<BalloonStyle>
				#<text>$[description]</text>
				#</BalloonStyle>
				
				//$x_k_ping->Document->folder->BalloonStyle->text = "$[description]";
				#$x_k_ping->Document->folder->addChild('folder');  #2nd folder 
				#$x_k_ping->Document->folder->folder->addChild('name', $setkmlarray['GPS']['secondaryfoldername']);
				#$x_k_ping->Document->folder->folder->addChild('description', $setkmlarray['GPS']['secondaryfolderdesc']);
				$headercompleted="done";
			}//endif $tmpfilenumber
			$tmpfilenumber++;
			//
			// start populating the placemarks
			//
			dbg("d","final scanned_directory/projfilename =$directorypath."/".$projfilename");
			$handle = fopen($directorypath."/".$projfilename, "r");
			if ($handle) {
				while (($line = fgets($handle)) !== false) {
					// process the line read.		
					//08:33:11.987 ttyUSB0 (72) $GPRMC,213315.597,A,3001.6899,S,15311.8652,E,000.0,000.0,310118,,,A*77
					//08:33:13.210 192.168.1.101 !213316.597,3001.6899,S,15311.8652,E! 1 packets transmitted, 0 received, +1 errors, 100% packet loss, time 0ms
					//08:33:11.595 127.0.0.1 !112113.027,3001.6701,S,15311.8400,E! 64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.024 ms
					if (TRUE){
					//if (strpos($line,$setkmlarray['Ping']['pm01validkeyword'])){

						//if line contains key word
						$fields=explode($setkmlarray['Ping']['pmo1coorddataseperator'],$line);
						//explode the line
						/*
						pm01ifkeyword="$GPRM"
						pm01primaryseperator=","
						pmo1metadataseperator=" "
						pmo1coorddataseperator="!"
						pm01placemarkname="GPS go"
						*/
						//<description><![CDATA[<b>Name: </b>BMACVMTR050RBC01<br /><b>MAC: </b>00:30:1a:46:04:9b<br /><b>Radio no: </b>wlan0<br /><b>Modulation: </b>1<br /><b>SNR: </b>102<br /><b>Cost: </b>400504<br /><b>Date: </b>21/05/2015<br /><b>Time: </b>0929.4100<br /><b>Longitude: </b>148.0609<br /><b>Latitude: </b>-22.157045<br /><b>Altitude: </b>252 m<br /><b>Suplimentry Data: </b>wlan3 5800 MHz 160 19-wlan2 2462 MHz 11 28-wlan2 2462 MHz 11 42-wlan0 922 MHz 7 56-wlan0 922 MHz 7 64-wlan0 922 MHz 7 102-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>
						//1. first split out coords with pmo1coorddataseperator
						//2. [0]=time/dest [1]=coords [2]=string
						//3. split [2] with pm01primaryseperator ','
						//4. look for error
						//5  look for good data / plot / do stats
						$thistype="";
						$primary=explode($setkmlarray['Ping']['pm01primaryseperator'],$fields[2]);
						#dbg("d","data string = ".$fields[2]);
						for ($s = count($primary)-1;$s!=0;$s--){
							#dbg("d","s steps = ".$s);
							#dbg("d","s primary var s = ".$primary[$s]."<  is it = too >".$setkmlarray['Ping']['pm01iflostkeyword']);
							if ($primary[$s] == $setkmlarray['Ping']['pm01iflostkeyword']) {
								dbg("d","YES lost ".$s);
								//this is an error string
								$thistype="Error";
								$thisdata="100% packet loss";  //data nothing changed to 1000 * .1 = 100m  elevation
								break;
							}
							#dbg("d","s primary var s = ".$primary[$s]."<  is it = too >".$setkmlarray['Ping']['pm01ifdatakeyword']);
							if ($primary[$s] == $setkmlarray['Ping']['pm01ifdatakeyword']){
								dbg("d","YES data ".$s);
								//this is a return value of succesful ping event
								$thistype="Data";
								//we dont want this field 's' though as the data we need is 2 fields towards the end
								$stmp=explode($setkmlarray['Ping']['pmo1metadataseperator'],$primary[$s+2]);
								$thisdata=$stmp[1];
								break;
							}
							#dbg("d","s primary var s = ".$primary[$s]."<  is it = too >".$setkmlarray['Ping']['pm01ifdismisskeyword']);
							if ($primary[$s] == $setkmlarray['Ping']['pm01ifdismisskeyword']){
								dbg("d","YES data is to be dismissed ".$s);
								//this is a return value of succesful ping event
								break;
							}

						}
						if ($thistype != "" ){
							//good record process style
;//metadata
;//<description><![CDATA[<b>Name: </b>BMACVMTR050RBC01<br /><b>MAC: </b>00:30:1a:46:04:9b<br /><b>Radio no: </b>wlan0<br /><b>Modulation: </b>1<br /><b>SNR: </b>102<br /><b>Cost: </b>400504<br /><b>Date: </b>21/05/2015<br /><b>Time: </b>0929.4800<br /><b>Longitude: </b>148.060793333333<br /><b>Latitude: </b>-22.1573516666667<br /><b>Altitude: </b>253 m<br /><b>Suplimentry Data: </b>wlan3 5800 MHz 160 19-wlan2 2462 MHz 11 28-wlan2 2462 MHz 11 44-wlan0 922 MHz 7 56-wlan0 922 MHz 7 64-wlan0 922 MHz 7 102-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>

							//function updatestats($thisapplyedtype,$thistype,$thisdata,$statsdata){
							updatestats("Placemarks_".$pname,$thistype,$thisdata,$statsdata);
							
							$tmp=$x_k_ping->Document->Folder->addChild('Placemark');							
							$tmp->addChild('TimeStamp');
							$tmp->TimeStamp->addChild('when',datetime2kml($projfilename,$fields[0]));
							$tmpstyle=fetchstyle("Ping",$thisdata,$setkmlarray);		
							$tmp->addChild('styleUrl',"#".$tmpstyle);
							$tmp->addChild('ExtendedData');
							$tmp->ExtendedData->addChild('Data');
							$tmp->ExtendedData->Data->addAttribute('name','displaytext');
							$tmp->ExtendedData->Data->addChild('value',htmlspecialchars(fetchmetadata($pname,$thistype,$thisdata,$line,$statsdata)));
							$tmp->addChild('Point');
							$nematmp=explode($setkmlarray['Ping']['pmo1metadataseperator'],$primary[$s]);
							$tmp->Point->addChild('extrude','1');
							$tmp->Point->addChild('altitudeMode','relativeToGround');
							$tmp->Point->addChild('coordinates',nema2kml($fields[1],$thisdata,".1"));
							dbg("d","add name = ".$tmp->addChild('name',$fields[0].$tmpstyle." ".$thisdata));
							#######sleep(1);
						}//endif for "thistype" not blank ..good record process style


					}//if line has a keyword
				}//endwhile
				fclose($handle);			
			} else {
						// error opening the file.
			} //end handle
			#echo filesize($directorypath."/".$projfilename);
			########sleep(10);
			updatestats("Project_Info",$pname,filesize($directorypath."/".$projfilename),$statsdata);
			#print_r($statsdata);

		}//endif if file is a PING file
	}//endif finding a file dir finished searching  	

	dbg("d","total of "."Placemarks_".$pname."=".calcstats("Placemarks_".$pname,$pname,"totalnumofpings",$statsdata));
	
	dbg("d","total of "."averagevalueofpings_".$pname."=".round(calcstats("Placemarks_".$pname,$pname,"averagevalueofpings",$statsdata),3)."ms");

	dbg("d","total of "."total num of lost pings_".$pname."=".calcstats("Placemarks_".$pname,$pname,"totalnumoflostpings",$statsdata));

	dbg("d","total of "."percentage of lost pings_".$pname."=".round(calcstats("Placemarks_".$pname,$pname,"percentageoflostpings",$statsdata),3)."%");

	
	$statstext="\nTotal No of Placemarks = ".calcstats("Placemarks_".$pname,$pname,"totalnumofpings",$statsdata)."\n";
	$statstext=$statstext."Everage ping = ".round(calcstats("Placemarks_".$pname,$pname,"averagevalueofpings",$statsdata),3)."ms\n";
	$statstext=$statstext."Lost Pings total = ".calcstats("Placemarks_".$pname,$pname,"totalnumoflostpings",$statsdata)."\n";
	$statstext=$statstext."Percentage of pings lost = ".round(calcstats("Placemarks_".$pname,$pname,"percentageoflostpings",$statsdata),3)."%\n";


	$x_k_ping->Document->Folder->addChild('description', $setkmlarray['Ping']['primaryfolderdesc']."\n".$statstext);


	######sleep(5);

	if ($headercompleted == "done"){
		dbg("d","saving to xml");
		$tmp=$directorypath."/".$setkmlarray['Ping']['outputsubdir']."/".$setkmlarray['Ping']['outputfilename'].$pname.".kml";
		checknmake($directorypath."/".$setkmlarray['Ping']['outputsubdir']);
		#$x_k_ping->asXML($tmp); saving this creates non readable format no line breaks
		#this code preserves original indented formating ... why its not automatic i dunno
		$dom = new DOMDocument("1.0");
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($x_k_ping->asXML());
		// Saving the XML to filename
		$tmp=$directorypath."/".$setkmlarray['Ping']['outputsubdir']."/".$setkmlarray['Ping']['outputfilename'].$pname.".kml";
		dbg("d","output dir/file = ".$tmp);
		checknmake($directorypath."/".$setkmlarray['Ping']['outputsubdir']);
		$test=$dom->saveXML();
		$dom->save($tmp);
	}
	}//end foreach $t 
########sleep(60);
}







function updatestats($thisapplyedtype,$thistype,$thisdata,&$statsdata){

$statsdata[$thisapplyedtype]["totalcount"]++;
$statsdata[$thisapplyedtype][$thistype."count"]++;
$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
#return($statsdata);
}


function calcstats($thisapplyedtype,$thistype,$thisdata,&$statsdata){


if ($thisdata=="totalnumofpings"){
 if (isset($statsdata[$thisapplyedtype]["totalcount"])){
  return($statsdata[$thisapplyedtype]["totalcount"]);
 }else{
  return("0");
 }
}
if ($thisdata=="averagevalueofpings"){
 if (isset($statsdata[$thisapplyedtype]["Datadatatotal"]) && isset($statsdata[$thisapplyedtype]["totalcount"])){
  if (! $statsdata[$thisapplyedtype]["Datadatatotal"] > "1"){ return "0";}
  if (! $statsdata[$thisapplyedtype]["totalcount"] > "1"){ return "0";}
  return($statsdata[$thisapplyedtype]["Datadatatotal"] / $statsdata[$thisapplyedtype]["totalcount"]);
 }else{
  return("N/A ");
 }
}
if ($thisdata=="totalnumoflostpings"){
 if (isset($statsdata[$thisapplyedtype]["Errorcount"])){
  return($statsdata[$thisapplyedtype]["Errorcount"]);
 }else{
  return("0");
 }
}
if ($thisdata=="percentageoflostpings"){
 if (isset($statsdata[$thisapplyedtype]["Errorcount"]) && isset($statsdata[$thisapplyedtype]["totalcount"])){
  if (! $statsdata[$thisapplyedtype]["Errorcount"] > "1"){ return "0";}
  if (! $statsdata[$thisapplyedtype]["totalcount"] > "1"){ return "0";}
  return($statsdata[$thisapplyedtype]["Errorcount"]/$statsdata[$thisapplyedtype]["totalcount"]*100);
 }else{
  return("0");
 }
}


/*
(
    [0] => Array
        (
        )

    [General] => Array
        (
            [Starttime] => 20180219_143209
        )

    [Placemarks_PingPrimary] => Array
        (
            [totalcount] => 74
            [Errorcount] => 74
            [Errordatatotal] => 7400
        )

    [Project_Info] => Array
        (
            [totalcount] => 5
            [PingPrimarycount] => 2
            [PingPrimarydatatotal] => 10163
            [PingSecondarycount] => 3
            [PingSecondarydatatotal] => 31351
        )

    [Placemarks_PingSecondary] => Array
        (
            [totalcount] => 90
            [Datacount] => 90
            [Datadatatotal] => 5090.95
        )

)
*/

#$statsdata[$thisapplyedtype]["totalcount"]++;
#$statsdata[$thisapplyedtype][$thistype."count"]++;
#$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
}








function fetchmetadata($thisapplyedtype,$thistype,$thisdata,$line,&$statsdata){
if ($thistype != "Error"){
/*
 $strt=htmlspecialchars("<![CDATA[");
 $t1=htmlspecialchars("<b>");
 $t2=htmlspecialchars("</b>");
 $t3=htmlspecialchars("<br />");
 $end=htmlspecialchars("]]>");
*/
 $strt="<![CDATA[";
 $t1="<b>";
 $t2="</b>";
 $t3="<br />";
 $end="]]>";
 //format $strst . $t1 (desc) $t2 (data) $t3 = [linereturn]  then "more ts and te and le untill metadata is closed with $end 
 if ($thisapplyedtype == "PingPrimary"){
  #08:33:14.070 127.0.0.1 !213317.597,3001.6900,S,15311.8651,E! 64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.017 ms
  $split=explode(" ",$line);
  $metadata= $strt.$t1."Time : ".$t2.$split[0].$t3.$t1."Target : ".$t2.$split[1].$t3.$t1."Ping : ".$t2.$thisdata." ms".$t3;

  #yet2do add average and count errors
  #$statsdata[$thisapplyedtype][$thistype."count"]++;
  #$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
  dbg("d","metadatstr = ".$metadata);
	########sleep(10);
  return($metadata);
 }
 if ($thisapplyedtype == "PingSecondary"){
  #08:33:14.070 127.0.0.1 !213317.597,3001.6900,S,15311.8651,E! 64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.017 ms
  $split=explode(" ",$line);
  $metadata= $strt.$t1."Time : ".$t2.$split[0].$t3.$t1."Target : ".$t2.$split[1].$t3.$t1."Ping : ".$t2.$thisdata." ms".$t3.$end;
  #yet2do add average and count errors
  #$statsdata[$thisapplyedtype][$thistype."count"]++;
  #$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
  dbg("d","metadatstr = ".$metadata);
########sleep(10);
  return($metadata);
 }

 if ($thisapplyedtype == "GPS"){
  #08:33:14.070,USB GPS
  $split=explode(",",$line);
  $metadata= $strt.$t1."Time : ".$t2.$split[0].$t3.$t1."GPS Type : ".$t2.$split[1].$t3.$end;
  #yet2do add average and count errors
  #$statsdata[$thisapplyedtype][$thistype."count"]++;
  #$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
  dbg("d","metadatstr = ".$metadata);
########sleep(10);
  return($metadata);
 }



 if ($thisapplyedtype == "BCC"){
  if ($thistype == "SNR"){
   #08:33:14.070 , Best SNR , 38 ,channel , freq 
   $split=explode(" ",$line);
   $metadata= $strt.$t1."Time : ".$t2.$split[0].$t3.$t1."Rating : ".$t2.$split[1].$t3.$t1."SNR Value : ".$t2.$thisdata.$t3.$t1."Channel : ".$t2.$split[1].$t3.$t1."Freq : ".$t2.$split[1].$t3;

   #yet2do add average and count errors
   #$statsdata[$thisapplyedtype][$thistype."count"]++;
   #$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
   dbg("d","metadatstr = ".$metadata);
   ########sleep(10);
   return($metadata);
  }
 }


}//if error
return ("");
} //eof





function fetchmetadata2($thisapplyedtype,$thistype,$thisdata,$line,&$statsdata){
if ($thistype != "Error"){
 $strt=htmlspecialchars("");
 $t1=htmlspecialchars("<b>");
 $t2=htmlspecialchars("</b>");
 $t3=htmlspecialchars("\n");          #"<br />");
 $end=htmlspecialchars("bro\n");
 //format $strst . $t1 (desc) $t2 (data) $t3 = [linereturn]  then "more ts and te and le untill metadata is closed with $end 
 if ($thisapplyedtype == "PingPrimary"){
  #08:33:14.070 127.0.0.1 !213317.597,3001.6900,S,15311.8651,E! 64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.017 ms
  $split=explode(" ",$line);
#  $metadata= htmlspecialchars($strt.$t1."Time : ".$t2.$split[0].$t3.$t1."Target : ".$t2.$split[1].$t3.$t1."Ping : ".$t2.$thisdata." ms".$t3.$end);
  $metadata= $strt."Time : ".$split[0].$t3."Target : ".$split[1].$t3."Ping : ".$thisdata." ms".$t3.$end;

  #yet2do add average and count errors
  #$statsdata[$thisapplyedtype][$thistype."count"]++;
  #$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
  dbg("d","metadatstr = ".$metadata);
  return($metadata);
 }
 if ($thisapplyedtype == "PingSecondary"){
  #08:33:14.070 127.0.0.1 !213317.597,3001.6900,S,15311.8651,E! 64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.017 ms
  $split=explode(" ",$line);
  $metadata= $strt."Time : ".$split[0].$t3."Target : ".$split[1].$t3."Ping : ".$thisdata." ms".$t3.$end;
  #yet2do add average and count errors
  #$statsdata[$thisapplyedtype][$thistype."count"]++;
  #$statsdata[$thisapplyedtype][$thistype."datatotal"]=$statsdata[$thisapplyedtype][$thistype."datatotal"]+$thisdata;
  dbg("d","metadatstr = ".$metadata);
  return($metadata);
 }


 if ($thisapplyedtype == "Bcc"){
#  $split=explode(" ",$line);
#  $metadata=$strt.$t1."Target : ".$t2.$split[1].$t3.$t1."Ping : ".$t2.$thisdata." ms".$t3,$end;
  dbg("d","metadatstr = ".$metadata);
 return($metadata);
 }


}//if error
return ("");
} //eof


function fetchstyle($thistype,$thisdata,$setkmlarray){
  dbg("d","fetchstyle start = ".$thistype.",".$thisdata);

if ($thistype=="Ping"){
/*
pm01styleurl00="data,=,lost"
pm01styleurl01="data,>,80"
pm01styleurl02="data,>,40"
pm01styleurl03="data,>,20"
pm01styleurl04="data,>,10"
pm01styleurl05="data,>,0"
pm01styleurl06= ....
pm01styleurl19=
*/
for ($t = 0;$t<20;$t++) {
 dbg("d","t = ".$t);
 if ($t < 10){$t='0'.$t;}
 dbg("d","t = ".$t);

 $tmp=explode(",",$setkmlarray['Ping']['pm01styleurl'.$t]);
 dbg("d","arrays = ".$tmp[0],"/".$tmp[1],"/".$tmp[2]);

 if (count($tmp) == 3){
  $cmd=$thisdata.$tmp[1].$tmp[2];
  dbg("d","inputtrueorfalse fuction call = ".$cmd);
  dbg("d","return inputtrueorfalse = ".inputtrueorfalse($thisdata,$tmp[1],$tmp[2]));
  if (inputtrueorfalse($thisdata,$tmp[1],$tmp[2])){
   $styletype='styleid_'.$t;
  dbg("d","styletype = ".$styletype);
   return($setkmlarray['Ping']["$styletype"]);
   #break;
  }
 }else{
  $styletype='maybe error yet2do error in _fetchstyle';
  dbg("d","Return style type = ".$styletype);
  return($styletype);
 }//endif
}//end for
}//end if 


if ($thistype=="SNR"){
/*
pm01styleurl06="data,==,0"  ;//this is the order of testing 01
pm01styleurl07="data,<=,8" ;//02
pm01styleurl08="data,<=,16" ;//03 ..
pm01styleurl09="data,<=,24"
pm01styleurl10="data,<=,32"
pm01styleurl11="data,>,32"
pm01styleurl12= ....
pm01styleurl13=
*/
for ($t = 0;$t<20;$t++) {
 dbg("d","t = ".$t);
 if ($t < 10){$t='0'.$t;}
 dbg("d","t = ".$t);

 $tmp=explode(",",$setkmlarray['Ping']['pm01styleurl'.$t]);
 dbg("d","arrays = ".$tmp[0],"/".$tmp[1],"/".$tmp[2]);

 if (count($tmp) == 3){
  $cmd=$thisdata.$tmp[1].$tmp[2];
  dbg("d","inputtrueorfalse fuction call = ".$cmd);
  dbg("d","return inputtrueorfalse = ".inputtrueorfalse($thisdata,$tmp[1],$tmp[2]));
  if (inputtrueorfalse($thisdata,$tmp[1],$tmp[2])){
   $styletype='styleid_'.$t;
  dbg("d","styletype = ".$styletype);
   return($setkmlarray['Ping']["$styletype"]);
   #break;
  }
 }else{
  $styletype='Error pm01styleur bad formatting';
  dbg("d","Return style type = ".$styletype);
  return($styletype);
 }
}
}//end if SNR


$styletype='no value from _fetchstyle';
return($styletype);
}



function inputtrueorfalse($v1,$compare,$v2){

if ($compare == "=" ){if ($v1 == $v2) {return True;}}
if ($compare == "==" ){if ($v1 == $v2) {return True;}}
if ($compare == "=>" ){if ($v1 >= $v2) {return True;}}
if ($compare == ">=" ){if ($v1 >= $v2) {return True;}}
if ($compare == "=<" ){if ($v1 <= $v2) {return True;}}
if ($compare == "<=" ){if ($v1 <= $v2) {return True;}}
if ($compare == "<" ){if ($v1 < $v2) {return True;}}
if ($compare == ">" ){if ($v1 > $v2) {return True;}}
if ($compare == "!=" ){if ($v1 != $v2) {return True;}}
return false;
}





function build_gpskml($scanned_directory,$setkmlarray,$directorypath){
	$tmpfilenumber=1;
	foreach ($scanned_directory as &$projfilename) {
		if (strstr($projfilename,"gps")){
			#could here export to GPXfile for ver2? maybe
			if ($tmpfilenumber == 1) { //first occurrance make a header
				#first start a new kml file
				$xml_kml_gps=<<<XML
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
</Document>
</kml>
XML;
				$x_k_gps = new SimpleXMLElement($xml_kml_gps);
				/*
				#[gps]
				#filenamecontainer="gps"   ;[unique txt from file name , dictakes format to check fields for]
				#outputfilename="gps_track.kml"
				#primaryfoldername="CC2KML"
				#primaryfolderdesc="Data collection tool . v 0.20180216"
				#secondaryfoldername="GPS track data"
				#secondaryfolderdesc="Collected GPS Data from target "


				#styleid_00=None
				#scale_00=.75
				#color_00=ff000000 ;//Red
				#iconref_00=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png
				*/


				/*
				Style id="redisbadStyle">
				<IconStyle>
				<scale>.75</scale>
				<color>ff000000</color>
				<Icon>
				<href>http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png</href>
				</Icon>
				</IconStyle>
				<BalloonStyle>
				<text>$[description]</text>
				</BalloonStyle>
				</Style>
				*/
				for ($t = 0;$t<6;$t++) {
					#$t=0;
					#dbg("d","t cycle =".$t);
					${'seq'.$t}=$x_k_gps->Document->addChild('Style');
					${'seq'.$t}->addAttribute('id',$setkmlarray['GPS']["styleid_0$t"]);
					#$x_k_gps->Document->Style->addChild('Style_id',$setkmlarray['GPS']["styleid_0$t"]);
					${'seq'.$t}->addChild('IconStyle');
					${'seq'.$t}->IconStyle->addChild('scale',$setkmlarray['GPS']["scale_0$t"]);
					${'seq'.$t}->IconStyle->addChild('color',$setkmlarray['GPS']["color_0$t"]);
					${'seq'.$t}->IconStyle->addChild('Icon',$setkmlarray['GPS']["iconref_0$t"]);
					//${'seq'.$t}->addChild('BalloonStyle');
					//${'seq'.$t}->BalloonStyle->addChild('text','$[description]');
				}
				$x_k_gps->Document->addChild('Folder');
				$x_k_gps->Document->Folder->addChild('open','1');
				$x_k_gps->Document->Folder->addChild('name', $setkmlarray['GPS']['primaryfoldername']);
				$x_k_gps->Document->Folder->addChild('description', $setkmlarray['GPS']['primaryfolderdesc']);

				if ($setkmlarray['GPS']["hideplacemarksintree"]="true"){
					dbg("d","hideplacemarksintree=true");

					// <Style id="check-hide-children">
					//      <ListStyle>
					//        <listItemType>checkHideChildren</listItemType>
					//      </ListStyle>
					//    </Style>
					//    <styleUrl>#check-hide-children</styleUrl>
					$x_k_gps->Document->Folder->addChild('Style');
					$x_k_gps->Document->Folder->Style->addAttribute('id','check-hide-children');
					$x_k_gps->Document->Folder->Style->addChild('ListStyle');
					$x_k_gps->Document->Folder->Style->ListStyle->addChild('listItemStyle','checkHideChildren');
					$x_k_gps->Document->Folder->Style->ListStyle->addChild('bgColor','00ffffff');
					$x_k_gps->Document->Folder->Style->ListStyle->addChild('maxSnippetLines','2');
					// if variabkles used , as below, created this error ...maybe hideen characters? Cannot add child. Parent is not a permanent member of the XML tree in /home/mst/localhost_html/cc2kml/cc2kml_maker.php on line 274
				}

				#<BalloonStyle>
				#<text>$[description]</text>
				#</BalloonStyle>
				
				//$x_k_gps->Document->folder->BalloonStyle->text = "$[description]";
				#$x_k_gps->Document->folder->addChild('folder');  #2nd folder 
				#$x_k_gps->Document->folder->folder->addChild('name', $setkmlarray['GPS']['secondaryfoldername']);
				#$x_k_gps->Document->folder->folder->addChild('description', $setkmlarray['GPS']['secondaryfolderdesc']);
				$headercompleted="done";
			}//endif $tmpfilenumber
			$tmpfilenumber++;
			//
			// start populating the placemarks
			//
			dbg("d","final scanned_directory/projfilename =$directorypath."/".$projfilename");
			$handle = fopen($directorypath."/".$projfilename, "r");
			if ($handle) {
				while (($line = fgets($handle)) !== false) {
					// process the line read.		
					//08:33:11.987 ttyUSB0 (72) $GPRMC,213315.597,A,3001.6899,S,15311.8652,E,000.0,000.0,310118,,,A*77
					if (strpos($line,$setkmlarray['GPS']['pm01validkeyword'])){

						//if line contains key word
						$fields=explode($setkmlarray['GPS']['pm01primaryseperator'],$line);
						//explode the line
						/*
						pm01ifkeyword="$GPRM"
						pm01primaryseperator=","
						pmo1metadataseperator=""
						pmo1coorddataseperator=""
						pm01placemarkname="GPS go"
						*/
						//<description><![CDATA[<b>Name: </b>BMACVMTR050RBC01<br /><b>MAC: </b>00:30:1a:46:04:9b<br /><b>Radio no: </b>wlan0<br /><b>Modulation: </b>1<br /><b>SNR: </b>102<br /><b>Cost: </b>400504<br /><b>Date: </b>21/05/2015<br /><b>Time: </b>0929.4100<br /><b>Longitude: </b>148.0609<br /><b>Latitude: </b>-22.157045<br /><b>Altitude: </b>252 m<br /><b>Suplimentry Data: </b>wlan3 5800 MHz 160 19-wlan2 2462 MHz 11 28-wlan2 2462 MHz 11 42-wlan0 922 MHz 7 56-wlan0 922 MHz 7 64-wlan0 922 MHz 7 102-<br /><br />]]></description>	<styleUrl>#greenisgoodStyle</styleUrl>
						$tmp=$x_k_gps->Document->Folder->addChild('Placemark');
						$tmp->addChild('TimeStamp');
						$tmp->addChild('when',datetime2kml($projfilename,$fields[0]));					
						$tmp->addChild('styleUrl',"#".$setkmlarray['GPS']['pm01placemarkname']);
						$tmp->addChild('Point');
						$tmp->Point->addChild('coordinates',nema2kml($fields[3].",".$fields[4].",".$fields[5].",".$fields[6],"0","1"));
						#$tmp->Point->addChild('coordinates',nema2kml($fields[5].",".$fields[6].",".$fields[3].",".$fields[4],"0","1"));
						#dbg("d",$fields[5].",".$fields[6].",".$fields[3].",".$fields[4]);
						#sleep(1);
						#swapped lat long remember?
					}//if line has a keyword
				}//endwhile
				fclose($handle);			
			} else {
						// error opening the file.
			} //end handle
			
	
				//    <Placemark>
				//      <TimeStamp>
				//        <when>2007-01-14T21:05:02Z</when>
				//      </TimeStamp>
				//      <styleUrl>#paddle-a</styleUrl>
				//      <Point>
				//        <coordinates>-122.536226,37.86047,0</coordinates>
				//      </Point>
				//    </Placemark>
		}//endif if file is a gps file
	}//endif finding a file 
	if ($headercompleted="done"){
		$x_k_gps->asXML();
		#this code preserves original indented formating ... why its not automatic i dunno
		$dom = new DOMDocument("1.0");
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($x_k_gps->asXML());
		// Saving the XML to filename
		$tmp=$directorypath."/".$setkmlarray['GPS']['outputsubdir']."/".$setkmlarray['GPS']['outputfilename'];
		dbg("d","output dir/file = ".$tmp);
		checknmake($directorypath."/".$setkmlarray['GPS']['outputsubdir']);
		$test=$dom->saveXML();
		$dom->save($tmp);
		#$dom->saveXML();
		#######sleep(60);
	}
}

function checknmake($dir){
if (!file_exists($dir)) {
    mkdir($dir, 0777, true);
}
}

function nema2kml($fieldsX4,$data = null ,$datamultiplier = null){
if (null === $data) { $data = 0;}
if (null === $datamultiplier) {$datamultiplier = 1;}

//changes the format for kml insertion
//3001.6880,S,15311.8628,E
// to
//<coordinates>-122.536226,37.86047,0</coordinates>
dbg("d","nema2kml args =".$fieldsX4."/".$data."/".$datamultiplier);
#####sleep(1);
$tmp=explode(",",$fieldsX4);
if (count($tmp) == 5 ){
 $tmp=explode(",",$fieldsX4);
 $fieldsX4=$tmp[1].",".$tmp[2].",".$tmp[3].",".$tmp[4];
 $tmp=explode(",",$fieldsX4);
 dbg("d","trimmed fields to 4 in nema3kml =".$fieldsX4);
}



if (count($tmp) < 4 ){
	return"error wrong no of paramters from nema fields";
}else{
 $t=explode(".",$tmp[0]);
 if (strlen($t[0]) == 4){
  $d1=substr($t[0],0,2);
  $m1=(substr($t[0],-2).".".$t[1])/60;
  $d1=$d1+$m1;
  if (strtoupper($tmp[1]) =="S" || strtoupper($tmp[1]) =="W"){
   $d1=$d1*-1;
  } 
 }else{
  if (strlen($t[0]) == 5){
   $d1=substr($t[0],0,3);
   $m1=(substr($t[0],-2).".".$t[1])/60;
   $d1=$d1+$m1;
   if (strtoupper($tmp[1]) =="S" || strtoupper($tmp[1]) =="W"){
    $d1=$d1*-1;
   }
  }
 }
 $t=explode(".",$tmp[2]);
 if (strlen($t[0]) == 4){
  $d2=substr($t[0],0,2);
  $m2=(substr($t[0],-2).".".$t[1])/60;
  $d2=$d2+$m2;
  if (strtoupper($tmp[3]) =="S" || strtoupper($tmp[3]) =="W"){
   $d2=$d2*-1;
  }
 }else{
 if (strlen($t[0]) == 5){
   $d2=substr($t[0],0,3);
   $m2=(substr($t[0],-2).".".$t[1])/60;
   $d2=$d2+$m2;
   if (strtoupper($tmp[3]) =="S" || strtoupper($tmp[3]) =="W"){
    $d2=$d2*-1;
   } 
  }
 }
 dbg("d","nema2kml retn =".$d2.",".$d1.",0");
 //yet2do precision decc error?
if (! $data == ""){
 if ($data == "100% packet loss"){$data="1000";}
 if (! $datamultiplier == ""){
  $data=$data*$datamultiplier;
 }else{
  #$data=$data
 }
}else{
$data=0;
}
 return($d2.",".$d1.",".$data);
}
}

/*
function getDD2DMS(dms, type){

    var sign = 1, Abs=0;
    var days, minutes, secounds, direction;

    if(dms < 0)  { sign = -1; }
    Abs = Math.abs( Math.round(dms * 1000000.));
    //Math.round is used to eliminate the small error caused by rounding in the computer:
    //e.g. 0.2 is not the same as 0.20000000000284
    //Error checks
    if(type == "lat" && Abs > (90 * 1000000)){
        //alert(" Degrees Latitude must be in the range of -90. to 90. ");
        return false;
    } else if(type == "lon" && Abs > (180 * 1000000)){
        //alert(" Degrees Longitude must be in the range of -180 to 180. ");
        return false;
    }

    days = Math.floor(Abs / 1000000);
    minutes = Math.floor(((Abs/1000000) - days) * 60);
    secounds = ( Math.floor((( ((Abs/1000000) - days) * 60) - minutes) * 100000) *60/100000 ).toFixed();
    days = days * sign;
    if(type == 'lat') direction = days<0 ? 'S' : 'N';
    if(type == 'lon') direction = days<0 ? 'W' : 'E';
    //else return value     
    return (days * sign) + 'º ' + minutes + "' " + secounds + "'' " + direction;
}
alert(getDD2DMS(-8.68388888888889, 'lon'));

*/


function datetime2kml($f,$t){
//changes the format for kml insertion
//201802010833_gps.log","08:33:24.041 ttyUSB0 (72) $GPRMC
//to
//2007-01-14T21:05:02Z
$ret=substr($f,0,4)."-".substr($f,6,2)."-".substr($f,4,2)."T".substr($t,0,8)."Z";
dbg("d","datetime2kml args =".$f." ".$t);
dbg("d","datetime2kml  rtn =".$ret);
return ($ret);
}

function s(&$m,$t){
return($m.$t);
}





function dirtoarray($dir){
#dir to array minus . and ..
#$GLOBALS["scanned_directory"] = array_diff(scandir($dir), array('..', '.'));
$scandir = array_diff(scandir($dir), array('..', '.'));
#print_r($scandir);
return($scandir);
}





function setdefaults($filename){
#yet2do
};//end of func setdefaults


function readkmlset($filename){
//KMLSET
//read the ini file for the info to make the kml
//.... ini file contents...........
//IP_1_start=10.36.61.1
//IP_1_end=10.36.62.254
//IPlist=("10.36.61.1" "10.36.61.2")
//etc

if ( !file_exists($filename) ) {
	dbg("d","file not found $filename");
	$filename="/home/mst/localhost_html/cc2kml/kmlset_default.ini";
	dbg("d","using instead the default file $filename");
	if ( !file_exists($filename) ) {
		dbg("d","default file not found $filename");
		setdefaults($filename);
		dbg("d","created new default file $filename");
	}
}else{
	dbg("d","file found , using file $filename");
}
##print_r(parse_ini_file($filename,true));
#parse_ini_file($filename,true);
return parse_ini_file($filename,true);


/*
#old code read 1 line at a time 
$lines = file($filename); //file location read into $lines array
dbg("d","line[0]=".trim($lines[0]));
dbg("d","line[1]=".trim($lines[1]));
dbg("d","line[2]=".trim($lines[2]));

foreach ($lines as $line_num => $line){ //read variables from the $lines array
 $line = explode("=",$line);
 $varname = trim($line[0]);   
 //ie OutputFileName=Whatever
 #echo $varname.chr(10); //varname
 global $varname;
 if (! $line[1]=="") $$varname =trim( $line[1]); 
 #echo $$varname.chr(10); //var val
 ##sleepq(1);
} //end for each
*/

}//end of func readkmlset











///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DBG
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function dbg($type,$d1=""){
/*
valid types=
b = breadcrumb
c = changes
d = database
e = errors
f = files
g = general
k = kmls
o = other

$debuglevel 0 = G for general
$debuglevel 1 = E only  "errors"
$debuglevel 2 = D for debug
$debuglevel none = silent
*/


if ( $GLOBALS["debuglevel"]==""){
		#echo date("Ymd_His")."[$type] $d1 ".chr(10);
		#do nuthin
}else{
$type=strtoupper($type);
switch ($type){
	case "G": //general output
	if ($GLOBALS["debuglevel"]=="0") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	if ($GLOBALS["debuglevel"]=="1") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	if ($GLOBALS["debuglevel"]=="2") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	break;
	case "E": //error entries and queries
	if ($GLOBALS["debuglevel"]=="1") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	if ($GLOBALS["debuglevel"]=="2") echo date("Ymd_His")."[$type] $d1 ".chr(10);
	break;
	case "D":  //debug 
		if ($GLOBALS["debuglevel"]=="2") echo date("Ymd_His")."[$type] $d1 ".chr(10);
		break;
	default: // otherwise print/echo it the thing
		echo date("Ymd_His")."[$type] $d1 ".chr(10); 
		break;
	
} //end switch

}//end if
}//end function

	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//TIDYFILES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function tidyfiles(){ //yet2do trim databse and log files
databasetrim("peers","3");#3
databasetrim("bcdata","3");#3
databasetrim("admin","180");#180
databasetrim("bcchanges","60");#60
databasetrim("ipstatus","3");#3
archiveKML("7");#60
} //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FIXPOSFORGOOGLEEARTH
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function FixPosForGoogleEarth($oldval){
/*	
_gps_gpsPos_gpsLat="2108.8873S"  //if S then thats southern hemisphere so we add a - negative
we use these numbers from the string '08.8873' and devide by 60 = .148121666666 , and we drop off more than 6 places to get .148121
it becomes 21.148121 then we drop the s and add a negative for southern hemispheere
_gps_gpsPos_gpsLat="-21.148121"  //if S then thats southern hemisphere so we add a - negative

_gps_gpsPos_gpsLong="14911.2502E" //if W then thats west of GMT so we add a - negative
_gps_gpsPos_gpsLong="149 AND .  AND 11.2502 / 60 "  //here we just need to get rid of the E for east
_gps_gpsPos_gpsLong="149.187391"

_gps_gpsPos_gpsPrecisionH=1.2

*/
//ie 2108.8873S  = $oldval
echo $oldval.chr(10);
$gpsarray=explode(chr(46),strval($oldval));  //split at the decimal  ie 2108 and 8873S chr46 = .
#print_r($gpsarray);
$DecMax=substr($gpsarray[0],0,strlen($gpsarray[0])-2);  //get the beggining of the dec whole numbers minus 2 numbers from the end  ie 21
echo $DecMax.chr(10);
$DecPlus=substr($gpsarray[0],-2); // get the decimal val to ad to the decimal places ie 08 
echo $DecPlus.chr(10);
$hemiID=substr($gpsarray[1],-1); // get the hemisphere id ie S is south
echo $hemiID.chr(10);
$decimal=substr($gpsarray[1],0,strlen($gpsarray[1])-1);  //get the beggining of the deimal minus the S ie 8873
echo $decimal.chr(10);
$decimal=$DecPlus.".".$decimal;  //put our decimal back together  ie 08.8873
echo $decimal.chr(10);
$decimal=floatval($decimal)/60;  //divide by 60 to get the google earth compatible decimal value
echo $decimal.chr(10);
$decimal= round($decimal,6);  //round the result to 6 decimal places
echo $decimal.chr(10);

if (strtoupper($hemiID) == "S"){
	$FinalVal=$DecMax+$decimal; //add the - if required
	$FinalVal= 0-$FinalVal;
}else{
	if (strtoupper($hemiID) == "W"){
		$FinalVal=$DecMax+$decimal; //add the - if required
		$FinalVal= 0-$FinalVal;
	}else{
		$FinalVal=$DecMax+$decimal; //otherwise just add the string back together
	}
}
echo $oldval.chr(10).$FinalVal;
#########sleep(15);
dbg("k","convertered for GE $oldval to $FinalVal");
return $FinalVal;
	
}  //end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//PLACENAME  //returns the shortened name and the type of placemark from the ini file attribrutes
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function placename($namestr){
$returntype="";	
//recieves name  , translate new name and returns also type via csv
//gp1_filter_replace='BMACVMTR','TR'.'Trailers':'MACVMJS','',Infrastructure:
#echo $GLOBALS[gp1_filter_replace].chr(10);
$search4array=split(":",$GLOBALS[gp1_filter_replace]);  //search for criteria
for ($x=0;$x<sizeof($search4array);$x++){ //autoincrement through the array to the maximimnumber of elements counter 
	#echo $search4array[$x]." ";
	#########sleep(1);
	$miniA=explode(",",$search4array[$x]) ;
	if (stripos($namestr,$miniA[0],0) ){
		$namestr=str_ireplace($miniA[0],$miniA[1],$namestr );
		if ($miniA[2] <> "" ) $returntype= $miniA[2];
	} //end if
}//end for
#echo $namestr.",".$returntype.chr(10);
#########sleep(5);
return $namestr.",".$returntype;

}//end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//zipkmz   make a kmz file and put it in /archives
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function zipkmz($s){
//$s=sitename


$file = $s.".kmz";
dbg("f","KMZ site name =" . $file);
dbg("f","KMZ ini system user name =" . $GLOBALS["linuxsytemfileusername"]);
dbg("f","KMZ linux user name =" . get_current_user());

$zip = new ZipArchive();


if (unlink($file)) dbg("f","zipkmz deleted ".$file. " "); // delete the kmz file if it exists

if ($zip->open($file, ZIPARCHIVE::CREATE)!==TRUE) {
dbg("e","zipkmz Error - cannot open new zip file - check zip librarys are installed in Yast 'Zlib' and 'PHP5-Zip' ".$file);
exit("cannot open <$file>\n");
}

if (checkfilefirst("kml","active.kml",get_current_user()) != "OK"){
	dbg("e","zipkmz Error - cannot read active.kml in kml directory  - check directory exists and permissions for ".get_current_user());
}else{
$zip->addFile('kml/active.kml', 'doc.kml');
}	

###########add icons;
if($zip->addEmptyDir('icons')) {
       	dbg("f","zipkmz icons directory inserted into zip");
} else {
       	dbg("e","zipkmz icons directory error, not inserted into zip");
}

	
$path    = 'kml/icons';
$files = scandir($path);
#print_r($files);
for ($x=1;$x<sizeof($files);$x++){ //autoincrement through from no2 of the array of files names to the maximimnumber of elements counter 
	if (($files[$x]<>".") and ($files[$x]<>"..")) {
		if (checkfilefirst("$path",$files[$x],get_current_user()) == "OK"){ //checks ownership permissiions etc
			IF ($zip->addFile("kml/icons/".$files[$x], "icons/".$files[$x])) { //add files to archive
				dbg("f","zipkmz Created file in ZIP icons/'".$files[$x]);
			} else {
				dbg("e","zipkmz Failed to add to ZIP archive in ZIP icons/'".$files[$x]);
			}
		}
	}//end if files`	
} //end for x

##########add logs;
if($zip->addEmptyDir('logs')) {
       	dbg("f","zipkmz logs directory inserted into zip");
} else {
      	dbg("e","zipkmz logs directory error, not inserted into zip");
}
$path = 'logs';
$files = scandir($path);
#print_r($files);
for ($x=1;$x<sizeof($files);$x++){ //autoincrement through from no2 the array of files names to the maximimnumber of elements counter 
	if (($files[$x]<>".") and ($files[$x]<>"..")) {
		if (checkfilefirst("$path",$files[$x],get_current_user()) == "OK"){ //checks ownership permissiions etc
			IF ($zip->addFile("logs/".$files[$x], "logs/".$files[$x])) {  //add files to archive
				dbg("f","zipkmz Created file in ZIP logs/'".$files[$x]);
			} else {
				dbg("e","zipkmz Failed to add to ZIP archive in ZIP logs/'".$files[$x]);
			}
		}	
	} // end if files
} //end for x

$zip->close();

if (! is_readable($file)) dbg("e","zipkmz Error - cannot read new zip file - check zip librarys are installed in Yast 'Zlib' and 'PHP5-Zip' ".$file);
if (is_readable($file)) dbg("e","zipkmz New zip filereadable ".$file);
		
		
if (!is_dir('archives')) {
    mkdir('archives',0755); //make archives with permision level 0755
}

//create the archive with date
if (Copy($s.".kmz","archives/".$s."_".date("Ymd_His").".kmz")) {
	dbg("f","zipkmz Created file in archives/".$s."_".date("Ymd_His").".kmz");
} else {
	dbg("e","zipkmz Error could not create file in archives/".$s."_".date("Ymd_His").".kmz");
}

//create the last active kmz for network limking to GE
if (Copy($s.".kmz","archives/".$s."_LastActiveCopy.kmz")) {
	dbg("f","zipkmz Created file in archives/".$s."_LastActiveCopy.kmz");
} else {
	dbg("e","zipkmz Error could not create file in archives/".$s."_LastActiveCopy.kmz");
}
dbg("f","zipkmz end function");
} // end funtion zipkmz


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//checkfilefirst    checks the directory exists [makes if it not , check the file in the directory and write permissions and the owner of the file and checks to be readable , created to minimise errors in dev and production environments 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function checkfilefirst($d,$f,$o){  //$d = directory is made if not exist, $f=file name or blank to just check the directory  , $o = owner
 // owner will be the user/group the PHP script is run under
 //had to write this for zip files containing bad permissioned ziiped files causing grief during ftp
 dbg("f","checkfilefirst inputs d=" . $d." f=".$f. " o=".$o);
 if ($d!="") $d=$d."/";
 dbg("f","checkfilefirst modified input if d not ='' inputs d=" . $d." f=".$f. " o=".$o);
 if ( (!file_exists($d)) AND ($d!="")) {  // if directory does not exist make it AND THE DIRECTORY FIELD IS NOT BLANK MEANING NOT OUR CURRENT DIREECTOR
     dbg("f","checkfilefirst directory does not exist , making it now" . $d." ".$f. " ".$o);
	 $oldmask = umask(0);  // helpful when used in linux server //dunno what this is  i cutnpasted  	
     mkdir ($d, 0755);  //directory made
     dbg("f","checkfilefirst directory made" .$d." ".getcwd());
	 $returnval = "OK";
}else{  //directory exists check for acces via writing a temp file
	dbg("f","checkfilefirst checking file write access to directory".$d." by ".$f." in CWD ".getcwd());
	if (! file_put_contents ($d.'test.txt', 'Test for access to the file system')){
	    dbg("f","checkfilefirst non fatal error - file write access NOT allowed to directory ".$d." in CWD ".getcwd());
		$returnval="Error - file write access not allowed to directory ".$d." in CWD ".getcwd();
	}else{ //cool we have a directory and write access
		dbg("f","checkfilefirst write access allowed ".$d." in CWD ".getcwd());
		unlink($d.'test.txt'); //now delete the temp file we just made	
	    dbg("f","checkfilefirst temp file deleted - file write access allowed to directory ".$d." in CWD ".getcwd());
		if ($f != "" ){ //if a file check is required due to the file name is given  we test it otherwise we are done with the matching else statement
			if (! file_exists($d.$f)) { //check it exists
			    dbg("f","checkfilefirst Error - file does not exist ".$f." in " .$d." in CWD ".getcwd());
				$returnval="Error - file does not exist ".$f." in CWD ".getcwd();
			}else{ //cool it exists
				dbg("f","checkfilefirst file exists ".$f." in " .$d." in CWD ".getcwd());
				if (! chown($d.$f,$o)) { //check we are the owner
					dbg("f","checkfilefirst Error - could not change owner in ".$f." in " .$d." in CWD ".getcwd());
					$returnval="Error - could not change owner in ".$f." in CWD ".getcwd();
				}else{ //cool we are the owner
					dbg("f","checkfilefirst owner rights OK ".$f." in " .$d." in CWD ".getcwd());
					if (! chmod($d.$f,0755)) { //check the permissions
						dbg("f","checkfilefirst Error-permissions set failed ".$f." in " .$d." in CWD ".getcwd());
						$returnval="Error - could not change permissions in ".$f." in CWD ".getcwd();
					}else{ //cool permissions set was ok
						dbg("f","checkfilefirst permission set OK ".$f." in " .$d." in CWD ".getcwd());
						if (! is_readable($d.$f)){  //check if readable
							dbg("f","checkfilefirst Error - file not readable ".$f." in " .$d." in CWD ".getcwd());
							$returnval="Error - file not readable ".$f." in CWD ".getcwd();
						}else{ //cool everthing is good
							dbg("f","checkfilefirst -file readable OK ".$f." in " .$d." in CWD ".getcwd());
							$returnval="OK";
						}
					}	
				}
			}
		}else{
			dbg("f","checkfilefirst file name not given skipped filename checks ".$f." in " .$d." ".getcwd());
			$returnval="OK";
		}
	}
}
dbg("f","checkfilefirst return value =".$returnval." for these inputs ".$f." in " .$d." ".getcwd());
return $returnval;
}//end function checkfilefirst

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Calculates the great-circle distance between two points, with
 * the Haversine formula.
 * @param float $latitudeFrom Latitude of start point in [deg decimal]
 * @param float $longitudeFrom Longitude of start point in [deg decimal]
 * @param float $latitudeTo Latitude of target point in [deg decimal]
 * @param float $longitudeTo Longitude of target point in [deg decimal]
 * @param float $earthRadius Mean earth radius in [m]
 * @return float Distance between points in [m] (same as earthRadius)
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function distance($lat1, $lon1, $lat2, $lon2, $unit) {

  $theta = $lon1 - $lon2;
  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  $dist = acos($dist);
  $dist = rad2deg($dist);
  $miles = $dist * 60 * 1.1515;
  $unit = strtoupper($unit);

  if ($unit == "K") {
      return ($miles * 1.609344);
  } else if ($unit == "N") {
      return ($miles * 0.8684);
  } else {
      return $miles;
  }

}  //end function
////////////////////////////////////////////////////////////////////////////////////////////////////////////////










/*
< kmlset_default_ping.ini >

[General]
debuglevel=0 //none|0|1|2
timezone=local
outputdir=kmlz
outputfilename=settings.txt
kmltype=timeslider    //timeslider|placemarksblank|path|multipath


[fileoperators]
filenamecontainer=ping   [from file name , dictakes format to check fields for]


//filenamecontainer=bcc   [from file name , dictakes format to check fields for]
//bccgseperator01=space
//bccseperator02=!

[statscollection]


//08:33:09.115 127.0.0.1 !112113.027,3001.6701,S,15311.8400,E! rtt min/avg/max/mdev = 0.025/0.025/0.025/0.000 ms
//Average of all successfull pings
stats01ifkeyword=min/avg/max/mdev
stats01primaryseperator=space
stats01metadataseperator=/
stats01description=metadata
stats01metadatafields=f7[f2]  //fields from string
stats01metadata_f7=Average time of successful pings:  

//08:33:30.602 192.168.1.101 !213333.597,3001.6896,S,15311.8644,E! 1 packets transmitted, 0 received, +1 errors, 100% packet loss, time 0ms
//Total of failed pings
stats02ifkeyword=100%
stats02primaryseperator=space
stats02metadataseperator=/
stats02description=metadata
stats02metadatafields=  //fields from string
stats02metadata_=Total number of unsuccessful pings:  


//08:33:09.115 127.0.0.1 !112113.027,3001.6701,S,15311.8400,E! rtt min/avg/max/mdev = 0.025/0.025/0.025/0.000 ms
//stats comment
stats03ifkeyword=any
stats03primaryseperator=space
stats03metadataseperator=/
stats03description=Statistics test text only

//08:33:09.115 127.0.0.1 !112113.027,3001.6701,S,15311.8400,E! rtt min/avg/max/mdev = 0.025/0.025/0.025/0.000 ms
//Average total all failed pings overall
stats01ifkeyword=100%
stats01primaryseperator=space
stats01metadataseperator=/
stats01description=metadata
stats01metadatafields=  //fields from string
stats01metadata_f7=Average % of failed pings from sample:  



[kmlspecifics]
outputfilename=test.kml
documentname=collected test data
primaryheadername=CC2KML
primarheaderdesc=Data collection tool
secondaryheadername=Ping Data
secondaryheaderdesc=From vehicle


[kmlstyles]
styleid_00=None
scale_00=.75
color_00=ff000000 //Red
iconref_00=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png

styleid_01=VeryPoor
scale_01=.75
color_01=ffff0014  //orange
iconref_01=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png

styleid_02=Poor
scale_02=.75
color_02=ffff7814  //yellow
iconref_02=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png

styleid_03=Good
scale_03=.75
color_03=ffff7814  //darkgreen
iconref_03=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png

styleid_04=VeryGood
scale_04=.75
color_04=fff00ff55 //mediumgreen
iconref_04=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png

styleid_05=Excellent
scale_05=.75
color_05=fff00ff55 //brightgreen
iconref_05=http://maps.google.com/mapfiles/kml/shapes/shaded_dot.png



[placemarks]
//08:33:30.602 192.168.1.101 !213333.597,3001.6896,S,15311.8644,E! 1 packets transmitted, 0 received, +1 errors, 100% packet loss, time 0ms
pm01ifkeyword=100%
pm01primaryseperator=space
pmo1metadataseperator=/
pmo1coorddataseperator=,
pm01placemarkname=
pm01description=metadata
pm01metadatafields=f1,f2  //fields from string
pm01metadata_f2=IpDest: 
pm01metadata_f1=DateTime: 
pm01metadata_=Time: 100% Packet Loss
pm01metadata_f0=Data: 
pm01styleurl00=f0~100%
pm01coordssource=same  //same/file
pm01coords=f3[f2,f3,f4,f5]  //example field2 [then subdata f3andf4]

//08:33:09.115 127.0.0.1 !112113.027,3001.6701,S,15311.8400,E! rtt min/avg/max/mdev = 0.025/0.025/0.025/0.000 ms
pm02ifkeyword=min/avg/max/mdev
pm02primaryseperator=space
pmo2metadataseperator=/
pmo2coorddataseperator=,
pm02placemarkname=
pm02description=metadata
pm02metadatafields=f1,f2,f7[f2]  //fields from string
pm02metadata_f2=IpDest: 
pm02metadata_f1=DateTime: 
pm02metadata_f7=Time ms:  
pm02styleurl00=f7~None
pm02styleurl01=f7>160
pm02styleurl02=f7>80
pm02styleurl03=f7>40
pm02styleurl04=f7>20
pm02styleurl05=f7>0
pm02coordssource=same  //same/file
pm02coords=f3[f2,f3,f4,f5]  //example field2 [then subdata f3andf4]


*/















?>

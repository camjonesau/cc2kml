#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |tr '\n' ' '|sed 's/[0-9][0-9]:[0-9][0-9]:/\'$'\n&/g'|grep -E  'gps|mac'>logwatch1.txt
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |awk '{ printf "%s,",$0 }'
echo ping destination is $1
echo ping pipe file is $2
rm $2
mkfifo $2
#rm ping1tail
#mkfifo ping1tail
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all >"$(date "+%Y%m%d%H%M")_bccl.log"

echo now pinging to $dodgeip>t.txt
sleep 10
#bash readfifo_ping1.sh
echo $dodgeip >a.txt

while :
do
tmp=$(<gps)
echo now pinging to $tmp>>t.txt

echo "now pinging to "$tmp>>a.txt
echo $tmp >>a.txt
ping -c 1 -W 1 $tmp | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$tmp' {}'|grep -E 'ms'|tee $2 

sleep 0.8


done

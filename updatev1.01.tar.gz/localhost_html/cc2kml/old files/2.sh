#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |tr '\n' ' '|sed 's/[0-9][0-9]:[0-9][0-9]:/\'$'\n&/g'|grep -E  'gps|mac'>logwatch1.txt
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |awk '{ printf "%s,",$0 }'
echo started bccl.sh
echo user is $USER
#rm bcclp
echo $PPID
echo projectname is $1
#mkfifo bcclp
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all >"$(date "+%Y%m%d%H%M")_bccl.log"

#echo starting bcc11
#/bin/sh /opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all >bcclp | grep -e 'gps' -e 'mac:' -e 'macs:' -e 'gpsLat:' -e 'gpsLong:'

# ping -c 1 -t 1 -w 1 $1 | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'"$tmp"'! {}'|grep -E 'ms'|tee $2 
ping -c 10 -t 1 -w 1 $1 | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'""'! {}'|grep -E 'ms' 

echo end of bccl.sh

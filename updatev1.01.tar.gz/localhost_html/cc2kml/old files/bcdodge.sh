
startping1apps(){
(. ./bccdodgeping.sh "$dodgeip" ping1 | sed -e 's/^/[ping1.    ] /'| grep -e 100% &)
(./bccpipe_read.sh "$projname" ping1| sed -e 's/^/[ping1.read] /' &)
}


valid_ip()
{
# Check if IP format is num.num.num.num / num between 0..255
if [ "$(sipcalc $1 | grep ERR)" != "" ]; then
#echo "ip incorrect"
return 1
fi
#echo "ip correct"
return 0
}


echo starting bcc_bullshit.sh
echo user is $USER
echo $PPID
echo $PID

pkill -f -c bcc

echo $PID>lastbccpid.txt
trap 'kill %1; kill %2' SIGINT

echo New [n] or Continue [c] with existing project?
read type
if [ $type == 'n' ] ; then
 echo $type
 echo Enter project name
 read projname
 echo project is "$projname"
 if [ ! -d "$projname" ] ; then
	mkdir "$projname"
 else
	clear
	echo directory ["$projname"] exists , delete directory [y/n]  all contents will be lost forever!
 	read deletedir 
	if [ $deletedir == 'y' ] ; then
		rm -rf "$projname"
	else
 		exit
	fi
 fi
 mkdir "$projname"
 projdir=$PWD"/""$projname"
 echo project directory is "$projdir"
else
 clear
 ls -d */
 echo the above project directories are listed, type in the name of the project you want to continue.
 read projname
 echo project is "$projname"
 if [ -d "$projname" ] ; then
	echo good project name "$projname"
 else
	clear
	echo directory ["$projname"] does not exist exists exiting now
	sleep 3
	exit
 fi
fi


export dodgeip="9.9.9.9"



startping1apps




echo CTRL/C to exit , restart app if errors as suspected 


while true; do
sleep 3
export dodgeip="8.8.8.8"
echo $dodgeip>gps

sleep 3
export dodgeip="9.9.9.9"
echo $dodgeip>gps
done 

trap - SIGINT
echo end of bc_controller.sh

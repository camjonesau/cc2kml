#!bin/sh
LOGNAME="$(date "+%Y%m%d%H%M")_ping1.log"
echo first file now writing to $LOGNAME
while :
do
  read poo < ping1
  LOGNAME="$(date "+%Y%m%d%H%M")_ping1.log"
  printf "%s\n" "$poo" >> "$LOGNAME"
done < ping1

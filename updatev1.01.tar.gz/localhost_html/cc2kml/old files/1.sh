#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |tr '\n' ' '|sed 's/[0-9][0-9]:[0-9][0-9]:/\'$'\n&/g'|grep -E  'gps|mac'>logwatch1.txt
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all |awk '{ printf "%s,",$0 }'
echo started bccl.sh
echo user is $USER
#rm bcclp
echo $PPID
#echo projectname is $1
#mkfifo bcclp
#/opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all >"$(date "+%Y%m%d%H%M")_bccl.log"

#echo starting bcc11
#/bin/sh /opt/bcc11/bcc11 -u co -p breadcrumb-co -c -l all >bcclp | grep -e 'gps' -e 'mac:' -e 'macs:' -e 'gpsLat:' -e 'gpsLong:'

# ping -c 1 -t 1 -w 1 $1 | xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'"$tmp"'! {}'|grep -E 'ms'|tee $2 

#LOGNAME="$(date "+%Y%m%d%H%M")_"$pipefilename".log"
#printf "%s\n" "$pipereadline" >> "$projname"/"$LOGNAME"

#this line good but if not host does not show error due to grep only showing ms
#stdbuf -o0 ping -c 300 -W 1 $1 |stdbuf -o0 xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'""'! {}'|stdbuf -o0 grep -E 'ms'|while read line; do echo $line|tee -a 

##############ping worked ok but buffers 3 retries when no host found
#no buffering output<ping options host>| xarg prefixs date/time and host[$1] and soon !'"GPS"'! lonlats|read 1 line at a time|echo into Tee appends to file which #worksaround  buffering and not tee writing to only 1 file
###stdbuf -o0 ping -c 300 -W 1 $1 |stdbuf -o0 xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'""'! {}'|while read line; do echo $line|tee -a "crap/$(date "+%Y%m%d%H%M")_"$pipefilename".log"; done

##############Fping worked but not every line get timestamp
#no buffering output<Fping options host>| xarg prefixs date/time and host[$1] and soon !'"GPS"'! lonlats|read 1 line at a time|echo into Tee appends to file which #worksaround  buffering and not tee writing to only 1 file
stdbuf -o0 fping -l -r 0 -Q 1 -t1000 $1 |stdbuf -o0 xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'""'! {}'|while read line; do echo $line|tee -a "crap/$(date "+%Y%m%d%H%M")_"$pipefilename".log"; done


#no buffering output<Fping options host>| xarg prefixs date/time and host[$1] and soon !'"GPS"'! lonlats|read 1 line at a time|echo into Tee appends to file which #worksaround  buffering and not tee writing to only 1 file
stdbuf -o0 fping -l -r 0 -t1000 $1 |while read line; do echo $line|stdbuf -o0 xargs -L 1 -I '{}' date '+%H:%M:%S.%3N '$1' !'""'! {}'|while read line; do echo $line|tee -a "crap/$(date "+%Y%m%d%H%M")_"$pipefilename".log"; done


#|tee "$(date "+%Y%m%d%H%M%s")_"$pipefilename".log" 

echo end of bccl.sh

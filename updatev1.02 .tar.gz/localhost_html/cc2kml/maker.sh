#!/bin/bash
#$projname = shell_exec('./getaprojectdir.sh');
#$out = array();
#$status = -1;

#$projname=shell_exec( './getaprojectdir.sh 2>&1' );
#echo $projname;
#sleep(3);

./runonce.sh
clear

projname=`kdialog --title "Select an EXISTING project directory" --getexistingdirectory .`
echo ""
echo "^"
echo "$projname"
sleep 1
php cc2kmlmaker.php "$projname"



